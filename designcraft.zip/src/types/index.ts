export type CategoryType = 
  | 'All'
  | 'Logo Design'
  | 'UI/UX Design'
  | 'Branding'
  | 'Web Design'
  | 'Social Media'
  | 'Illustration'
  | 'Posters';

export interface Review {
  id: string;
  clientName: string;
  clientRole: string;
  clientCompany: string;
  clientAvatar: string;
  rating: number;
  date: string;
  comment: string;
  projectName?: string;
}

export interface ServicePackage {
  id: string;
  name: string;
  price: number;
  deliveryDays: number;
  revisions: string;
  description: string;
  deliverables: string[];
}

export interface ServiceItem {
  id: string;
  title: string;
  category: CategoryType;
  description: string;
  startingPrice: number;
  iconName: string;
  deliverables: string[];
  popular?: boolean;
}

export interface PortfolioProject {
  id: string;
  title: string;
  designerId: string;
  designerName: string;
  designerAvatar: string;
  designerTitle: string;
  category: CategoryType;
  imageUrl: string;
  secondaryImages?: string[];
  description: string;
  likes: number;
  views: number;
  toolsUsed: string[];
  clientName?: string;
  completionDate?: string;
  featured?: boolean;
  deliverables?: string[];
}

export interface Designer {
  id: string;
  name: string;
  handle: string;
  avatar: string;
  coverImage: string;
  title: string;
  category: CategoryType;
  location: string;
  bio: string;
  about: string;
  skills: string[];
  rating: number;
  reviewCount: number;
  completedProjects: number;
  startingPrice: number;
  hourlyRate: number;
  availability: 'available' | 'busy' | 'unavailable';
  verified: boolean;
  featured: boolean;
  services: ServicePackage[];
  reviews: Review[];
  socials: {
    dribbble?: string;
    behance?: string;
    instagram?: string;
    website?: string;
    twitter?: string;
  };
}

export interface ClientProject {
  id: string;
  title: string;
  category: CategoryType;
  designerId?: string;
  designerName?: string;
  designerAvatar?: string;
  budget: number;
  deadline: string;
  status: 'In Progress' | 'Under Review' | 'Completed' | 'Pending Proposal';
  description: string;
  createdAt: string;
  deliverablesCount: number;
}

export interface MessageThread {
  id: string;
  participantId: string;
  participantName: string;
  participantAvatar: string;
  participantRole: string;
  lastMessage: string;
  lastMessageTime: string;
  unreadCount: number;
  messages: {
    id: string;
    senderId: string;
    text: string;
    timestamp: string;
    isOwn: boolean;
  }[];
}

export interface User {
  id: string;
  name: string;
  email: string;
  role: 'client' | 'designer';
  avatar: string;
  title?: string;
  bio?: string;
  location?: string;
  company?: string;
}

export type PageView = 
  | 'home'
  | 'explore'
  | 'designers'
  | 'designer-profile'
  | 'services'
  | 'about'
  | 'contact'
  | 'login'
  | 'signup'
  | 'client-dashboard'
  | 'designer-dashboard';

export interface ToastMessage {
  id: string;
  type: 'success' | 'info' | 'warning' | 'error';
  title: string;
  message: string;
}
