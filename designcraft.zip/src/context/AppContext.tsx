import React, { createContext, useContext, useState, useEffect } from 'react';
import { 
  Designer, 
  PortfolioProject, 
  ServiceItem, 
  User, 
  PageView, 
  ClientProject, 
  MessageThread, 
  ToastMessage,
  CategoryType 
} from '../types';
import { 
  INITIAL_DESIGNERS, 
  INITIAL_PROJECTS, 
  INITIAL_SERVICES, 
  INITIAL_CLIENT_PROJECTS, 
  INITIAL_MESSAGE_THREADS 
} from '../data/mockData';

interface AppContextType {
  // Theme
  isDarkMode: boolean;
  toggleDarkMode: () => void;
  
  // Navigation
  currentView: PageView;
  setCurrentView: (view: PageView) => void;
  navigateTo: (view: PageView, params?: { designerId?: string; projectId?: string; category?: CategoryType }) => void;
  
  // Active Entities
  selectedDesignerId: string | null;
  setSelectedDesignerId: (id: string | null) => void;
  selectedProject: PortfolioProject | null;
  setSelectedProject: (project: PortfolioProject | null) => void;
  activeCategoryFilter: CategoryType;
  setActiveCategoryFilter: (category: CategoryType) => void;

  // Modals
  hireModalDesigner: Designer | null;
  openHireModal: (designer: Designer) => void;
  closeHireModal: () => void;
  isStartProjectOpen: boolean;
  openStartProjectModal: () => void;
  closeStartProjectModal: () => void;

  // Data Collections
  designers: Designer[];
  projects: PortfolioProject[];
  services: ServiceItem[];
  clientProjects: ClientProject[];
  messageThreads: MessageThread[];
  
  // Likes & Favorites
  likedProjectIds: Set<string>;
  toggleLikeProject: (projectId: string) => void;
  savedDesignerIds: Set<string>;
  toggleSaveDesigner: (designerId: string) => void;

  // Auth
  currentUser: User | null;
  login: (role: 'client' | 'designer') => void;
  logout: () => void;

  // Actions
  createClientProject: (project: Omit<ClientProject, 'id' | 'createdAt' | 'status' | 'deliverablesCount'>) => void;
  addDesignerProject: (project: Omit<PortfolioProject, 'id' | 'likes' | 'views'>) => void;
  deleteDesignerProject: (projectId: string) => void;
  sendMessage: (threadId: string, text: string) => void;
  startMessageWithDesigner: (designer: Designer, initialMessage?: string) => void;

  // Notifications
  toasts: ToastMessage[];
  showToast: (title: string, message: string, type?: 'success' | 'info' | 'warning' | 'error') => void;
  removeToast: (id: string) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

const DEMO_CLIENT: User = {
  id: 'usr-client-1',
  name: 'Sophia Laurent',
  email: 'sophia@laurentstudio.com',
  role: 'client',
  avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80',
  title: 'Creative Brand Director',
  company: 'Aura Studio & Co.'
};

const DEMO_DESIGNER: User = {
  id: 'des-1',
  name: 'Elena Rostova',
  email: 'elena.rostova@designcraft.com',
  role: 'designer',
  avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=200&q=80',
  title: 'Senior Product & UI/UX Designer',
  location: 'Berlin, Germany',
  bio: 'Crafting intentional, high-converting digital products for ambitious ventures.'
};

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Theme State
  const [isDarkMode, setIsDarkMode] = useState<boolean>(() => {
    const saved = localStorage.getItem('designcraft_theme');
    if (saved) return saved === 'dark';
    return window.matchMedia('(prefers-color-scheme: dark)').matches;
  });

  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
      localStorage.setItem('designcraft_theme', 'dark');
    } else {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('designcraft_theme', 'light');
    }
  }, [isDarkMode]);

  const toggleDarkMode = () => setIsDarkMode(prev => !prev);

  // Navigation State
  const [currentView, setCurrentView] = useState<PageView>('home');
  const [selectedDesignerId, setSelectedDesignerId] = useState<string | null>(null);
  const [selectedProject, setSelectedProject] = useState<PortfolioProject | null>(null);
  const [activeCategoryFilter, setActiveCategoryFilter] = useState<CategoryType>('All');

  // Modals State
  const [hireModalDesigner, setHireModalDesigner] = useState<Designer | null>(null);
  const [isStartProjectOpen, setIsStartProjectOpen] = useState<boolean>(false);

  // Auth State
  const [currentUser, setCurrentUser] = useState<User | null>(() => {
    const savedUser = localStorage.getItem('designcraft_user');
    if (savedUser) {
      try {
        return JSON.parse(savedUser);
      } catch (e) {
        console.error(e);
      }
    }
    return DEMO_CLIENT; // Default logged in as Client for great demo experience
  });

  // Collections State
  const [designers] = useState<Designer[]>(INITIAL_DESIGNERS);
  const [projects, setProjects] = useState<PortfolioProject[]>(() => {
    const saved = localStorage.getItem('designcraft_projects');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.error(e);
      }
    }
    return INITIAL_PROJECTS;
  });

  const [services] = useState<ServiceItem[]>(INITIAL_SERVICES);
  
  const [clientProjects, setClientProjects] = useState<ClientProject[]>(() => {
    const saved = localStorage.getItem('designcraft_client_projects');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.error(e);
      }
    }
    return INITIAL_CLIENT_PROJECTS;
  });

  const [messageThreads, setMessageThreads] = useState<MessageThread[]>(() => {
    const saved = localStorage.getItem('designcraft_messages');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.error(e);
      }
    }
    return INITIAL_MESSAGE_THREADS;
  });

  // Likes & Saves
  const [likedProjectIds, setLikedProjectIds] = useState<Set<string>>(() => {
    const saved = localStorage.getItem('designcraft_likes');
    if (saved) {
      try {
        return new Set(JSON.parse(saved));
      } catch (e) {
        console.error(e);
      }
    }
    return new Set(['proj-1', 'proj-3']);
  });

  const [savedDesignerIds, setSavedDesignerIds] = useState<Set<string>>(() => {
    const saved = localStorage.getItem('designcraft_saved_designers');
    if (saved) {
      try {
        return new Set(JSON.parse(saved));
      } catch (e) {
        console.error(e);
      }
    }
    return new Set(['des-1', 'des-2']);
  });

  // Toast Notifications
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  const showToast = (title: string, message: string, type: 'success' | 'info' | 'warning' | 'error' = 'success') => {
    const id = 'toast-' + Date.now() + Math.random().toString(36).substring(2, 6);
    setToasts(prev => [...prev, { id, title, message, type }]);
    setTimeout(() => {
      setToasts(prev => prev.filter(t => t.id !== id));
    }, 3500);
  };

  const removeToast = (id: string) => {
    setToasts(prev => prev.filter(t => t.id !== id));
  };

  // Synchronize state changes to localStorage
  useEffect(() => {
    localStorage.setItem('designcraft_projects', JSON.stringify(projects));
  }, [projects]);

  useEffect(() => {
    localStorage.setItem('designcraft_client_projects', JSON.stringify(clientProjects));
  }, [clientProjects]);

  useEffect(() => {
    localStorage.setItem('designcraft_messages', JSON.stringify(messageThreads));
  }, [messageThreads]);

  useEffect(() => {
    localStorage.setItem('designcraft_likes', JSON.stringify(Array.from(likedProjectIds)));
  }, [likedProjectIds]);

  useEffect(() => {
    localStorage.setItem('designcraft_saved_designers', JSON.stringify(Array.from(savedDesignerIds)));
  }, [savedDesignerIds]);

  useEffect(() => {
    if (currentUser) {
      localStorage.setItem('designcraft_user', JSON.stringify(currentUser));
    } else {
      localStorage.removeItem('designcraft_user');
    }
  }, [currentUser]);

  // Actions
  const navigateTo = (view: PageView, params?: { designerId?: string; projectId?: string; category?: CategoryType }) => {
    if (params?.designerId) {
      setSelectedDesignerId(params.designerId);
    }
    if (params?.projectId) {
      const p = projects.find(proj => proj.id === params.projectId);
      if (p) setSelectedProject(p);
    }
    if (params?.category) {
      setActiveCategoryFilter(params.category);
    }
    setCurrentView(view);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const toggleLikeProject = (projectId: string) => {
    setLikedProjectIds(prev => {
      const next = new Set(prev);
      const isLiked = next.has(projectId);
      if (isLiked) {
        next.delete(projectId);
        showToast('Removed from Likes', 'Project removed from your liked list.', 'info');
      } else {
        next.add(projectId);
        showToast('Added to Likes', 'Project saved to your liked inspirations!', 'success');
      }
      return next;
    });

    setProjects(prev => prev.map(p => {
      if (p.id === projectId) {
        const currentlyLiked = likedProjectIds.has(projectId);
        return {
          ...p,
          likes: currentlyLiked ? p.likes - 1 : p.likes + 1
        };
      }
      return p;
    }));
  };

  const toggleSaveDesigner = (designerId: string) => {
    setSavedDesignerIds(prev => {
      const next = new Set(prev);
      const isSaved = next.has(designerId);
      if (isSaved) {
        next.delete(designerId);
        showToast('Designer Removed', 'Removed designer from your saved list.', 'info');
      } else {
        next.add(designerId);
        showToast('Designer Saved', 'Designer bookmarked in your Client Dashboard.', 'success');
      }
      return next;
    });
  };

  const openHireModal = (designer: Designer) => {
    setHireModalDesigner(designer);
  };

  const closeHireModal = () => {
    setHireModalDesigner(null);
  };

  const openStartProjectModal = () => {
    setIsStartProjectOpen(true);
  };

  const closeStartProjectModal = () => {
    setIsStartProjectOpen(false);
  };

  const login = (role: 'client' | 'designer') => {
    const user = role === 'client' ? DEMO_CLIENT : DEMO_DESIGNER;
    setCurrentUser(user);
    showToast(
      'Signed in Successfully',
      `Welcome back, ${user.name} (${role === 'client' ? 'Client' : 'Designer'} mode)`,
      'success'
    );
    if (role === 'client') {
      setCurrentView('client-dashboard');
    } else {
      setCurrentView('designer-dashboard');
    }
  };

  const logout = () => {
    setCurrentUser(null);
    showToast('Logged Out', 'You have been signed out of your account.', 'info');
    setCurrentView('home');
  };

  const createClientProject = (data: Omit<ClientProject, 'id' | 'createdAt' | 'status' | 'deliverablesCount'>) => {
    const newProject: ClientProject = {
      ...data,
      id: 'cp-' + Date.now(),
      createdAt: 'Just now',
      status: 'Pending Proposal',
      deliverablesCount: 3
    };

    setClientProjects(prev => [newProject, ...prev]);
    showToast('Project Created!', `Your project "${data.title}" has been created and sent.`, 'success');
    closeHireModal();
    closeStartProjectModal();
  };

  const addDesignerProject = (data: Omit<PortfolioProject, 'id' | 'likes' | 'views'>) => {
    const newProject: PortfolioProject = {
      ...data,
      id: 'proj-' + Date.now(),
      likes: 1,
      views: 12
    };

    setProjects(prev => [newProject, ...prev]);
    showToast('Portfolio Item Published!', `"${data.title}" is now live on Explore and your profile.`, 'success');
  };

  const deleteDesignerProject = (projectId: string) => {
    setProjects(prev => prev.filter(p => p.id !== projectId));
    showToast('Project Removed', 'The item was deleted from your portfolio.', 'info');
  };

  const sendMessage = (threadId: string, text: string) => {
    if (!text.trim()) return;
    
    setMessageThreads(prev => prev.map(thread => {
      if (thread.id === threadId) {
        const newMsg = {
          id: 'msg-' + Date.now(),
          senderId: currentUser?.id || 'guest',
          text,
          timestamp: 'Just now',
          isOwn: true
        };
        return {
          ...thread,
          lastMessage: text,
          lastMessageTime: 'Just now',
          messages: [...thread.messages, newMsg]
        };
      }
      return thread;
    }));

    showToast('Message Sent', 'Your reply was delivered.', 'success');
  };

  const startMessageWithDesigner = (designer: Designer, initialMessage?: string) => {
    const existingThread = messageThreads.find(t => t.participantId === designer.id);
    if (existingThread) {
      if (initialMessage) {
        sendMessage(existingThread.id, initialMessage);
      }
    } else {
      const newThread: MessageThread = {
        id: 'th-' + Date.now(),
        participantId: designer.id,
        participantName: designer.name,
        participantAvatar: designer.avatar,
        participantRole: designer.title,
        lastMessage: initialMessage || 'Project conversation started',
        lastMessageTime: 'Just now',
        unreadCount: 0,
        messages: initialMessage ? [{
          id: 'msg-' + Date.now(),
          senderId: currentUser?.id || 'guest',
          text: initialMessage,
          timestamp: 'Just now',
          isOwn: true
        }] : []
      };
      setMessageThreads(prev => [newThread, ...prev]);
    }

    showToast('Conversation Started', `Connected with ${designer.name}. Redirecting to dashboard messages.`, 'success');
    setCurrentView('client-dashboard');
  };

  return (
    <AppContext.Provider
      value={{
        isDarkMode,
        toggleDarkMode,
        currentView,
        setCurrentView,
        navigateTo,
        selectedDesignerId,
        setSelectedDesignerId,
        selectedProject,
        setSelectedProject,
        activeCategoryFilter,
        setActiveCategoryFilter,
        hireModalDesigner,
        openHireModal,
        closeHireModal,
        isStartProjectOpen,
        openStartProjectModal,
        closeStartProjectModal,
        designers,
        projects,
        services,
        clientProjects,
        messageThreads,
        likedProjectIds,
        toggleLikeProject,
        savedDesignerIds,
        toggleSaveDesigner,
        currentUser,
        login,
        logout,
        createClientProject,
        addDesignerProject,
        deleteDesignerProject,
        sendMessage,
        startMessageWithDesigner,
        toasts,
        showToast,
        removeToast
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = (): AppContextType => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
