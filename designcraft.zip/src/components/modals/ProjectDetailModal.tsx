import React, { useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { 
  X, 
  Heart, 
  Eye, 
  Calendar, 
  ExternalLink, 
  UserCheck, 
  CheckCircle,
  Share2
} from 'lucide-react';

export const ProjectDetailModal: React.FC = () => {
  const { 
    selectedProject, 
    setSelectedProject, 
    likedProjectIds, 
    toggleLikeProject, 
    navigateTo, 
    designers,
    openHireModal,
    showToast
  } = useApp();

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setSelectedProject(null);
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [setSelectedProject]);

  if (!selectedProject) return null;

  const isLiked = likedProjectIds.has(selectedProject.id);
  const designer = designers.find(d => d.id === selectedProject.designerId);

  const handleShare = () => {
    navigator.clipboard?.writeText(window.location.href);
    showToast('Link Copied', 'Project link copied to clipboard!', 'info');
  };

  const handleViewProfile = () => {
    if (selectedProject.designerId) {
      setSelectedProject(null);
      navigateTo('designer-profile', { designerId: selectedProject.designerId });
    }
  };

  const handleHire = () => {
    if (designer) {
      setSelectedProject(null);
      openHireModal(designer);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 overflow-y-auto bg-black/75 backdrop-blur-md animate-in fade-in duration-200">
      <div 
        className="relative w-full max-w-4xl bg-white dark:bg-neutral-900 rounded-2xl shadow-2xl border border-neutral-200 dark:border-neutral-800 overflow-hidden my-auto max-h-[92vh] flex flex-col"
        onClick={e => e.stopPropagation()}
      >
        {/* Header Bar */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-neutral-200 dark:border-neutral-800 bg-white/60 dark:bg-neutral-900/60 backdrop-blur-md">
          <div className="flex items-center gap-3">
            <img
              src={selectedProject.designerAvatar}
              alt={selectedProject.designerName}
              referrerPolicy="no-referrer"
              className="w-10 h-10 rounded-full object-cover ring-2 ring-indigo-500/20"
            />
            <div>
              <div className="flex items-center gap-1.5">
                <h4 className="font-semibold text-sm text-neutral-900 dark:text-white leading-tight">
                  {selectedProject.designerName}
                </h4>
                {designer?.verified && (
                  <CheckCircle className="w-3.5 h-3.5 text-indigo-500 fill-indigo-500/10" />
                )}
              </div>
              <p className="text-xs text-neutral-500 dark:text-neutral-400">
                {selectedProject.designerTitle}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleShare}
              className="p-2 rounded-xl text-neutral-600 dark:text-neutral-300 hover:bg-neutral-100 dark:hover:bg-neutral-800 transition-colors"
              title="Share project"
            >
              <Share2 className="w-4 h-4" />
            </button>

            <button
              id="modal-like-btn"
              onClick={() => toggleLikeProject(selectedProject.id)}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl border text-xs font-semibold transition-all ${
                isLiked
                  ? 'bg-rose-50 border-rose-200 text-rose-600 dark:bg-rose-950/40 dark:border-rose-900 dark:text-rose-400'
                  : 'bg-neutral-50 dark:bg-neutral-800 border-neutral-200 dark:border-neutral-700 text-neutral-700 dark:text-neutral-300 hover:text-rose-500'
              }`}
            >
              <Heart className={`w-3.5 h-3.5 ${isLiked ? 'fill-rose-500 text-rose-500' : ''}`} />
              <span>{selectedProject.likes}</span>
            </button>

            <button
              id="close-project-modal-btn"
              onClick={() => setSelectedProject(null)}
              className="p-2 rounded-xl text-neutral-400 hover:text-neutral-900 dark:hover:text-white hover:bg-neutral-100 dark:hover:bg-neutral-800 transition-colors"
              aria-label="Close modal"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Modal Scrollable Body */}
        <div className="overflow-y-auto p-6 sm:p-8 space-y-6 flex-1">
          {/* Main Visual Showcase */}
          <div className="rounded-2xl overflow-hidden shadow-md bg-neutral-100 dark:bg-neutral-800 border border-neutral-200/60 dark:border-neutral-700/60">
            <img
              src={selectedProject.imageUrl}
              alt={selectedProject.title}
              referrerPolicy="no-referrer"
              className="w-full max-h-[480px] object-cover"
            />
          </div>

          {/* Project Details Grid */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 items-start">
            <div className="md:col-span-2 space-y-4">
              <div className="flex items-center gap-2 flex-wrap">
                <span className="px-2.5 py-1 rounded-md text-xs font-semibold bg-indigo-50 text-indigo-600 dark:bg-indigo-950/50 dark:text-indigo-400 border border-indigo-200/60 dark:border-indigo-800/60">
                  {selectedProject.category}
                </span>
                {selectedProject.clientName && (
                  <span className="text-xs text-neutral-500 flex items-center gap-1">
                    Client: <strong className="text-neutral-700 dark:text-neutral-300">{selectedProject.clientName}</strong>
                  </span>
                )}
                {selectedProject.completionDate && (
                  <span className="text-xs text-neutral-500 flex items-center gap-1">
                    <Calendar className="w-3.5 h-3.5 text-neutral-400" /> {selectedProject.completionDate}
                  </span>
                )}
              </div>

              <h2 className="text-2xl sm:text-3xl font-display font-bold text-neutral-900 dark:text-white">
                {selectedProject.title}
              </h2>

              <p className="text-neutral-600 dark:text-neutral-300 leading-relaxed text-sm sm:text-base">
                {selectedProject.description}
              </p>

              {/* Tools Used */}
              {selectedProject.toolsUsed && selectedProject.toolsUsed.length > 0 && (
                <div className="pt-2">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-neutral-400 dark:text-neutral-500 mb-2">
                    Tools & Technologies
                  </h4>
                  <div className="flex flex-wrap gap-2">
                    {selectedProject.toolsUsed.map(tool => (
                      <span
                        key={tool}
                        className="px-2.5 py-1 rounded-lg text-xs font-medium bg-neutral-100 dark:bg-neutral-800 text-neutral-700 dark:text-neutral-300"
                      >
                        {tool}
                      </span>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Sidebar actions card */}
            <div className="p-5 rounded-2xl bg-neutral-50 dark:bg-neutral-800/60 border border-neutral-200 dark:border-neutral-700/80 space-y-4">
              <div className="flex items-center justify-between text-xs text-neutral-500 pb-3 border-b border-neutral-200 dark:border-neutral-700">
                <span className="flex items-center gap-1">
                  <Eye className="w-4 h-4 text-neutral-400" /> {selectedProject.views} views
                </span>
                <span className="flex items-center gap-1">
                  <Heart className="w-4 h-4 text-rose-500 fill-rose-500" /> {selectedProject.likes} likes
                </span>
              </div>

              <div className="space-y-2">
                <p className="text-xs text-neutral-500 font-medium">Interested in a similar project?</p>
                <button
                  id="modal-hire-designer-btn"
                  onClick={handleHire}
                  className="w-full py-2.5 px-4 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-sm transition-all shadow-md shadow-indigo-600/20 flex items-center justify-center gap-2"
                >
                  <UserCheck className="w-4 h-4" />
                  <span>Hire {selectedProject.designerName.split(' ')[0]}</span>
                </button>

                <button
                  id="modal-view-profile-btn"
                  onClick={handleViewProfile}
                  className="w-full py-2.5 px-4 rounded-xl border border-neutral-300 dark:border-neutral-700 hover:bg-neutral-100 dark:hover:bg-neutral-800 text-neutral-900 dark:text-white font-medium text-sm transition-colors flex items-center justify-center gap-1.5"
                >
                  <span>View Full Profile</span>
                  <ExternalLink className="w-3.5 h-3.5 text-neutral-400" />
                </button>
              </div>

              {designer && (
                <div className="text-xs text-neutral-500 dark:text-neutral-400 pt-2 border-t border-neutral-200 dark:border-neutral-700">
                  <span>Starting at </span>
                  <strong className="text-neutral-900 dark:text-white font-semibold">${designer.startingPrice}</strong>
                  <span> • {designer.availability === 'available' ? '🟢 Available now' : '🟡 Busy'}</span>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
