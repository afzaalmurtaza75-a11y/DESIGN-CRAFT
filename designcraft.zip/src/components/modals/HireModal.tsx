import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { CategoryType } from '../../types';
import { X, CheckCircle, DollarSign, Calendar, Sparkles } from 'lucide-react';

export const HireModal: React.FC = () => {
  const { hireModalDesigner, closeHireModal, createClientProject, showToast } = useApp();

  const [title, setTitle] = useState('');
  const [category, setCategory] = useState<CategoryType>('UI/UX Design');
  const [budget, setBudget] = useState<number>(1200);
  const [deadline, setDeadline] = useState('');
  const [description, setDescription] = useState('');
  const [selectedPackage, setSelectedPackage] = useState<string>('');

  if (!hireModalDesigner) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) {
      showToast('Title Required', 'Please provide a descriptive title for your project.', 'warning');
      return;
    }
    if (!description.trim()) {
      showToast('Brief Required', 'Please share a brief description of what you need designed.', 'warning');
      return;
    }

    createClientProject({
      title,
      category,
      designerId: hireModalDesigner.id,
      designerName: hireModalDesigner.name,
      designerAvatar: hireModalDesigner.avatar,
      budget: Number(budget) || hireModalDesigner.startingPrice,
      deadline: deadline || 'Within 2 weeks',
      description
    });
  };

  const handlePackageSelect = (pkgName: string, price: number) => {
    setSelectedPackage(pkgName);
    setBudget(price);
    setTitle(`${pkgName} for ${hireModalDesigner.name}`);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 overflow-y-auto bg-black/75 backdrop-blur-md animate-in fade-in duration-200">
      <div 
        className="relative w-full max-w-2xl bg-white dark:bg-neutral-900 rounded-2xl shadow-2xl border border-neutral-200 dark:border-neutral-800 overflow-hidden my-auto max-h-[92vh] flex flex-col"
        onClick={e => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-neutral-200 dark:border-neutral-800 bg-neutral-50/50 dark:bg-neutral-900/50">
          <div className="flex items-center gap-3">
            <img
              src={hireModalDesigner.avatar}
              alt={hireModalDesigner.name}
              referrerPolicy="no-referrer"
              className="w-10 h-10 rounded-full object-cover ring-2 ring-indigo-500/20"
            />
            <div>
              <h3 className="font-display font-bold text-base text-neutral-900 dark:text-white flex items-center gap-1.5">
                Hire {hireModalDesigner.name}
                {hireModalDesigner.verified && (
                  <CheckCircle className="w-4 h-4 text-indigo-500 fill-indigo-500/10" />
                )}
              </h3>
              <p className="text-xs text-neutral-500 dark:text-neutral-400">
                Starting from ${hireModalDesigner.startingPrice} • {hireModalDesigner.location}
              </p>
            </div>
          </div>

          <button
            onClick={closeHireModal}
            className="p-2 rounded-xl text-neutral-400 hover:text-neutral-900 dark:hover:text-white hover:bg-neutral-100 dark:hover:bg-neutral-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Form */}
        <form onSubmit={handleSubmit} className="p-6 sm:p-8 overflow-y-auto space-y-5 flex-1">
          {/* Quick Package Selector if available */}
          {hireModalDesigner.services && hireModalDesigner.services.length > 0 && (
            <div className="space-y-2">
              <label className="text-xs font-bold uppercase tracking-wider text-neutral-500">
                Choose a Pre-defined Package (Optional)
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {hireModalDesigner.services.map(pkg => (
                  <div
                    key={pkg.id}
                    onClick={() => handlePackageSelect(pkg.name, pkg.price)}
                    className={`p-3.5 rounded-xl border cursor-pointer transition-all ${
                      selectedPackage === pkg.name
                        ? 'border-indigo-600 bg-indigo-50/70 dark:bg-indigo-950/40 text-indigo-900 dark:text-indigo-200'
                        : 'border-neutral-200 dark:border-neutral-800 hover:border-neutral-300 dark:hover:border-neutral-700 bg-neutral-50/50 dark:bg-neutral-800/40'
                    }`}
                  >
                    <div className="flex justify-between items-baseline">
                      <span className="font-semibold text-xs text-neutral-900 dark:text-white">{pkg.name}</span>
                      <span className="font-bold text-xs text-indigo-600 dark:text-indigo-400">${pkg.price}</span>
                    </div>
                    <p className="text-[11px] text-neutral-500 dark:text-neutral-400 mt-1 line-clamp-2 leading-tight">
                      {pkg.description}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Project Title */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-neutral-600 dark:text-neutral-300 mb-1.5">
              Project Title *
            </label>
            <input
              type="text"
              required
              value={title}
              onChange={e => setTitle(e.target.value)}
              placeholder="e.g. Modern Mobile Banking App Onboarding Redesign"
              className="w-full px-4 py-2.5 rounded-xl border border-neutral-300 dark:border-neutral-700 bg-white dark:bg-neutral-800 text-neutral-900 dark:text-white text-sm focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500"
            />
          </div>

          {/* Category & Budget */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-neutral-600 dark:text-neutral-300 mb-1.5">
                Discipline Category
              </label>
              <select
                value={category}
                onChange={e => setCategory(e.target.value as CategoryType)}
                className="w-full px-4 py-2.5 rounded-xl border border-neutral-300 dark:border-neutral-700 bg-white dark:bg-neutral-800 text-neutral-900 dark:text-white text-sm focus:outline-none focus:border-indigo-500"
              >
                <option value="UI/UX Design">UI/UX Design</option>
                <option value="Branding">Brand Identity & Branding</option>
                <option value="Logo Design">Logo Design</option>
                <option value="Web Design">Web Design</option>
                <option value="Social Media">Social Media</option>
                <option value="Posters">Poster & Print</option>
                <option value="Illustration">Illustration</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-neutral-600 dark:text-neutral-300 mb-1.5">
                Estimated Budget ($ USD)
              </label>
              <div className="relative">
                <DollarSign className="w-4 h-4 text-neutral-400 absolute left-3 top-3" />
                <input
                  type="number"
                  min="50"
                  step="50"
                  value={budget}
                  onChange={e => setBudget(Number(e.target.value))}
                  className="w-full pl-9 pr-4 py-2.5 rounded-xl border border-neutral-300 dark:border-neutral-700 bg-white dark:bg-neutral-800 text-neutral-900 dark:text-white text-sm focus:outline-none focus:border-indigo-500"
                />
              </div>
            </div>
          </div>

          {/* Deadline */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-neutral-600 dark:text-neutral-300 mb-1.5">
              Target Completion Timeline
            </label>
            <div className="relative">
              <Calendar className="w-4 h-4 text-neutral-400 absolute left-3 top-3" />
              <input
                type="text"
                value={deadline}
                onChange={e => setDeadline(e.target.value)}
                placeholder="e.g. 2-3 weeks, or by November 15th"
                className="w-full pl-9 pr-4 py-2.5 rounded-xl border border-neutral-300 dark:border-neutral-700 bg-white dark:bg-neutral-800 text-neutral-900 dark:text-white text-sm focus:outline-none focus:border-indigo-500"
              />
            </div>
          </div>

          {/* Project Brief */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-neutral-600 dark:text-neutral-300 mb-1.5">
              Project Scope & Brief *
            </label>
            <textarea
              required
              rows={4}
              value={description}
              onChange={e => setDescription(e.target.value)}
              placeholder="Describe your company, the main goals, target audience, deliverables you need, and any inspiration links..."
              className="w-full px-4 py-2.5 rounded-xl border border-neutral-300 dark:border-neutral-700 bg-white dark:bg-neutral-800 text-neutral-900 dark:text-white text-sm focus:outline-none focus:border-indigo-500"
            ></textarea>
          </div>

          <div className="pt-3 border-t border-neutral-200 dark:border-neutral-800 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={closeHireModal}
              className="px-4 py-2.5 text-sm font-medium text-neutral-600 dark:text-neutral-300 hover:bg-neutral-100 dark:hover:bg-neutral-800 rounded-xl transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-6 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-sm rounded-xl transition-all shadow-md shadow-indigo-600/20 flex items-center gap-2"
            >
              <Sparkles className="w-4 h-4" />
              <span>Send Project Proposal</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
