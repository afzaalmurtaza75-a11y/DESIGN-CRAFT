import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { CategoryType } from '../../types';
import { 
  X, 
  Sparkles, 
  Check, 
  DollarSign, 
  Calendar, 
  Layers,
  Palette,
  Layout,
  Globe,
  Share2,
  Image as ImageIcon,
  PenTool
} from 'lucide-react';

export const StartProjectModal: React.FC = () => {
  const { isStartProjectOpen, closeStartProjectModal, createClientProject, showToast, designers } = useApp();

  const [step, setStep] = useState<1 | 2>(1);
  const [selectedCategory, setSelectedCategory] = useState<CategoryType>('UI/UX Design');
  const [title, setTitle] = useState('');
  const [budget, setBudget] = useState<number>(1500);
  const [deadline, setDeadline] = useState('Within 3 weeks');
  const [description, setDescription] = useState('');
  const [preferredDesignerId, setPreferredDesignerId] = useState<string>('');

  if (!isStartProjectOpen) return null;

  const categories: { label: CategoryType; icon: React.ReactNode; desc: string }[] = [
    { label: 'Logo Design', icon: <PenTool className="w-5 h-5" />, desc: 'Brand marks, vectors, and iconography' },
    { label: 'UI/UX Design', icon: <Layout className="w-5 h-5" />, desc: 'Mobile apps, web software, design systems' },
    { label: 'Branding', icon: <Palette className="w-5 h-5" />, desc: 'Comprehensive identity suites & guidelines' },
    { label: 'Web Design', icon: <Globe className="w-5 h-5" />, desc: 'Landing pages, responsive web layouts' },
    { label: 'Social Media', icon: <Share2 className="w-5 h-5" />, desc: 'Social feed templates, carousels, ads' },
    { label: 'Illustration', icon: <Sparkles className="w-5 h-5" />, desc: 'Custom 2D/3D visual art and editorial' },
    { label: 'Posters', icon: <ImageIcon className="w-5 h-5" />, desc: 'Print & digital exhibition posters' },
  ];

  const handleNext = () => {
    setStep(2);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) {
      showToast('Title Required', 'Please enter a title for your design project.', 'warning');
      return;
    }
    if (!description.trim()) {
      showToast('Brief Required', 'Please provide a brief description of the design requirements.', 'warning');
      return;
    }

    const assignedDesigner = designers.find(d => d.id === preferredDesignerId);

    createClientProject({
      title,
      category: selectedCategory,
      designerId: assignedDesigner?.id,
      designerName: assignedDesigner?.name,
      designerAvatar: assignedDesigner?.avatar,
      budget: Number(budget) || 1000,
      deadline: deadline || 'Within 1 month',
      description
    });

    // Reset
    setStep(1);
    setTitle('');
    setDescription('');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 overflow-y-auto bg-black/75 backdrop-blur-md animate-in fade-in duration-200">
      <div 
        className="relative w-full max-w-2xl bg-white dark:bg-neutral-900 rounded-2xl shadow-2xl border border-neutral-200 dark:border-neutral-800 overflow-hidden my-auto max-h-[92vh] flex flex-col"
        onClick={e => e.stopPropagation()}
      >
        {/* Modal Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-neutral-200 dark:border-neutral-800 bg-neutral-50/50 dark:bg-neutral-900/50">
          <div>
            <span className="text-[10px] uppercase font-bold tracking-widest text-indigo-600 dark:text-indigo-400">
              Step {step} of 2 • Project Setup
            </span>
            <h3 className="font-display font-bold text-lg text-neutral-900 dark:text-white">
              {step === 1 ? 'What type of design do you need?' : 'Tell us about your project'}
            </h3>
          </div>
          <button
            onClick={closeStartProjectModal}
            className="p-2 rounded-xl text-neutral-400 hover:text-neutral-900 dark:hover:text-white hover:bg-neutral-100 dark:hover:bg-neutral-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Step 1: Category Picker */}
        {step === 1 && (
          <div className="p-6 sm:p-8 space-y-6 overflow-y-auto flex-1">
            <p className="text-sm text-neutral-500 dark:text-neutral-400">
              Select the primary discipline for your creative project to match with vetted talent.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {categories.map(cat => {
                const isSelected = selectedCategory === cat.label;
                return (
                  <div
                    key={cat.label}
                    onClick={() => setSelectedCategory(cat.label)}
                    className={`p-4 rounded-xl border cursor-pointer transition-all flex items-start gap-3.5 ${
                      isSelected
                        ? 'border-indigo-600 bg-indigo-50/60 dark:bg-indigo-950/40 text-indigo-950 dark:text-indigo-100 shadow-sm'
                        : 'border-neutral-200 dark:border-neutral-800 hover:border-neutral-300 dark:hover:border-neutral-700 bg-white dark:bg-neutral-850'
                    }`}
                  >
                    <div className={`p-2.5 rounded-lg shrink-0 ${
                      isSelected
                        ? 'bg-indigo-600 text-white'
                        : 'bg-neutral-100 dark:bg-neutral-800 text-neutral-600 dark:text-neutral-300'
                    }`}>
                      {cat.icon}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between">
                        <h4 className="font-semibold text-sm text-neutral-900 dark:text-white">{cat.label}</h4>
                        {isSelected && <Check className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />}
                      </div>
                      <p className="text-xs text-neutral-500 dark:text-neutral-400 mt-0.5 leading-relaxed">{cat.desc}</p>
                    </div>
                  </div>
                );
              })}
            </div>

            <div className="pt-4 border-t border-neutral-200 dark:border-neutral-800 flex justify-end">
              <button
                onClick={handleNext}
                className="px-6 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-sm transition-all shadow-md shadow-indigo-600/20"
              >
                Continue to Details →
              </button>
            </div>
          </div>
        )}

        {/* Step 2: Project Details Form */}
        {step === 2 && (
          <form onSubmit={handleSubmit} className="p-6 sm:p-8 space-y-5 overflow-y-auto flex-1">
            <div className="flex items-center gap-2 p-2.5 rounded-xl bg-neutral-100 dark:bg-neutral-800 text-xs text-neutral-600 dark:text-neutral-300">
              <span className="font-medium">Selected Category:</span>
              <span className="font-bold text-indigo-600 dark:text-indigo-400">{selectedCategory}</span>
              <button
                type="button"
                onClick={() => setStep(1)}
                className="ml-auto text-indigo-500 hover:underline font-semibold"
              >
                Change
              </button>
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-neutral-600 dark:text-neutral-300 mb-1.5">
                Project Title *
              </label>
              <input
                type="text"
                required
                value={title}
                onChange={e => setTitle(e.target.value)}
                placeholder="e.g. Next-Gen Fintech Mobile App Onboarding & Cards"
                className="w-full px-4 py-2.5 rounded-xl border border-neutral-300 dark:border-neutral-700 bg-white dark:bg-neutral-800 text-neutral-900 dark:text-white text-sm focus:outline-none focus:border-indigo-500"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-neutral-600 dark:text-neutral-300 mb-1.5">
                  Budget ($ USD)
                </label>
                <div className="relative">
                  <DollarSign className="w-4 h-4 text-neutral-400 absolute left-3 top-3" />
                  <input
                    type="number"
                    min="100"
                    step="50"
                    value={budget}
                    onChange={e => setBudget(Number(e.target.value))}
                    className="w-full pl-9 pr-4 py-2.5 rounded-xl border border-neutral-300 dark:border-neutral-700 bg-white dark:bg-neutral-800 text-neutral-900 dark:text-white text-sm focus:outline-none focus:border-indigo-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-neutral-600 dark:text-neutral-300 mb-1.5">
                  Estimated Timeline
                </label>
                <div className="relative">
                  <Calendar className="w-4 h-4 text-neutral-400 absolute left-3 top-3" />
                  <input
                    type="text"
                    value={deadline}
                    onChange={e => setDeadline(e.target.value)}
                    placeholder="e.g. 2 weeks"
                    className="w-full pl-9 pr-4 py-2.5 rounded-xl border border-neutral-300 dark:border-neutral-700 bg-white dark:bg-neutral-800 text-neutral-900 dark:text-white text-sm focus:outline-none focus:border-indigo-500"
                  />
                </div>
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-neutral-600 dark:text-neutral-300 mb-1.5">
                Assign to Specific Designer (Optional)
              </label>
              <select
                value={preferredDesignerId}
                onChange={e => setPreferredDesignerId(e.target.value)}
                className="w-full px-4 py-2.5 rounded-xl border border-neutral-300 dark:border-neutral-700 bg-white dark:bg-neutral-800 text-neutral-900 dark:text-white text-sm focus:outline-none focus:border-indigo-500"
              >
                <option value="">Open to all matching designers</option>
                {designers.map(d => (
                  <option key={d.id} value={d.id}>
                    {d.name} — {d.title} (Starting ${d.startingPrice})
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-neutral-600 dark:text-neutral-300 mb-1.5">
                Project Scope & Details *
              </label>
              <textarea
                required
                rows={4}
                value={description}
                onChange={e => setDescription(e.target.value)}
                placeholder="Share your goals, preferred aesthetic style, specific screen count or brand assets needed..."
                className="w-full px-4 py-2.5 rounded-xl border border-neutral-300 dark:border-neutral-700 bg-white dark:bg-neutral-800 text-neutral-900 dark:text-white text-sm focus:outline-none focus:border-indigo-500"
              ></textarea>
            </div>

            <div className="pt-3 border-t border-neutral-200 dark:border-neutral-800 flex items-center justify-between">
              <button
                type="button"
                onClick={() => setStep(1)}
                className="text-xs font-semibold text-neutral-500 hover:text-neutral-900 dark:hover:text-white"
              >
                ← Back to Category
              </button>

              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={closeStartProjectModal}
                  className="px-4 py-2 text-sm text-neutral-500 hover:text-neutral-900 dark:hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-sm transition-all shadow-md shadow-indigo-600/20 flex items-center gap-2"
                >
                  <Sparkles className="w-4 h-4" />
                  <span>Launch Project</span>
                </button>
              </div>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
