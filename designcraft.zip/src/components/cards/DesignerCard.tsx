import React from 'react';
import { Designer } from '../../types';
import { useApp } from '../../context/AppContext';
import { Star, CheckCircle, Bookmark, ArrowRight, UserCheck, Briefcase } from 'lucide-react';

interface DesignerCardProps {
  designer: Designer;
}

export const DesignerCard: React.FC<DesignerCardProps> = ({ designer }) => {
  const { 
    navigateTo, 
    openHireModal, 
    savedDesignerIds, 
    toggleSaveDesigner 
  } = useApp();

  const isSaved = savedDesignerIds.has(designer.id);

  const handleViewProfile = () => {
    navigateTo('designer-profile', { designerId: designer.id });
  };

  const handleHire = (e: React.MouseEvent) => {
    e.stopPropagation();
    openHireModal(designer);
  };

  return (
    <div
      id={`designer-card-${designer.id}`}
      onClick={handleViewProfile}
      className="group relative bg-white dark:bg-neutral-900 rounded-2xl border border-neutral-200/80 dark:border-neutral-800/80 hover:border-neutral-300 dark:hover:border-neutral-700 shadow-sm hover:shadow-xl transition-all duration-300 flex flex-col justify-between overflow-hidden cursor-pointer"
    >
      {/* Top Banner accent */}
      <div className="h-20 w-full overflow-hidden relative bg-neutral-100 dark:bg-neutral-800">
        <img
          src={designer.coverImage}
          alt={designer.name}
          referrerPolicy="no-referrer"
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500 opacity-80"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-black/20 to-transparent" />
        
        {/* Bookmark button */}
        <button
          onClick={(e) => {
            e.stopPropagation();
            toggleSaveDesigner(designer.id);
          }}
          className={`absolute top-3 right-3 p-1.5 rounded-full backdrop-blur-md transition-colors ${
            isSaved
              ? 'bg-indigo-600 text-white shadow-md'
              : 'bg-black/30 text-white hover:bg-black/50'
          }`}
          title={isSaved ? 'Remove from Saved' : 'Save Designer'}
        >
          <Bookmark className={`w-3.5 h-3.5 ${isSaved ? 'fill-white' : ''}`} />
        </button>
      </div>

      {/* Profile Info */}
      <div className="px-5 pt-0 pb-5 flex-1 flex flex-col">
        {/* Avatar & Availability */}
        <div className="flex items-end justify-between -mt-9 mb-3 relative">
          <div className="relative">
            <img
              src={designer.avatar}
              alt={designer.name}
              referrerPolicy="no-referrer"
              className="w-18 h-18 rounded-2xl object-cover ring-4 ring-white dark:ring-neutral-900 shadow-md bg-white dark:bg-neutral-800"
            />
            {designer.verified && (
              <span className="absolute -bottom-1 -right-1 p-0.5 rounded-full bg-white dark:bg-neutral-900">
                <CheckCircle className="w-4 h-4 text-indigo-600 fill-indigo-600/15" />
              </span>
            )}
          </div>

          <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-semibold border ${
            designer.availability === 'available'
              ? 'bg-emerald-50 text-emerald-700 border-emerald-200/60 dark:bg-emerald-950/40 dark:text-emerald-400 dark:border-emerald-800/60'
              : 'bg-amber-50 text-amber-700 border-amber-200/60 dark:bg-amber-950/40 dark:text-amber-400 dark:border-amber-800/60'
          }`}>
            <span className={`w-1.5 h-1.5 rounded-full ${designer.availability === 'available' ? 'bg-emerald-500 animate-pulse' : 'bg-amber-500'}`} />
            {designer.availability === 'available' ? 'Available' : 'Busy'}
          </span>
        </div>

        {/* Name & Title */}
        <div className="space-y-1 mb-2">
          <h3 className="font-display font-bold text-base text-neutral-900 dark:text-white group-hover:text-indigo-600 dark:group-hover:text-indigo-400 transition-colors">
            {designer.name}
          </h3>
          <p className="text-xs font-medium text-neutral-500 dark:text-neutral-400">
            {designer.title}
          </p>
        </div>

        {/* Short Biography */}
        <p className="text-xs text-neutral-600 dark:text-neutral-300 line-clamp-2 leading-relaxed mb-4">
          {designer.bio}
        </p>

        {/* Skills Badges */}
        <div className="flex flex-wrap gap-1.5 mb-4">
          {designer.skills.slice(0, 3).map(skill => (
            <span
              key={skill}
              className="px-2 py-0.5 rounded-md text-[11px] font-medium bg-neutral-100 dark:bg-neutral-800 text-neutral-700 dark:text-neutral-300"
            >
              {skill}
            </span>
          ))}
          {designer.skills.length > 3 && (
            <span className="px-1.5 py-0.5 text-[11px] text-neutral-400 font-medium">
              +{designer.skills.length - 3}
            </span>
          )}
        </div>

        {/* Metrics Row: Rating, Completed, Starting Price */}
        <div className="mt-auto pt-3 border-t border-neutral-100 dark:border-neutral-800 grid grid-cols-3 gap-2 text-center">
          <div>
            <div className="flex items-center justify-center gap-1 text-xs font-bold text-neutral-900 dark:text-white">
              <Star className="w-3.5 h-3.5 text-amber-500 fill-amber-500" />
              <span>{designer.rating}</span>
            </div>
            <span className="text-[10px] text-neutral-400 uppercase tracking-tight font-medium">
              {designer.reviewCount} reviews
            </span>
          </div>

          <div>
            <div className="flex items-center justify-center gap-1 text-xs font-bold text-neutral-900 dark:text-white">
              <Briefcase className="w-3 h-3 text-neutral-400" />
              <span>{designer.completedProjects}</span>
            </div>
            <span className="text-[10px] text-neutral-400 uppercase tracking-tight font-medium">
              Projects
            </span>
          </div>

          <div>
            <div className="text-xs font-bold text-indigo-600 dark:text-indigo-400">
              ${designer.startingPrice}
            </div>
            <span className="text-[10px] text-neutral-400 uppercase tracking-tight font-medium">
              Starts at
            </span>
          </div>
        </div>
      </div>

      {/* Action Buttons */}
      <div className="p-3 bg-neutral-50 dark:bg-neutral-850/60 border-t border-neutral-200/80 dark:border-neutral-800/80 flex items-center gap-2">
        <button
          onClick={handleViewProfile}
          className="flex-1 py-2 px-3 rounded-xl border border-neutral-300 dark:border-neutral-700 hover:bg-white dark:hover:bg-neutral-800 text-xs font-semibold text-neutral-800 dark:text-neutral-200 transition-colors flex items-center justify-center gap-1"
        >
          <span>View Profile</span>
          <ArrowRight className="w-3 h-3 text-neutral-400" />
        </button>

        <button
          onClick={handleHire}
          className="py-2 px-3.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold shadow-sm transition-all flex items-center justify-center gap-1"
        >
          <UserCheck className="w-3.5 h-3.5" />
          <span>Hire</span>
        </button>
      </div>
    </div>
  );
};
