import React from 'react';
import { PortfolioProject } from '../../types';
import { useApp } from '../../context/AppContext';
import { Heart, Eye, ArrowUpRight } from 'lucide-react';

interface ProjectCardProps {
  project: PortfolioProject;
  onSelect?: () => void;
}

export const ProjectCard: React.FC<ProjectCardProps> = ({ project, onSelect }) => {
  const { likedProjectIds, toggleLikeProject, setSelectedProject } = useApp();
  const isLiked = likedProjectIds.has(project.id);

  const handleClick = () => {
    if (onSelect) {
      onSelect();
    } else {
      setSelectedProject(project);
    }
  };

  return (
    <div 
      id={`project-card-${project.id}`}
      className="group relative bg-white dark:bg-neutral-900 rounded-2xl overflow-hidden border border-neutral-200/80 dark:border-neutral-800/80 hover:border-neutral-300 dark:hover:border-neutral-700 shadow-sm hover:shadow-xl transition-all duration-300 flex flex-col cursor-pointer"
      onClick={handleClick}
    >
      {/* Thumbnail Container */}
      <div className="relative aspect-[4/3] w-full overflow-hidden bg-neutral-100 dark:bg-neutral-800">
        <img
          src={project.imageUrl}
          alt={project.title}
          loading="lazy"
          referrerPolicy="no-referrer"
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500 ease-out"
        />

        {/* Hover Overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex flex-col justify-between p-4">
          <div className="flex justify-between items-center">
            <span className="px-2.5 py-1 rounded-md text-[11px] font-semibold bg-white/90 text-neutral-900 backdrop-blur-md shadow-sm">
              {project.category}
            </span>

            <button
              id={`like-btn-${project.id}`}
              onClick={(e) => {
                e.stopPropagation();
                toggleLikeProject(project.id);
              }}
              className={`p-2 rounded-full backdrop-blur-md transition-transform active:scale-90 ${
                isLiked
                  ? 'bg-rose-500 text-white'
                  : 'bg-black/40 text-white hover:bg-black/60'
              }`}
              aria-label="Like project"
            >
              <Heart className={`w-4 h-4 ${isLiked ? 'fill-white' : ''}`} />
            </button>
          </div>

          <div className="flex items-center justify-between text-white">
            <span className="text-xs font-medium flex items-center gap-1.5">
              <span>View Details</span>
              <ArrowUpRight className="w-3.5 h-3.5" />
            </span>

            <div className="flex items-center gap-2.5 text-xs opacity-90">
              <span className="flex items-center gap-1">
                <Eye className="w-3.5 h-3.5" /> {project.views}
              </span>
              <span className="flex items-center gap-1">
                <Heart className="w-3.5 h-3.5 fill-white/80" /> {project.likes}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Card Info Footer */}
      <div className="p-4 flex items-center justify-between gap-3">
        <div className="flex items-center gap-2.5 min-w-0">
          <img
            src={project.designerAvatar}
            alt={project.designerName}
            referrerPolicy="no-referrer"
            className="w-7 h-7 rounded-full object-cover ring-1 ring-neutral-200 dark:ring-neutral-700 shrink-0"
          />
          <div className="min-w-0">
            <h3 className="text-xs font-semibold text-neutral-900 dark:text-white truncate leading-tight group-hover:text-indigo-600 dark:group-hover:text-indigo-400 transition-colors">
              {project.title}
            </h3>
            <p className="text-[11px] text-neutral-500 dark:text-neutral-400 truncate">
              {project.designerName}
            </p>
          </div>
        </div>

        {/* Quick Like counter on normal state */}
        <button
          onClick={(e) => {
            e.stopPropagation();
            toggleLikeProject(project.id);
          }}
          className="flex items-center gap-1 text-xs text-neutral-400 hover:text-rose-500 transition-colors shrink-0"
        >
          <Heart className={`w-3.5 h-3.5 ${isLiked ? 'text-rose-500 fill-rose-500' : ''}`} />
          <span className="text-[11px] font-medium">{project.likes}</span>
        </button>
      </div>
    </div>
  );
};
