import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { CategoryType, PageView } from '../../types';
import { 
  Sparkles, 
  Send, 
  Check, 
  Dribbble, 
  Twitter, 
  Instagram, 
  Linkedin, 
  Github,
  Heart
} from 'lucide-react';

export const Footer: React.FC = () => {
  const { navigateTo, showToast } = useApp();
  const [email, setEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !email.includes('@')) {
      showToast('Invalid Email', 'Please enter a valid email address.', 'warning');
      return;
    }
    setSubscribed(true);
    showToast('Subscribed!', 'You are now subscribed to the DesignCraft Creative Weekly curated newsletter.', 'success');
    setEmail('');
  };

  const categories: { label: string; cat: CategoryType }[] = [
    { label: 'UI/UX & Product Design', cat: 'UI/UX Design' },
    { label: 'Brand Identity & Guidelines', cat: 'Branding' },
    { label: 'Logo Marks & Typography', cat: 'Logo Design' },
    { label: 'Web Design & Landing Pages', cat: 'Web Design' },
    { label: 'Editorial Posters', cat: 'Posters' },
    { label: 'Social Media & Growth Assets', cat: 'Social Media' }
  ];

  return (
    <footer className="bg-neutral-900 text-neutral-300 border-t border-neutral-800 transition-colors">
      {/* Top newsletter banner */}
      <div className="border-b border-neutral-800/80">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 md:py-16">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            <div className="lg:col-span-7 space-y-2">
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-indigo-500/10 text-indigo-400 text-xs font-semibold tracking-wide border border-indigo-500/20">
                <Sparkles className="w-3.5 h-3.5" /> Curated Creative Digest
              </span>
              <h3 className="text-2xl sm:text-3xl font-display font-bold text-white tracking-tight">
                Stay inspired by the world’s finest design minds.
              </h3>
              <p className="text-neutral-400 text-sm max-w-xl">
                Get weekly design teardowns, typography spotlights, and high-impact design insights delivered straight to your inbox.
              </p>
            </div>
            <div className="lg:col-span-5">
              <form onSubmit={handleSubscribe} className="flex flex-col sm:flex-row gap-2.5">
                <input
                  type="email"
                  value={email}
                  onChange={e => setEmail(e.target.value)}
                  placeholder="Enter your email address..."
                  className="flex-1 px-4 py-3 rounded-xl bg-neutral-800 border border-neutral-700 text-white placeholder-neutral-500 text-sm focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition-all"
                  aria-label="Email for newsletter"
                />
                <button
                  type="submit"
                  className="px-6 py-3 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-medium text-sm transition-all duration-200 flex items-center justify-center gap-2 shadow-lg shadow-indigo-600/25 active:scale-95 shrink-0"
                >
                  {subscribed ? <Check className="w-4 h-4" /> : <Send className="w-4 h-4" />}
                  <span>{subscribed ? 'Subscribed' : 'Join Digest'}</span>
                </button>
              </form>
            </div>
          </div>
        </div>
      </div>

      {/* Main footer navigation */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-14">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-10">
          {/* Brand Column */}
          <div className="lg:col-span-2 space-y-4">
            <div 
              onClick={() => navigateTo('home')}
              className="flex items-center gap-2.5 cursor-pointer select-none group"
            >
              <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-indigo-500 to-cyan-400 flex items-center justify-center text-white shadow-md shadow-indigo-500/20">
                <Sparkles className="w-4 h-4" />
              </div>
              <span className="font-display font-extrabold text-2xl tracking-tight text-white">
                Design<span className="text-indigo-400">Craft</span>
              </span>
            </div>
            <p className="text-neutral-400 text-sm leading-relaxed max-w-sm">
              DesignCraft connects ambitious startups and discerning businesses with world-class graphic designers, art directors, and digital product architects.
            </p>
            <div className="flex items-center gap-3 pt-2">
              <a href="https://dribbble.com" target="_blank" rel="noreferrer" className="w-9 h-9 rounded-lg bg-neutral-800 hover:bg-indigo-600/20 hover:text-indigo-400 flex items-center justify-center text-neutral-400 transition-colors" aria-label="Dribbble">
                <Dribbble className="w-4 h-4" />
              </a>
              <a href="https://twitter.com" target="_blank" rel="noreferrer" className="w-9 h-9 rounded-lg bg-neutral-800 hover:bg-indigo-600/20 hover:text-indigo-400 flex items-center justify-center text-neutral-400 transition-colors" aria-label="Twitter">
                <Twitter className="w-4 h-4" />
              </a>
              <a href="https://instagram.com" target="_blank" rel="noreferrer" className="w-9 h-9 rounded-lg bg-neutral-800 hover:bg-indigo-600/20 hover:text-indigo-400 flex items-center justify-center text-neutral-400 transition-colors" aria-label="Instagram">
                <Instagram className="w-4 h-4" />
              </a>
              <a href="https://linkedin.com" target="_blank" rel="noreferrer" className="w-9 h-9 rounded-lg bg-neutral-800 hover:bg-indigo-600/20 hover:text-indigo-400 flex items-center justify-center text-neutral-400 transition-colors" aria-label="LinkedIn">
                <Linkedin className="w-4 h-4" />
              </a>
              <a href="https://github.com" target="_blank" rel="noreferrer" className="w-9 h-9 rounded-lg bg-neutral-800 hover:bg-indigo-600/20 hover:text-indigo-400 flex items-center justify-center text-neutral-400 transition-colors" aria-label="GitHub">
                <Github className="w-4 h-4" />
              </a>
            </div>
          </div>

          {/* Categories Column */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-white mb-4">
              Explore Disciplines
            </h4>
            <ul className="space-y-2.5 text-sm">
              {categories.map(cat => (
                <li key={cat.label}>
                  <button
                    onClick={() => navigateTo('explore', { category: cat.cat })}
                    className="text-neutral-400 hover:text-white transition-colors text-left"
                  >
                    {cat.label}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Platform Column */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-white mb-4">
              Platform
            </h4>
            <ul className="space-y-2.5 text-sm">
              <li>
                <button onClick={() => navigateTo('explore')} className="text-neutral-400 hover:text-white transition-colors">
                  Explore Designs
                </button>
              </li>
              <li>
                <button onClick={() => navigateTo('designers')} className="text-neutral-400 hover:text-white transition-colors">
                  Find Designers
                </button>
              </li>
              <li>
                <button onClick={() => navigateTo('services')} className="text-neutral-400 hover:text-white transition-colors">
                  Design Services
                </button>
              </li>
              <li>
                <button onClick={() => navigateTo('home')} className="text-neutral-400 hover:text-white transition-colors">
                  How It Works
                </button>
              </li>
              <li>
                <button onClick={() => navigateTo('about')} className="text-neutral-400 hover:text-white transition-colors">
                  About DesignCraft
                </button>
              </li>
            </ul>
          </div>

          {/* Company & Support Column */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-white mb-4">
              Support & Connect
            </h4>
            <ul className="space-y-2.5 text-sm">
              <li>
                <button onClick={() => navigateTo('contact')} className="text-neutral-400 hover:text-white transition-colors">
                  Contact Support
                </button>
              </li>
              <li>
                <button onClick={() => navigateTo('signup')} className="text-neutral-400 hover:text-white transition-colors">
                  Join as a Designer
                </button>
              </li>
              <li>
                <button onClick={() => navigateTo('about')} className="text-neutral-400 hover:text-white transition-colors">
                  Brand Guidelines
                </button>
              </li>
              <li>
                <span className="text-neutral-500 cursor-not-allowed">Privacy Policy</span>
              </li>
              <li>
                <span className="text-neutral-500 cursor-not-allowed">Terms of Service</span>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="pt-12 mt-12 border-t border-neutral-800 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-neutral-500">
          <p>© {new Date().getFullYear()} DesignCraft Inc. All creative rights reserved.</p>
          <div className="flex items-center gap-2">
            <span>Engineered with craftsmanship &</span>
            <Heart className="w-3.5 h-3.5 text-rose-500 inline fill-rose-500" />
            <span>for the global design community</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
