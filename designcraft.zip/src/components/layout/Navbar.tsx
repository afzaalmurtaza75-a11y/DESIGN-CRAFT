import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { PageView } from '../../types';
import { 
  Sparkles, 
  Menu, 
  X, 
  Sun, 
  Moon, 
  Compass, 
  Users, 
  Briefcase, 
  Layers, 
  Phone, 
  Info, 
  PlusCircle, 
  ArrowUpRight,
  UserCheck,
  LogOut,
  ChevronDown
} from 'lucide-react';

export const Navbar: React.FC = () => {
  const { 
    currentView, 
    navigateTo, 
    isDarkMode, 
    toggleDarkMode, 
    currentUser, 
    logout,
    login,
    openStartProjectModal 
  } = useApp();

  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isUserDropdownOpen, setIsUserDropdownOpen] = useState(false);

  const navLinks: { label: string; view: PageView; icon: React.ReactNode }[] = [
    { label: 'Home', view: 'home', icon: <Layers className="w-4 h-4" /> },
    { label: 'Explore', view: 'explore', icon: <Compass className="w-4 h-4" /> },
    { label: 'Designers', view: 'designers', icon: <Users className="w-4 h-4" /> },
    { label: 'Services', view: 'services', icon: <Briefcase className="w-4 h-4" /> },
    { label: 'About', view: 'about', icon: <Info className="w-4 h-4" /> },
    { label: 'Contact', view: 'contact', icon: <Phone className="w-4 h-4" /> }
  ];

  const handleNav = (view: PageView) => {
    navigateTo(view);
    setIsMobileMenuOpen(false);
  };

  return (
    <header className="sticky top-0 z-40 w-full backdrop-blur-xl bg-white/80 dark:bg-neutral-900/80 border-b border-neutral-200/80 dark:border-neutral-800/80 transition-colors duration-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-18 flex items-center justify-between">
        {/* Logo */}
        <div 
          id="nav-logo"
          onClick={() => handleNav('home')} 
          className="flex items-center gap-2.5 cursor-pointer group select-none"
        >
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-neutral-900 via-indigo-950 to-indigo-600 dark:from-indigo-600 dark:via-indigo-500 dark:to-cyan-400 flex items-center justify-center text-white shadow-md shadow-indigo-500/10 group-hover:scale-105 transition-transform duration-200">
            <Sparkles className="w-5 h-5 text-amber-300" />
          </div>
          <div className="flex flex-col">
            <span className="font-display font-extrabold text-xl tracking-tight text-neutral-900 dark:text-white group-hover:text-indigo-600 dark:group-hover:text-indigo-400 transition-colors">
              Design<span className="text-indigo-600 dark:text-indigo-400">Craft</span>
            </span>
            <span className="text-[10px] tracking-widest uppercase font-semibold text-neutral-400 dark:text-neutral-500 -mt-1">
              Curated Talent
            </span>
          </div>
        </div>

        {/* Desktop Navigation Links */}
        <nav className="hidden md:flex items-center gap-1 lg:gap-2">
          {navLinks.map(link => {
            const isActive = currentView === link.view;
            return (
              <button
                key={link.view}
                id={`nav-link-${link.view}`}
                onClick={() => handleNav(link.view)}
                className={`px-3.5 py-2 rounded-lg text-sm font-medium transition-all duration-150 flex items-center gap-1.5 ${
                  isActive
                    ? 'bg-neutral-100 text-indigo-600 dark:bg-neutral-800 dark:text-indigo-400 font-semibold'
                    : 'text-neutral-600 hover:text-neutral-900 dark:text-neutral-400 dark:hover:text-white hover:bg-neutral-100/60 dark:hover:bg-neutral-800/60'
                }`}
              >
                {link.label}
              </button>
            );
          })}
        </nav>

        {/* Right Side Actions */}
        <div className="hidden lg:flex items-center gap-3">
          {/* Dark / Light Toggle */}
          <button
            id="nav-theme-toggle"
            onClick={toggleDarkMode}
            className="p-2 rounded-xl text-neutral-500 hover:text-neutral-900 dark:text-neutral-400 dark:hover:text-white hover:bg-neutral-100 dark:hover:bg-neutral-800 transition-colors"
            title={isDarkMode ? 'Switch to Light mode' : 'Switch to Dark mode'}
            aria-label="Toggle theme"
          >
            {isDarkMode ? <Sun className="w-5 h-5 text-amber-400" /> : <Moon className="w-5 h-5" />}
          </button>

          {/* User Auth or Profile */}
          {currentUser ? (
            <div className="relative">
              <button
                id="nav-user-menu-btn"
                onClick={() => setIsUserDropdownOpen(prev => !prev)}
                className="flex items-center gap-2.5 p-1.5 pr-3 rounded-full border border-neutral-200 dark:border-neutral-700 bg-white dark:bg-neutral-800 hover:border-neutral-300 dark:hover:border-neutral-600 transition-all shadow-sm"
              >
                <img
                  src={currentUser.avatar}
                  alt={currentUser.name}
                  referrerPolicy="no-referrer"
                  className="w-7 h-7 rounded-full object-cover ring-2 ring-indigo-500/30"
                />
                <div className="text-left hidden sm:block">
                  <span className="text-xs font-semibold block leading-tight text-neutral-900 dark:text-white truncate max-w-[90px]">
                    {currentUser.name}
                  </span>
                  <span className="text-[10px] uppercase font-bold text-indigo-600 dark:text-indigo-400 tracking-wider">
                    {currentUser.role}
                  </span>
                </div>
                <ChevronDown className="w-3.5 h-3.5 text-neutral-400 ml-0.5" />
              </button>

              {isUserDropdownOpen && (
                <div 
                  className="absolute right-0 mt-2 w-56 py-2 bg-white dark:bg-neutral-900 rounded-2xl shadow-2xl border border-neutral-200 dark:border-neutral-800 z-50 animate-in fade-in zoom-in-95 duration-150"
                  onClick={() => setIsUserDropdownOpen(false)}
                >
                  <div className="px-4 py-2 border-b border-neutral-100 dark:border-neutral-800">
                    <p className="text-xs font-semibold text-neutral-900 dark:text-white">{currentUser.name}</p>
                    <p className="text-[11px] text-neutral-500 truncate">{currentUser.email}</p>
                  </div>

                  <button
                    onClick={() => handleNav(currentUser.role === 'client' ? 'client-dashboard' : 'designer-dashboard')}
                    className="w-full px-4 py-2.5 text-left text-sm text-neutral-700 dark:text-neutral-200 hover:bg-neutral-50 dark:hover:bg-neutral-800/80 flex items-center gap-2"
                  >
                    <UserCheck className="w-4 h-4 text-indigo-500" />
                    <span>{currentUser.role === 'client' ? 'Client Dashboard' : 'Designer Studio'}</span>
                  </button>

                  <div className="my-1 border-t border-neutral-100 dark:border-neutral-800"></div>

                  <div className="px-3 py-1">
                    <span className="text-[10px] uppercase font-bold text-neutral-400 tracking-wider">Quick Switch Demo:</span>
                    <div className="flex gap-2 mt-1.5">
                      <button
                        onClick={() => login('client')}
                        className={`flex-1 text-[11px] py-1 px-2 rounded-md font-medium text-center border ${
                          currentUser.role === 'client' 
                            ? 'bg-indigo-50 border-indigo-200 text-indigo-700 dark:bg-indigo-950/40 dark:border-indigo-800 dark:text-indigo-300'
                            : 'bg-neutral-50 border-neutral-200 text-neutral-600 dark:bg-neutral-800 dark:border-neutral-700 dark:text-neutral-300'
                        }`}
                      >
                        Client
                      </button>
                      <button
                        onClick={() => login('designer')}
                        className={`flex-1 text-[11px] py-1 px-2 rounded-md font-medium text-center border ${
                          currentUser.role === 'designer' 
                            ? 'bg-indigo-50 border-indigo-200 text-indigo-700 dark:bg-indigo-950/40 dark:border-indigo-800 dark:text-indigo-300'
                            : 'bg-neutral-50 border-neutral-200 text-neutral-600 dark:bg-neutral-800 dark:border-neutral-700 dark:text-neutral-300'
                        }`}
                      >
                        Designer
                      </button>
                    </div>
                  </div>

                  <div className="my-1 border-t border-neutral-100 dark:border-neutral-800"></div>

                  <button
                    onClick={logout}
                    className="w-full px-4 py-2 text-left text-xs text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/30 flex items-center gap-2"
                  >
                    <LogOut className="w-3.5 h-3.5" />
                    <span>Log Out</span>
                  </button>
                </div>
              )}
            </div>
          ) : (
            <div className="flex items-center gap-2">
              <button
                id="nav-login-btn"
                onClick={() => handleNav('login')}
                className="px-4 py-2 text-sm font-medium text-neutral-700 dark:text-neutral-300 hover:text-neutral-900 dark:hover:text-white rounded-xl hover:bg-neutral-100 dark:hover:bg-neutral-800 transition-colors"
              >
                Login
              </button>
              <button
                id="nav-signup-btn"
                onClick={() => handleNav('signup')}
                className="px-4 py-2 text-sm font-medium text-neutral-900 dark:text-white border border-neutral-300 dark:border-neutral-700 hover:bg-neutral-100 dark:hover:bg-neutral-800 rounded-xl transition-all"
              >
                Sign Up
              </button>
            </div>
          )}

          {/* Start a Project CTA */}
          <button
            id="nav-start-project-btn"
            onClick={openStartProjectModal}
            className="px-4.5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-sm font-semibold shadow-md shadow-indigo-600/20 hover:shadow-indigo-600/30 transition-all duration-200 flex items-center gap-1.5 active:scale-95"
          >
            <PlusCircle className="w-4 h-4" />
            <span>Start a Project</span>
          </button>
        </div>

        {/* Mobile menu trigger & Theme icon */}
        <div className="flex items-center gap-2 lg:hidden">
          <button
            onClick={toggleDarkMode}
            className="p-2 rounded-lg text-neutral-600 dark:text-neutral-400 hover:bg-neutral-100 dark:hover:bg-neutral-800"
            aria-label="Toggle theme"
          >
            {isDarkMode ? <Sun className="w-5 h-5 text-amber-400" /> : <Moon className="w-5 h-5" />}
          </button>

          <button
            id="mobile-menu-toggle"
            onClick={() => setIsMobileMenuOpen(prev => !prev)}
            className="p-2 rounded-xl text-neutral-700 dark:text-neutral-200 hover:bg-neutral-100 dark:hover:bg-neutral-800"
            aria-label="Toggle menu"
          >
            {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {isMobileMenuOpen && (
        <div className="lg:hidden border-b border-neutral-200 dark:border-neutral-800 bg-white/95 dark:bg-neutral-900/95 backdrop-blur-xl px-4 pt-3 pb-6 space-y-4">
          <div className="grid grid-cols-2 gap-2">
            {navLinks.map(link => (
              <button
                key={link.view}
                onClick={() => handleNav(link.view)}
                className={`flex items-center gap-2.5 px-4 py-3 rounded-xl text-sm font-medium text-left ${
                  currentView === link.view
                    ? 'bg-indigo-50 dark:bg-indigo-950/40 text-indigo-600 dark:text-indigo-400 font-semibold'
                    : 'text-neutral-700 dark:text-neutral-300 hover:bg-neutral-100 dark:hover:bg-neutral-800'
                }`}
              >
                {link.icon}
                <span>{link.label}</span>
              </button>
            ))}
          </div>

          <div className="pt-2 border-t border-neutral-200 dark:border-neutral-800 space-y-2">
            {currentUser ? (
              <div className="space-y-2">
                <button
                  onClick={() => handleNav(currentUser.role === 'client' ? 'client-dashboard' : 'designer-dashboard')}
                  className="w-full flex items-center justify-between px-4 py-3 rounded-xl bg-neutral-100 dark:bg-neutral-800 text-sm font-semibold"
                >
                  <div className="flex items-center gap-2">
                    <img src={currentUser.avatar} alt={currentUser.name} className="w-6 h-6 rounded-full" />
                    <span>{currentUser.role === 'client' ? 'Client Dashboard' : 'Designer Studio'}</span>
                  </div>
                  <ArrowUpRight className="w-4 h-4 text-neutral-400" />
                </button>
                <div className="flex gap-2">
                  <button
                    onClick={() => login(currentUser.role === 'client' ? 'designer' : 'client')}
                    className="flex-1 py-2 rounded-lg border border-neutral-300 dark:border-neutral-700 text-xs font-medium text-neutral-700 dark:text-neutral-300"
                  >
                    Switch to {currentUser.role === 'client' ? 'Designer' : 'Client'}
                  </button>
                  <button
                    onClick={logout}
                    className="py-2 px-4 rounded-lg border border-rose-200 dark:border-rose-900 text-xs font-medium text-rose-600"
                  >
                    Logout
                  </button>
                </div>
              </div>
            ) : (
              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={() => handleNav('login')}
                  className="w-full py-2.5 rounded-xl border border-neutral-300 dark:border-neutral-700 text-sm font-semibold text-center"
                >
                  Login
                </button>
                <button
                  onClick={() => handleNav('signup')}
                  className="w-full py-2.5 rounded-xl bg-neutral-900 text-white dark:bg-white dark:text-neutral-900 text-sm font-semibold text-center"
                >
                  Sign Up
                </button>
              </div>
            )}

            <button
              onClick={() => {
                setIsMobileMenuOpen(false);
                openStartProjectModal();
              }}
              className="w-full py-3 rounded-xl bg-indigo-600 text-white text-sm font-semibold flex items-center justify-center gap-2 shadow-md shadow-indigo-600/20"
            >
              <PlusCircle className="w-4 h-4" />
              <span>Start a Project</span>
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
