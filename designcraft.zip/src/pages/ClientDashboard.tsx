import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { ProjectCard } from '../components/cards/ProjectCard';
import { DesignerCard } from '../components/cards/DesignerCard';
import { 
  FolderKanban, 
  Heart, 
  Bookmark, 
  MessageSquare, 
  User as UserIcon, 
  PlusCircle, 
  Clock, 
  DollarSign, 
  Calendar, 
  Send,
  CheckCircle2,
  AlertCircle
} from 'lucide-react';

export const ClientDashboard: React.FC = () => {
  const { 
    currentUser, 
    clientProjects, 
    projects, 
    likedProjectIds, 
    designers, 
    savedDesignerIds, 
    messageThreads, 
    sendMessage,
    openStartProjectModal,
    showToast 
  } = useApp();

  const [activeTab, setActiveTab] = useState<'projects' | 'saved' | 'liked' | 'messages' | 'profile'>('projects');
  const [selectedThreadId, setSelectedThreadId] = useState<string>(messageThreads[0]?.id || '');
  const [replyText, setReplyText] = useState('');

  // Profile fields state
  const [clientName, setClientName] = useState(currentUser?.name || 'Sophia Laurent');
  const [clientCompany, setClientCompany] = useState(currentUser?.company || 'Aura Studio & Co.');

  const savedDesigners = designers.filter(d => savedDesignerIds.has(d.id));
  const likedProjects = projects.filter(p => likedProjectIds.has(p.id));
  const activeThread = messageThreads.find(t => t.id === selectedThreadId) || messageThreads[0];

  const handleSendReply = (e: React.FormEvent) => {
    e.preventDefault();
    if (!replyText.trim() || !activeThread) return;
    sendMessage(activeThread.id, replyText);
    setReplyText('');
  };

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    showToast('Profile Updated', 'Your client details have been saved.', 'success');
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
      {/* Dashboard Top Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-6 sm:p-8 rounded-3xl bg-white dark:bg-neutral-900 border border-neutral-200/80 dark:border-neutral-800/80 shadow-sm">
        <div className="flex items-center gap-4">
          <img
            src={currentUser?.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80'}
            alt="Client Avatar"
            referrerPolicy="no-referrer"
            className="w-16 h-16 rounded-2xl object-cover ring-2 ring-indigo-500/20"
          />
          <div>
            <div className="flex items-center gap-2">
              <h1 className="font-display font-bold text-2xl text-neutral-900 dark:text-white">
                {currentUser?.name || 'Sophia Laurent'}
              </h1>
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-indigo-50 text-indigo-700 dark:bg-indigo-950/50 dark:text-indigo-300 border border-indigo-200 dark:border-indigo-800">
                Client Workspace
              </span>
            </div>
            <p className="text-xs text-neutral-500 dark:text-neutral-400">
              {currentUser?.company || 'Aura Studio & Co.'} • {clientProjects.length} Active Commissions
            </p>
          </div>
        </div>

        <button
          onClick={openStartProjectModal}
          className="px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-xs shadow-md shadow-indigo-600/20 transition-all flex items-center justify-center gap-2"
        >
          <PlusCircle className="w-4 h-4" />
          <span>Create New Project</span>
        </button>
      </div>

      {/* Tabs Navigation */}
      <div className="flex items-center gap-2 border-b border-neutral-200 dark:border-neutral-800 pb-2 overflow-x-auto scrollbar-none">
        <button
          onClick={() => setActiveTab('projects')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-semibold transition-colors ${
            activeTab === 'projects'
              ? 'bg-indigo-600 text-white shadow-sm'
              : 'text-neutral-600 dark:text-neutral-400 hover:bg-neutral-100 dark:hover:bg-neutral-800'
          }`}
        >
          <FolderKanban className="w-4 h-4" />
          <span>Active Projects ({clientProjects.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('saved')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-semibold transition-colors ${
            activeTab === 'saved'
              ? 'bg-indigo-600 text-white shadow-sm'
              : 'text-neutral-600 dark:text-neutral-400 hover:bg-neutral-100 dark:hover:bg-neutral-800'
          }`}
        >
          <Bookmark className="w-4 h-4" />
          <span>Saved Designers ({savedDesigners.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('liked')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-semibold transition-colors ${
            activeTab === 'liked'
              ? 'bg-indigo-600 text-white shadow-sm'
              : 'text-neutral-600 dark:text-neutral-400 hover:bg-neutral-100 dark:hover:bg-neutral-800'
          }`}
        >
          <Heart className="w-4 h-4" />
          <span>Liked Inspirations ({likedProjects.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('messages')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-semibold transition-colors ${
            activeTab === 'messages'
              ? 'bg-indigo-600 text-white shadow-sm'
              : 'text-neutral-600 dark:text-neutral-400 hover:bg-neutral-100 dark:hover:bg-neutral-800'
          }`}
        >
          <MessageSquare className="w-4 h-4" />
          <span>Messages ({messageThreads.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('profile')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-semibold transition-colors ${
            activeTab === 'profile'
              ? 'bg-indigo-600 text-white shadow-sm'
              : 'text-neutral-600 dark:text-neutral-400 hover:bg-neutral-100 dark:hover:bg-neutral-800'
          }`}
        >
          <UserIcon className="w-4 h-4" />
          <span>Client Profile</span>
        </button>
      </div>

      {/* Tab 1: Active Projects */}
      {activeTab === 'projects' && (
        <div className="space-y-4">
          {clientProjects.length > 0 ? (
            <div className="grid grid-cols-1 gap-4">
              {clientProjects.map(proj => (
                <div
                  key={proj.id}
                  className="p-6 rounded-2xl bg-white dark:bg-neutral-900 border border-neutral-200/80 dark:border-neutral-800/80 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-6"
                >
                  <div className="space-y-2 flex-1">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="px-2.5 py-0.5 rounded-md text-[11px] font-semibold bg-neutral-100 dark:bg-neutral-800 text-neutral-700 dark:text-neutral-300">
                        {proj.category}
                      </span>
                      <span className={`px-2.5 py-0.5 rounded-md text-[11px] font-semibold border ${
                        proj.status === 'Completed'
                          ? 'bg-emerald-50 text-emerald-700 border-emerald-200 dark:bg-emerald-950/40 dark:text-emerald-400 dark:border-emerald-800'
                          : proj.status === 'In Progress'
                          ? 'bg-indigo-50 text-indigo-700 border-indigo-200 dark:bg-indigo-950/40 dark:text-indigo-400 dark:border-indigo-800'
                          : 'bg-amber-50 text-amber-700 border-amber-200 dark:bg-amber-950/40 dark:text-amber-400 dark:border-amber-800'
                      }`}>
                        {proj.status}
                      </span>
                    </div>

                    <h3 className="font-display font-bold text-lg text-neutral-900 dark:text-white">
                      {proj.title}
                    </h3>
                    <p className="text-xs text-neutral-600 dark:text-neutral-400 max-w-2xl leading-relaxed">
                      {proj.description}
                    </p>

                    {/* Assigned Designer */}
                    {proj.designerName && (
                      <div className="flex items-center gap-2 pt-1 text-xs text-neutral-500">
                        <span>Assigned Talent:</span>
                        {proj.designerAvatar && (
                          <img src={proj.designerAvatar} alt={proj.designerName} className="w-5 h-5 rounded-full object-cover" />
                        )}
                        <strong className="text-neutral-900 dark:text-white">{proj.designerName}</strong>
                      </div>
                    )}
                  </div>

                  {/* Project metadata */}
                  <div className="flex md:flex-col items-center md:items-end justify-between gap-4 pt-4 md:pt-0 border-t md:border-t-0 border-neutral-100 dark:border-neutral-800">
                    <div className="text-left md:text-right">
                      <div className="text-sm font-extrabold text-neutral-900 dark:text-white">
                        ${proj.budget.toLocaleString()}
                      </div>
                      <div className="text-[11px] text-neutral-400 flex items-center gap-1">
                        <Calendar className="w-3 h-3" /> Due {proj.deadline}
                      </div>
                    </div>

                    <button
                      onClick={() => showToast('Project Workspace', 'Reviewing latest revisions and files...', 'info')}
                      className="px-4 py-2 rounded-xl border border-neutral-300 dark:border-neutral-700 hover:bg-neutral-100 dark:hover:bg-neutral-800 text-xs font-semibold text-neutral-800 dark:text-neutral-200 transition-colors"
                    >
                      View Workspace
                    </button>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="p-12 text-center bg-white dark:bg-neutral-900 rounded-3xl border border-neutral-200 dark:border-neutral-800 space-y-3">
              <FolderKanban className="w-10 h-10 text-neutral-400 mx-auto" />
              <h3 className="font-display font-bold text-lg text-neutral-900 dark:text-white">No active projects yet</h3>
              <p className="text-xs text-neutral-500 max-w-sm mx-auto">
                Ready to begin? Post a brief or directly hire one of our vetted designers.
              </p>
              <button
                onClick={openStartProjectModal}
                className="px-5 py-2.5 rounded-xl bg-indigo-600 text-white text-xs font-semibold"
              >
                Start a Project
              </button>
            </div>
          )}
        </div>
      )}

      {/* Tab 2: Saved Designers */}
      {activeTab === 'saved' && (
        <div>
          {savedDesigners.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {savedDesigners.map(d => (
                <DesignerCard key={d.id} designer={d} />
              ))}
            </div>
          ) : (
            <div className="p-12 text-center bg-white dark:bg-neutral-900 rounded-3xl border border-neutral-200 dark:border-neutral-800 space-y-3">
              <Bookmark className="w-10 h-10 text-neutral-400 mx-auto" />
              <h3 className="font-display font-bold text-lg text-neutral-900 dark:text-white">No saved designers</h3>
              <p className="text-xs text-neutral-500">Bookmark designers you love to quickly reach out to them later.</p>
            </div>
          )}
        </div>
      )}

      {/* Tab 3: Liked Projects */}
      {activeTab === 'liked' && (
        <div>
          {likedProjects.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {likedProjects.map(p => (
                <ProjectCard key={p.id} project={p} />
              ))}
            </div>
          ) : (
            <div className="p-12 text-center bg-white dark:bg-neutral-900 rounded-3xl border border-neutral-200 dark:border-neutral-800 space-y-3">
              <Heart className="w-10 h-10 text-neutral-400 mx-auto" />
              <h3 className="font-display font-bold text-lg text-neutral-900 dark:text-white">No liked designs yet</h3>
              <p className="text-xs text-neutral-500">Explore the discovery feed and tap the heart icon on designs that inspire you.</p>
            </div>
          )}
        </div>
      )}

      {/* Tab 4: Messages */}
      {activeTab === 'messages' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 bg-white dark:bg-neutral-900 rounded-3xl border border-neutral-200/80 dark:border-neutral-800/80 shadow-sm overflow-hidden min-h-[520px]">
          {/* Threads List */}
          <div className="lg:col-span-4 border-r border-neutral-200 dark:border-neutral-800 p-4 space-y-2">
            <h4 className="text-xs font-bold uppercase tracking-wider text-neutral-400 px-3 py-2">
              Conversations
            </h4>
            {messageThreads.map(thread => {
              const isSelected = thread.id === activeThread?.id;
              return (
                <div
                  key={thread.id}
                  onClick={() => setSelectedThreadId(thread.id)}
                  className={`p-3.5 rounded-2xl cursor-pointer transition-colors flex items-start gap-3 ${
                    isSelected
                      ? 'bg-indigo-50 dark:bg-indigo-950/40 border border-indigo-200 dark:border-indigo-800/80'
                      : 'hover:bg-neutral-50 dark:hover:bg-neutral-800 border border-transparent'
                  }`}
                >
                  <img
                    src={thread.participantAvatar}
                    alt={thread.participantName}
                    className="w-10 h-10 rounded-full object-cover shrink-0"
                  />
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between">
                      <h5 className="font-semibold text-xs text-neutral-900 dark:text-white truncate">
                        {thread.participantName}
                      </h5>
                      <span className="text-[10px] text-neutral-400">{thread.lastMessageTime}</span>
                    </div>
                    <p className="text-[11px] text-neutral-500 dark:text-neutral-400 truncate mt-0.5">
                      {thread.lastMessage}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Active Chat Conversation View */}
          <div className="lg:col-span-8 flex flex-col justify-between p-6">
            {activeThread ? (
              <>
                {/* Chat Header */}
                <div className="flex items-center gap-3 pb-4 border-b border-neutral-200 dark:border-neutral-800">
                  <img
                    src={activeThread.participantAvatar}
                    alt={activeThread.participantName}
                    className="w-9 h-9 rounded-full object-cover"
                  />
                  <div>
                    <h4 className="font-bold text-sm text-neutral-900 dark:text-white">
                      {activeThread.participantName}
                    </h4>
                    <p className="text-[11px] text-neutral-500">{activeThread.participantRole}</p>
                  </div>
                </div>

                {/* Messages Feed */}
                <div className="flex-1 overflow-y-auto py-6 space-y-4 max-h-[380px]">
                  {activeThread.messages.map(msg => (
                    <div
                      key={msg.id}
                      className={`flex flex-col ${msg.isOwn ? 'items-end' : 'items-start'}`}
                    >
                      <div
                        className={`max-w-md p-3.5 rounded-2xl text-xs sm:text-sm leading-relaxed ${
                          msg.isOwn
                            ? 'bg-indigo-600 text-white rounded-br-sm'
                            : 'bg-neutral-100 dark:bg-neutral-800 text-neutral-800 dark:text-neutral-200 rounded-bl-sm'
                        }`}
                      >
                        {msg.text}
                      </div>
                      <span className="text-[10px] text-neutral-400 mt-1 px-1">{msg.timestamp}</span>
                    </div>
                  ))}
                </div>

                {/* Message Input Box */}
                <form onSubmit={handleSendReply} className="pt-4 border-t border-neutral-200 dark:border-neutral-800 flex gap-2">
                  <input
                    type="text"
                    value={replyText}
                    onChange={e => setReplyText(e.target.value)}
                    placeholder={`Reply to ${activeThread.participantName}...`}
                    className="flex-1 px-4 py-2.5 rounded-xl border border-neutral-200 dark:border-neutral-700 bg-neutral-50 dark:bg-neutral-800 text-neutral-900 dark:text-white text-xs focus:outline-none focus:border-indigo-500"
                  />
                  <button
                    type="submit"
                    className="px-4 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold transition-colors flex items-center gap-1.5"
                  >
                    <Send className="w-3.5 h-3.5" />
                    <span>Send</span>
                  </button>
                </form>
              </>
            ) : (
              <div className="flex-1 flex items-center justify-center text-xs text-neutral-400">
                Select a conversation thread to view messages.
              </div>
            )}
          </div>
        </div>
      )}

      {/* Tab 5: Client Profile Management */}
      {activeTab === 'profile' && (
        <div className="bg-white dark:bg-neutral-900 p-8 rounded-3xl border border-neutral-200/80 dark:border-neutral-800/80 shadow-sm max-w-2xl space-y-6">
          <div>
            <h3 className="font-display font-bold text-xl text-neutral-900 dark:text-white">
              Client Organization Profile
            </h3>
            <p className="text-xs text-neutral-500">Manage your company credentials and invoicing identity.</p>
          </div>

          <form onSubmit={handleSaveProfile} className="space-y-4">
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-neutral-600 dark:text-neutral-300 mb-1.5">
                Contact Name
              </label>
              <input
                type="text"
                value={clientName}
                onChange={e => setClientName(e.target.value)}
                className="w-full px-4 py-2.5 rounded-xl border border-neutral-300 dark:border-neutral-700 bg-white dark:bg-neutral-800 text-neutral-900 dark:text-white text-sm focus:outline-none focus:border-indigo-500"
              />
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-neutral-600 dark:text-neutral-300 mb-1.5">
                Company / Studio Name
              </label>
              <input
                type="text"
                value={clientCompany}
                onChange={e => setClientCompany(e.target.value)}
                className="w-full px-4 py-2.5 rounded-xl border border-neutral-300 dark:border-neutral-700 bg-white dark:bg-neutral-800 text-neutral-900 dark:text-white text-sm focus:outline-none focus:border-indigo-500"
              />
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-neutral-600 dark:text-neutral-300 mb-1.5">
                Email Address
              </label>
              <input
                type="email"
                disabled
                value={currentUser?.email || 'sophia@laurentstudio.com'}
                className="w-full px-4 py-2.5 rounded-xl border border-neutral-200 dark:border-neutral-800 bg-neutral-100 dark:bg-neutral-850 text-neutral-500 text-sm cursor-not-allowed"
              />
            </div>

            <div className="pt-2">
              <button
                type="submit"
                className="px-6 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold shadow-md shadow-indigo-600/20"
              >
                Save Changes
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
