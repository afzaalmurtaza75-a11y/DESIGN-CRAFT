import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { CategoryType, PortfolioProject } from '../types';
import { 
  BarChart3, 
  FolderPlus, 
  Layers, 
  MessageSquare, 
  Inbox, 
  Settings, 
  Eye, 
  Heart, 
  CheckCircle2, 
  XCircle, 
  Trash2, 
  Send, 
  DollarSign, 
  Sparkles,
  Clock,
  Plus
} from 'lucide-react';

export const DesignerDashboard: React.FC = () => {
  const { 
    currentUser, 
    projects, 
    designers, 
    addDesignerProject, 
    deleteDesignerProject, 
    messageThreads, 
    sendMessage, 
    showToast 
  } = useApp();

  const [activeTab, setActiveTab] = useState<'stats' | 'projects' | 'addProject' | 'requests' | 'messages' | 'profile'>('stats');

  // New Project Form State
  const [newTitle, setNewTitle] = useState('');
  const [newCategory, setNewCategory] = useState<CategoryType>('UI/UX Design');
  const [newImageUrl, setNewImageUrl] = useState('');
  const [newDescription, setNewDescription] = useState('');
  const [newTools, setNewTools] = useState('Figma, React, Tailwind');

  // Messages State
  const [selectedThreadId, setSelectedThreadId] = useState<string>(messageThreads[0]?.id || '');
  const [replyText, setReplyText] = useState('');

  // Find designer profile corresponding to logged in user or first designer
  const designer = designers.find(d => d.id === 'des-1') || designers[0];

  // Inquiries / proposals
  const [proposals, setProposals] = useState([
    {
      id: 'req-1',
      clientName: 'Elena Rostova',
      clientCompany: 'Fintech Pulse Inc.',
      avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=200&q=80',
      projectScope: 'Design complete iOS banking dashboard and dark mode design system.',
      budget: '$4,200',
      timeline: '3 Weeks',
      status: 'Pending'
    },
    {
      id: 'req-2',
      clientName: 'Marcus Bennett',
      clientCompany: 'Nova Audio Labs',
      avatar: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?auto=format&fit=crop&w=200&q=80',
      projectScope: 'Visual identity rebranding, 3D product renders, and interactive web landing.',
      budget: '$6,800',
      timeline: '1 Month',
      status: 'Accepted'
    }
  ]);

  const designerProjects = projects.filter(p => p.designerId === designer.id);
  const totalLikes = designerProjects.reduce((acc, p) => acc + p.likes, 0);
  const totalViews = designerProjects.reduce((acc, p) => acc + p.views, 0);

  const activeThread = messageThreads.find(t => t.id === selectedThreadId) || messageThreads[0];

  const handleCreateProject = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim() || !newImageUrl.trim()) {
      showToast('Validation Error', 'Title and image URL are required.', 'warning');
      return;
    }

    addDesignerProject({
      title: newTitle,
      category: newCategory,
      imageUrl: newImageUrl,
      designerId: designer.id,
      designerName: designer.name,
      designerAvatar: designer.avatar,
      designerTitle: designer.title,
      description: newDescription || 'Newly published creative showcase project on DesignCraft.',
      completionDate: 'Just now',
      toolsUsed: newTools.split(',').map(s => s.trim()),
      deliverables: ['Source files', 'Design guidelines', 'Hi-res preview exports'] as any
    });
    setNewTitle('');
    setNewImageUrl('');
    setNewDescription('');
    setActiveTab('projects');
  };

  const handleSendReply = (e: React.FormEvent) => {
    e.preventDefault();
    if (!replyText.trim() || !activeThread) return;
    sendMessage(activeThread.id, replyText);
    setReplyText('');
  };

  const handleUpdateProposal = (id: string, status: 'Accepted' | 'Declined') => {
    setProposals(prev => prev.map(p => p.id === id ? { ...p, status } : p));
    showToast(`Proposal ${status}`, `You have ${status.toLowerCase()} the client inquiry.`, 'info');
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
      {/* Header Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-6 sm:p-8 rounded-3xl bg-white dark:bg-neutral-900 border border-neutral-200/80 dark:border-neutral-800/80 shadow-sm">
        <div className="flex items-center gap-4">
          <img
            src={designer.avatar}
            alt={designer.name}
            referrerPolicy="no-referrer"
            className="w-16 h-16 rounded-2xl object-cover ring-2 ring-indigo-500/20"
          />
          <div>
            <div className="flex items-center gap-2">
              <h1 className="font-display font-bold text-2xl text-neutral-900 dark:text-white">
                {designer.name}
              </h1>
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-emerald-50 text-emerald-700 dark:bg-emerald-950/50 dark:text-emerald-400 border border-emerald-200 dark:border-emerald-800">
                Verified Creator
              </span>
            </div>
            <p className="text-xs text-neutral-500 dark:text-neutral-400">
              {designer.title} • {designer.location}
            </p>
          </div>
        </div>

        <button
          onClick={() => setActiveTab('addProject')}
          className="px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-xs shadow-md shadow-indigo-600/20 transition-all flex items-center justify-center gap-2"
        >
          <FolderPlus className="w-4 h-4" />
          <span>Add New Work</span>
        </button>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-2 border-b border-neutral-200 dark:border-neutral-800 pb-2 overflow-x-auto scrollbar-none">
        <button
          onClick={() => setActiveTab('stats')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-semibold transition-colors ${
            activeTab === 'stats'
              ? 'bg-indigo-600 text-white shadow-sm'
              : 'text-neutral-600 dark:text-neutral-400 hover:bg-neutral-100 dark:hover:bg-neutral-800'
          }`}
        >
          <BarChart3 className="w-4 h-4" />
          <span>Performance Overview</span>
        </button>

        <button
          onClick={() => setActiveTab('projects')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-semibold transition-colors ${
            activeTab === 'projects'
              ? 'bg-indigo-600 text-white shadow-sm'
              : 'text-neutral-600 dark:text-neutral-400 hover:bg-neutral-100 dark:hover:bg-neutral-800'
          }`}
        >
          <Layers className="w-4 h-4" />
          <span>My Portfolio ({designerProjects.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('addProject')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-semibold transition-colors ${
            activeTab === 'addProject'
              ? 'bg-indigo-600 text-white shadow-sm'
              : 'text-neutral-600 dark:text-neutral-400 hover:bg-neutral-100 dark:hover:bg-neutral-800'
          }`}
        >
          <FolderPlus className="w-4 h-4" />
          <span>Upload Work</span>
        </button>

        <button
          onClick={() => setActiveTab('requests')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-semibold transition-colors ${
            activeTab === 'requests'
              ? 'bg-indigo-600 text-white shadow-sm'
              : 'text-neutral-600 dark:text-neutral-400 hover:bg-neutral-100 dark:hover:bg-neutral-800'
          }`}
        >
          <Inbox className="w-4 h-4" />
          <span>Client Proposals ({proposals.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('messages')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-semibold transition-colors ${
            activeTab === 'messages'
              ? 'bg-indigo-600 text-white shadow-sm'
              : 'text-neutral-600 dark:text-neutral-400 hover:bg-neutral-100 dark:hover:bg-neutral-800'
          }`}
        >
          <MessageSquare className="w-4 h-4" />
          <span>Direct Inquiries</span>
        </button>
      </div>

      {/* Tab 1: Stats & Overview */}
      {activeTab === 'stats' && (
        <div className="space-y-8">
          {/* Stat Metric Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            <div className="p-6 rounded-2xl bg-white dark:bg-neutral-900 border border-neutral-200/80 dark:border-neutral-800/80 shadow-sm space-y-2">
              <span className="text-xs font-semibold text-neutral-500">Total Portfolio Works</span>
              <div className="flex items-baseline justify-between">
                <span className="font-display font-extrabold text-3xl text-neutral-900 dark:text-white">
                  {designerProjects.length}
                </span>
                <span className="text-xs font-semibold text-indigo-600 dark:text-indigo-400">Active</span>
              </div>
            </div>

            <div className="p-6 rounded-2xl bg-white dark:bg-neutral-900 border border-neutral-200/80 dark:border-neutral-800/80 shadow-sm space-y-2">
              <span className="text-xs font-semibold text-neutral-500">Total Portfolio Impressions</span>
              <div className="flex items-baseline justify-between">
                <span className="font-display font-extrabold text-3xl text-neutral-900 dark:text-white">
                  {totalViews.toLocaleString()}
                </span>
                <Eye className="w-4 h-4 text-neutral-400" />
              </div>
            </div>

            <div className="p-6 rounded-2xl bg-white dark:bg-neutral-900 border border-neutral-200/80 dark:border-neutral-800/80 shadow-sm space-y-2">
              <span className="text-xs font-semibold text-neutral-500">Total Community Likes</span>
              <div className="flex items-baseline justify-between">
                <span className="font-display font-extrabold text-3xl text-neutral-900 dark:text-white">
                  {totalLikes.toLocaleString()}
                </span>
                <Heart className="w-4 h-4 text-rose-500 fill-rose-500" />
              </div>
            </div>

            <div className="p-6 rounded-2xl bg-white dark:bg-neutral-900 border border-neutral-200/80 dark:border-neutral-800/80 shadow-sm space-y-2">
              <span className="text-xs font-semibold text-neutral-500">Inbound Client Requests</span>
              <div className="flex items-baseline justify-between">
                <span className="font-display font-extrabold text-3xl text-neutral-900 dark:text-white">
                  {proposals.length}
                </span>
                <span className="text-xs font-semibold text-emerald-600">+2 New</span>
              </div>
            </div>
          </div>

          {/* Tips for Profile Visibility */}
          <div className="p-6 rounded-3xl bg-indigo-50/70 dark:bg-indigo-950/40 border border-indigo-200/80 dark:border-indigo-800/80 flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="space-y-1 text-center sm:text-left">
              <h4 className="font-display font-bold text-base text-neutral-900 dark:text-white">
                💡 Want to reach more high-budget clients?
              </h4>
              <p className="text-xs text-neutral-600 dark:text-neutral-400">
                Designers with at least 5 projects and verified deliverable breakdowns get 3.8x more direct hire inquiries.
              </p>
            </div>
            <button
              onClick={() => setActiveTab('addProject')}
              className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold shrink-0"
            >
              Upload Project
            </button>
          </div>
        </div>
      )}

      {/* Tab 2: Manage Projects */}
      {activeTab === 'projects' && (
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <h3 className="font-display font-bold text-lg text-neutral-900 dark:text-white">
              Your Published Portfolio Pieces
            </h3>
            <button
              onClick={() => setActiveTab('addProject')}
              className="px-3.5 py-1.5 rounded-xl bg-indigo-600 text-white text-xs font-semibold flex items-center gap-1.5"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add New</span>
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {designerProjects.map(proj => (
              <div
                key={proj.id}
                className="bg-white dark:bg-neutral-900 rounded-2xl border border-neutral-200/80 dark:border-neutral-800/80 overflow-hidden shadow-sm flex flex-col justify-between"
              >
                <div>
                  <div className="aspect-[4/3] relative overflow-hidden bg-neutral-100 dark:bg-neutral-800">
                    <img
                      src={proj.imageUrl}
                      alt={proj.title}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover"
                    />
                    <span className="absolute top-3 left-3 px-2 py-0.5 rounded-md text-[10px] font-semibold bg-black/60 text-white backdrop-blur-md">
                      {proj.category}
                    </span>
                  </div>

                  <div className="p-4 space-y-2">
                    <h4 className="font-semibold text-sm text-neutral-900 dark:text-white">
                      {proj.title}
                    </h4>
                    <p className="text-xs text-neutral-500 line-clamp-2">
                      {proj.description}
                    </p>
                    <div className="flex items-center gap-3 text-[11px] text-neutral-400 pt-1">
                      <span>❤️ {proj.likes} likes</span>
                      <span>👁️ {proj.views} views</span>
                    </div>
                  </div>
                </div>

                <div className="p-3 bg-neutral-50 dark:bg-neutral-850/60 border-t border-neutral-100 dark:border-neutral-800 flex items-center justify-between">
                  <span className="text-[11px] text-neutral-400">Published {proj.completionDate || 'Recently'}</span>
                  <button
                    onClick={() => deleteDesignerProject(proj.id)}
                    className="p-1.5 rounded-lg text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-950/40 transition-colors"
                    title="Delete project"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tab 3: Upload / Add Project */}
      {activeTab === 'addProject' && (
        <div className="max-w-2xl mx-auto bg-white dark:bg-neutral-900 p-8 rounded-3xl border border-neutral-200/80 dark:border-neutral-800/80 shadow-sm space-y-6">
          <div>
            <h3 className="font-display font-bold text-xl text-neutral-900 dark:text-white">
              Add New Portfolio Piece
            </h3>
            <p className="text-xs text-neutral-500">
              Share your latest designs with potential clients on the DesignCraft feed.
            </p>
          </div>

          <form onSubmit={handleCreateProject} className="space-y-4">
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-neutral-600 dark:text-neutral-300 mb-1.5">
                Project Title *
              </label>
              <input
                type="text"
                required
                value={newTitle}
                onChange={e => setNewTitle(e.target.value)}
                placeholder="e.g. Lumina SaaS - Dark Mode Analytics"
                className="w-full px-4 py-2.5 rounded-xl border border-neutral-300 dark:border-neutral-700 bg-white dark:bg-neutral-800 text-neutral-900 dark:text-white text-sm focus:outline-none focus:border-indigo-500"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-neutral-600 dark:text-neutral-300 mb-1.5">
                  Category *
                </label>
                <select
                  value={newCategory}
                  onChange={e => setNewCategory(e.target.value as CategoryType)}
                  className="w-full px-4 py-2.5 rounded-xl border border-neutral-300 dark:border-neutral-700 bg-white dark:bg-neutral-800 text-neutral-900 dark:text-white text-sm focus:outline-none focus:border-indigo-500"
                >
                  <option value="UI/UX Design">UI/UX Design</option>
                  <option value="Branding">Branding</option>
                  <option value="Logo Design">Logo Design</option>
                  <option value="Web Design">Web Design</option>
                  <option value="Posters">Posters</option>
                  <option value="Social Media">Social Media</option>
                  <option value="Illustration">Illustration</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-neutral-600 dark:text-neutral-300 mb-1.5">
                  Tools Used
                </label>
                <input
                  type="text"
                  value={newTools}
                  onChange={e => setNewTools(e.target.value)}
                  placeholder="Figma, Illustrator, Spline"
                  className="w-full px-4 py-2.5 rounded-xl border border-neutral-300 dark:border-neutral-700 bg-white dark:bg-neutral-800 text-neutral-900 dark:text-white text-sm focus:outline-none focus:border-indigo-500"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-neutral-600 dark:text-neutral-300 mb-1.5">
                Image URL *
              </label>
              <input
                type="url"
                required
                value={newImageUrl}
                onChange={e => setNewImageUrl(e.target.value)}
                placeholder="https://images.unsplash.com/..."
                className="w-full px-4 py-2.5 rounded-xl border border-neutral-300 dark:border-neutral-700 bg-white dark:bg-neutral-800 text-neutral-900 dark:text-white text-sm focus:outline-none focus:border-indigo-500"
              />
              <p className="text-[11px] text-neutral-400 mt-1">
                Tip: Use Unsplash or your hosted portfolio image link.
              </p>
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-neutral-600 dark:text-neutral-300 mb-1.5">
                Description & Design Context
              </label>
              <textarea
                rows={3}
                value={newDescription}
                onChange={e => setNewDescription(e.target.value)}
                placeholder="Explain the client problem, typographic choices, color theory, or user testing results..."
                className="w-full px-4 py-2.5 rounded-xl border border-neutral-300 dark:border-neutral-700 bg-white dark:bg-neutral-800 text-neutral-900 dark:text-white text-sm focus:outline-none focus:border-indigo-500"
              />
            </div>

            <div className="pt-3">
              <button
                type="submit"
                className="w-full py-3 px-4 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-sm shadow-md shadow-indigo-600/20"
              >
                Publish to DesignCraft
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Tab 4: Client Proposals */}
      {activeTab === 'requests' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-display font-bold text-lg text-neutral-900 dark:text-white">
              Inbound Project Requests
            </h3>
            <span className="text-xs text-neutral-500">{proposals.length} active opportunities</span>
          </div>

          <div className="space-y-4">
            {proposals.map(req => (
              <div
                key={req.id}
                className="p-6 rounded-2xl bg-white dark:bg-neutral-900 border border-neutral-200/80 dark:border-neutral-800/80 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-6"
              >
                <div className="flex items-start gap-4 flex-1">
                  <img
                    src={req.avatar}
                    alt={req.clientName}
                    className="w-12 h-12 rounded-2xl object-cover ring-1 ring-neutral-200 dark:ring-neutral-800 shrink-0"
                  />
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <h4 className="font-bold text-sm text-neutral-900 dark:text-white">{req.clientName}</h4>
                      <span className="text-xs text-neutral-400">({req.clientCompany})</span>
                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        req.status === 'Accepted'
                          ? 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-400'
                          : req.status === 'Declined'
                          ? 'bg-rose-50 text-rose-700 dark:bg-rose-950/40 dark:text-rose-400'
                          : 'bg-amber-50 text-amber-700 dark:bg-amber-950/40 dark:text-amber-400'
                      }`}>
                        {req.status}
                      </span>
                    </div>

                    <p className="text-xs text-neutral-600 dark:text-neutral-300 leading-relaxed max-w-xl">
                      {req.projectScope}
                    </p>

                    <div className="flex items-center gap-4 text-xs font-medium text-neutral-500 pt-1">
                      <span>💰 Offered: <strong className="text-neutral-900 dark:text-white">{req.budget}</strong></span>
                      <span>⏱️ Timeline: {req.timeline}</span>
                    </div>
                  </div>
                </div>

                {req.status === 'Pending' && (
                  <div className="flex items-center gap-2 pt-2 md:pt-0">
                    <button
                      onClick={() => handleUpdateProposal(req.id, 'Declined')}
                      className="px-4 py-2 rounded-xl border border-neutral-300 dark:border-neutral-700 hover:bg-neutral-100 dark:hover:bg-neutral-800 text-xs font-semibold text-neutral-700 dark:text-neutral-300"
                    >
                      Decline
                    </button>
                    <button
                      onClick={() => handleUpdateProposal(req.id, 'Accepted')}
                      className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold shadow-sm"
                    >
                      Accept Proposal
                    </button>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tab 5: Messages */}
      {activeTab === 'messages' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 bg-white dark:bg-neutral-900 rounded-3xl border border-neutral-200/80 dark:border-neutral-800/80 shadow-sm overflow-hidden min-h-[500px]">
          {/* Threads */}
          <div className="lg:col-span-4 border-r border-neutral-200 dark:border-neutral-800 p-4 space-y-2">
            <h4 className="text-xs font-bold uppercase tracking-wider text-neutral-400 px-3 py-2">
              Inquiries
            </h4>
            {messageThreads.map(thread => {
              const isSelected = thread.id === activeThread?.id;
              return (
                <div
                  key={thread.id}
                  onClick={() => setSelectedThreadId(thread.id)}
                  className={`p-3.5 rounded-2xl cursor-pointer transition-colors flex items-start gap-3 ${
                    isSelected
                      ? 'bg-indigo-50 dark:bg-indigo-950/40 border border-indigo-200 dark:border-indigo-800/80'
                      : 'hover:bg-neutral-50 dark:hover:bg-neutral-800 border border-transparent'
                  }`}
                >
                  <img
                    src={thread.participantAvatar}
                    alt={thread.participantName}
                    className="w-10 h-10 rounded-full object-cover shrink-0"
                  />
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between">
                      <h5 className="font-semibold text-xs text-neutral-900 dark:text-white truncate">
                        {thread.participantName}
                      </h5>
                      <span className="text-[10px] text-neutral-400">{thread.lastMessageTime}</span>
                    </div>
                    <p className="text-[11px] text-neutral-500 truncate mt-0.5">
                      {thread.lastMessage}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Conversation */}
          <div className="lg:col-span-8 flex flex-col justify-between p-6">
            {activeThread ? (
              <>
                <div className="flex items-center gap-3 pb-4 border-b border-neutral-200 dark:border-neutral-800">
                  <img
                    src={activeThread.participantAvatar}
                    alt={activeThread.participantName}
                    className="w-9 h-9 rounded-full object-cover"
                  />
                  <div>
                    <h4 className="font-bold text-sm text-neutral-900 dark:text-white">
                      {activeThread.participantName}
                    </h4>
                    <p className="text-[11px] text-neutral-500">{activeThread.participantRole}</p>
                  </div>
                </div>

                <div className="flex-1 overflow-y-auto py-6 space-y-4 max-h-[360px]">
                  {activeThread.messages.map(msg => (
                    <div
                      key={msg.id}
                      className={`flex flex-col ${msg.isOwn ? 'items-end' : 'items-start'}`}
                    >
                      <div
                        className={`max-w-md p-3.5 rounded-2xl text-xs sm:text-sm leading-relaxed ${
                          msg.isOwn
                            ? 'bg-indigo-600 text-white rounded-br-sm'
                            : 'bg-neutral-100 dark:bg-neutral-800 text-neutral-800 dark:text-neutral-200 rounded-bl-sm'
                        }`}
                      >
                        {msg.text}
                      </div>
                      <span className="text-[10px] text-neutral-400 mt-1 px-1">{msg.timestamp}</span>
                    </div>
                  ))}
                </div>

                <form onSubmit={handleSendReply} className="pt-4 border-t border-neutral-200 dark:border-neutral-800 flex gap-2">
                  <input
                    type="text"
                    value={replyText}
                    onChange={e => setReplyText(e.target.value)}
                    placeholder={`Reply to ${activeThread.participantName}...`}
                    className="flex-1 px-4 py-2.5 rounded-xl border border-neutral-200 dark:border-neutral-700 bg-neutral-50 dark:bg-neutral-800 text-neutral-900 dark:text-white text-xs focus:outline-none focus:border-indigo-500"
                  />
                  <button
                    type="submit"
                    className="px-4 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold flex items-center gap-1.5"
                  >
                    <Send className="w-3.5 h-3.5" />
                    <span>Send</span>
                  </button>
                </form>
              </>
            ) : (
              <div className="flex-1 flex items-center justify-center text-xs text-neutral-400">
                Select an inquiry to view conversation.
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
