import React, { useState, useMemo } from 'react';
import { useApp } from '../context/AppContext';
import { CategoryType } from '../types';
import { ProjectCard } from '../components/cards/ProjectCard';
import { Search, SlidersHorizontal, Sparkles, Filter, X } from 'lucide-react';

export const ExplorePage: React.FC = () => {
  const { projects, activeCategoryFilter, setActiveCategoryFilter } = useApp();

  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState<'popular' | 'likes' | 'views' | 'newest'>('popular');

  const categories: (CategoryType | 'All')[] = [
    'All',
    'Logo Design',
    'Branding',
    'UI/UX Design',
    'Web Design',
    'Posters',
    'Social Media',
    'Illustration'
  ];

  const filteredProjects = useMemo(() => {
    return projects
      .filter(project => {
        // Category Filter
        if (activeCategoryFilter !== 'All' && project.category !== activeCategoryFilter) {
          return false;
        }

        // Search Query
        if (searchQuery.trim()) {
          const q = searchQuery.toLowerCase();
          const matchTitle = project.title.toLowerCase().includes(q);
          const matchDesigner = project.designerName.toLowerCase().includes(q);
          const matchCategory = project.category.toLowerCase().includes(q);
          const matchTools = project.toolsUsed?.some(t => t.toLowerCase().includes(q));
          if (!matchTitle && !matchDesigner && !matchCategory && !matchTools) {
            return false;
          }
        }

        return true;
      })
      .sort((a, b) => {
        if (sortBy === 'likes') return b.likes - a.likes;
        if (sortBy === 'views') return b.views - a.views;
        if (sortBy === 'newest') return b.id.localeCompare(a.id);
        // Default popular: likes + views weighting
        return (b.likes * 2 + b.views) - (a.likes * 2 + a.views);
      });
  }, [projects, activeCategoryFilter, searchQuery, sortBy]);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 sm:py-14 space-y-8">
      {/* Header Title */}
      <div className="text-center max-w-2xl mx-auto space-y-3">
        <span className="text-xs font-bold uppercase tracking-wider text-indigo-600 dark:text-indigo-400">
          Inspiration & Discovery
        </span>
        <h1 className="text-3xl sm:text-4xl md:text-5xl font-display font-extrabold text-neutral-900 dark:text-white tracking-tight">
          Explore Outstanding Design
        </h1>
        <p className="text-neutral-600 dark:text-neutral-400 text-sm sm:text-base">
          Browse real client deliverables, concept prototypes, and visual identity systems crafted by top creators.
        </p>
      </div>

      {/* Filter and Search Bar Control Suite */}
      <div className="bg-white dark:bg-neutral-900 p-4 sm:p-5 rounded-2xl border border-neutral-200/80 dark:border-neutral-800/80 shadow-sm space-y-4">
        <div className="flex flex-col md:flex-row gap-3 items-center justify-between">
          {/* Search Bar */}
          <div className="relative w-full md:max-w-md">
            <Search className="w-4 h-4 text-neutral-400 absolute left-3.5 top-3.5" />
            <input
              type="text"
              id="explore-search-input"
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              placeholder="Search by project name, designer, tool, or keyword..."
              className="w-full pl-10 pr-9 py-2.5 rounded-xl border border-neutral-200 dark:border-neutral-700 bg-neutral-50 dark:bg-neutral-800 text-neutral-900 dark:text-white text-sm focus:outline-none focus:border-indigo-500 focus:bg-white dark:focus:bg-neutral-850 transition-all"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-3 text-neutral-400 hover:text-neutral-700 dark:hover:text-neutral-200"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>

          {/* Sort Dropdown & Result Count */}
          <div className="w-full md:w-auto flex items-center justify-between md:justify-end gap-3 text-sm">
            <span className="text-xs text-neutral-500 font-medium">
              Showing <strong className="text-neutral-900 dark:text-white">{filteredProjects.length}</strong> creations
            </span>

            <div className="flex items-center gap-2">
              <SlidersHorizontal className="w-3.5 h-3.5 text-neutral-400" />
              <select
                id="explore-sort-select"
                value={sortBy}
                onChange={e => setSortBy(e.target.value as any)}
                className="px-3 py-2 rounded-xl border border-neutral-200 dark:border-neutral-700 bg-neutral-50 dark:bg-neutral-800 text-neutral-900 dark:text-white text-xs font-semibold focus:outline-none focus:border-indigo-500"
              >
                <option value="popular">Most Popular</option>
                <option value="likes">Most Liked</option>
                <option value="views">Most Viewed</option>
                <option value="newest">Newest Releases</option>
              </select>
            </div>
          </div>
        </div>

        {/* Category Pills Slider */}
        <div className="flex items-center gap-2 overflow-x-auto pb-1 pt-1 scrollbar-none">
          {categories.map(cat => {
            const isSelected = activeCategoryFilter === cat;
            return (
              <button
                key={cat}
                id={`filter-cat-${cat.toLowerCase().replace(/\s+/g, '-')}`}
                onClick={() => setActiveCategoryFilter(cat as CategoryType)}
                className={`px-4 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition-all duration-200 ${
                  isSelected
                    ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/25'
                    : 'bg-neutral-100 dark:bg-neutral-800 text-neutral-600 dark:text-neutral-300 hover:bg-neutral-200/80 dark:hover:bg-neutral-700'
                }`}
              >
                {cat}
              </button>
            );
          })}
        </div>
      </div>

      {/* Portfolio Grid */}
      {filteredProjects.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 animate-in fade-in duration-300">
          {filteredProjects.map(project => (
            <ProjectCard key={project.id} project={project} />
          ))}
        </div>
      ) : (
        /* Empty State */
        <div className="p-12 text-center bg-white dark:bg-neutral-900 rounded-3xl border border-neutral-200/80 dark:border-neutral-800/80 space-y-4 max-w-md mx-auto">
          <div className="w-12 h-12 rounded-2xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-500 flex items-center justify-center mx-auto">
            <Filter className="w-6 h-6" />
          </div>
          <h3 className="font-display font-bold text-lg text-neutral-900 dark:text-white">
            No designs found
          </h3>
          <p className="text-xs text-neutral-500 dark:text-neutral-400">
            We couldn't find any designs matching "{searchQuery}". Try selecting "All" or exploring different keywords.
          </p>
          <button
            onClick={() => {
              setSearchQuery('');
              setActiveCategoryFilter('All');
            }}
            className="px-4 py-2 bg-neutral-900 text-white dark:bg-white dark:text-neutral-900 text-xs font-semibold rounded-xl hover:opacity-90"
          >
            Reset All Filters
          </button>
        </div>
      )}
    </div>
  );
};
