import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { ServiceItem } from '../types';
import { 
  PenTool, 
  Palette, 
  Layout, 
  Globe, 
  Share2, 
  Image as ImageIcon, 
  Check, 
  ArrowRight, 
  Sparkles, 
  HelpCircle,
  ShieldCheck,
  ChevronDown
} from 'lucide-react';

export const ServicesPage: React.FC = () => {
  const { services, openStartProjectModal, navigateTo } = useApp();
  const [expandedServiceId, setExpandedServiceId] = useState<string | null>(null);

  const getServiceIcon = (iconName: string) => {
    switch (iconName) {
      case 'Shapes': return <PenTool className="w-6 h-6" />;
      case 'Palette': return <Palette className="w-6 h-6" />;
      case 'Layout': return <Layout className="w-6 h-6" />;
      case 'Globe': return <Globe className="w-6 h-6" />;
      case 'Share2': return <Share2 className="w-6 h-6" />;
      case 'Image': return <ImageIcon className="w-6 h-6" />;
      default: return <Sparkles className="w-6 h-6" />;
    }
  };

  const faqs = [
    {
      q: 'How does project payment and escrow work?',
      a: 'When you start a project, funds are placed into DesignCraft secure escrow. The designer only receives payout after you review and approve the agreed milestones and final deliverables.'
    },
    {
      q: 'Do I own the full intellectual property copyright for the design?',
      a: 'Yes, 100%. Upon completion and payment release, all copyright, source vector files, and commercial licenses are immediately transferred to you.'
    },
    {
      q: 'Can I request custom service packages and multiple designers?',
      a: 'Absolutely. You can start a custom project brief with custom milestones or hire multiple designers across branding, web, and mobile app UI simultaneously.'
    },
    {
      q: 'What formats and source files do designers provide?',
      a: 'Depending on the service: Figma source files with design tokens, vector files (AI, EPS, SVG), high-res print PDFs (CMYK 300DPI), and WebP/PNG assets.'
    }
  ];

  const handleGetStarted = (service: ServiceItem) => {
    openStartProjectModal();
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 sm:py-16 space-y-16">
      {/* Header */}
      <div className="text-center max-w-2xl mx-auto space-y-3">
        <span className="text-xs font-bold uppercase tracking-wider text-indigo-600 dark:text-indigo-400">
          Professional Design Solutions
        </span>
        <h1 className="text-3xl sm:text-4xl md:text-5xl font-display font-extrabold text-neutral-900 dark:text-white tracking-tight">
          Services Tailored for Modern Brands
        </h1>
        <p className="text-neutral-600 dark:text-neutral-400 text-sm sm:text-base">
          From early-stage brand identity to enterprise product design systems, collaborate with world-class talent with guaranteed delivery.
        </p>
      </div>

      {/* Services Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {services.map(service => {
          const isExpanded = expandedServiceId === service.id;

          return (
            <div
              key={service.id}
              id={`service-card-${service.id}`}
              className={`p-7 rounded-3xl bg-white dark:bg-neutral-900 border transition-all duration-300 flex flex-col justify-between relative shadow-sm hover:shadow-xl ${
                service.popular
                  ? 'border-indigo-500/80 dark:border-indigo-500/80 ring-1 ring-indigo-500/20'
                  : 'border-neutral-200/80 dark:border-neutral-800/80 hover:border-neutral-300 dark:hover:border-neutral-700'
              }`}
            >
              {service.popular && (
                <span className="absolute -top-3 right-6 px-3 py-1 rounded-full bg-indigo-600 text-white text-[11px] font-bold tracking-wide shadow-md">
                  Most Popular
                </span>
              )}

              <div className="space-y-4">
                {/* Icon & Category */}
                <div className="w-12 h-12 rounded-2xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 flex items-center justify-center">
                  {getServiceIcon(service.iconName)}
                </div>

                <div>
                  <h3 className="font-display font-bold text-xl text-neutral-900 dark:text-white">
                    {service.title}
                  </h3>
                  <p className="text-xs text-neutral-500 dark:text-neutral-400 mt-1">
                    {service.category}
                  </p>
                </div>

                <p className="text-xs sm:text-sm text-neutral-600 dark:text-neutral-300 leading-relaxed">
                  {service.description}
                </p>

                {/* Starting price */}
                <div className="pt-2 pb-1 border-y border-neutral-100 dark:border-neutral-800 flex items-baseline justify-between">
                  <span className="text-xs font-semibold text-neutral-500">Starting Price</span>
                  <span className="font-display font-extrabold text-2xl text-indigo-600 dark:text-indigo-400">
                    ${service.startingPrice}
                  </span>
                </div>

                {/* Deliverables Checklist */}
                <div className="space-y-2 pt-1">
                  <span className="text-[11px] font-bold uppercase tracking-wider text-neutral-400">
                    What's typically included:
                  </span>
                  <ul className="space-y-2 text-xs text-neutral-700 dark:text-neutral-300">
                    {service.deliverables.map((d, i) => (
                      <li key={i} className="flex items-start gap-2">
                        <Check className="w-3.5 h-3.5 text-emerald-500 shrink-0 mt-0.5" />
                        <span>{d}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Learn more expandable details */}
                {isExpanded && (
                  <div className="p-3.5 rounded-xl bg-neutral-50 dark:bg-neutral-800 text-xs text-neutral-600 dark:text-neutral-300 space-y-2 animate-in fade-in duration-200">
                    <p className="font-semibold text-neutral-900 dark:text-white">Workflow Timeline:</p>
                    <p>Milestone 1: Creative briefing & concept moodboards</p>
                    <p>Milestone 2: Revision rounds & refinement</p>
                    <p>Milestone 3: Final source handoff & copyright signing</p>
                  </div>
                )}
              </div>

              {/* Action Buttons: Learn More & Get Started */}
              <div className="pt-6 mt-6 border-t border-neutral-100 dark:border-neutral-800 flex items-center gap-3">
                <button
                  type="button"
                  onClick={() => setExpandedServiceId(isExpanded ? null : service.id)}
                  className="py-2.5 px-3 rounded-xl border border-neutral-200 dark:border-neutral-700 hover:bg-neutral-100 dark:hover:bg-neutral-800 text-xs font-semibold text-neutral-700 dark:text-neutral-300 transition-colors"
                >
                  {isExpanded ? 'Show Less' : 'Learn More'}
                </button>

                <button
                  type="button"
                  onClick={() => handleGetStarted(service)}
                  className="flex-1 py-2.5 px-4 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold shadow-md shadow-indigo-600/20 transition-all flex items-center justify-center gap-1.5"
                >
                  <span>Get Started</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* FAQ SECTION */}
      <div className="bg-neutral-50 dark:bg-neutral-900/60 rounded-3xl p-8 sm:p-12 border border-neutral-200/80 dark:border-neutral-800/80 max-w-4xl mx-auto space-y-8">
        <div className="text-center space-y-2">
          <div className="inline-flex items-center gap-1 text-xs font-bold uppercase tracking-wider text-indigo-600 dark:text-indigo-400">
            <HelpCircle className="w-4 h-4" />
            <span>Got Questions?</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-display font-bold text-neutral-900 dark:text-white">
            Frequently Asked Questions
          </h2>
        </div>

        <div className="space-y-4">
          {faqs.map((faq, i) => (
            <div
              key={i}
              className="p-5 rounded-2xl bg-white dark:bg-neutral-850 border border-neutral-200/80 dark:border-neutral-750 space-y-2"
            >
              <h4 className="font-semibold text-sm sm:text-base text-neutral-900 dark:text-white">
                {faq.q}
              </h4>
              <p className="text-xs sm:text-sm text-neutral-600 dark:text-neutral-400 leading-relaxed">
                {faq.a}
              </p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
