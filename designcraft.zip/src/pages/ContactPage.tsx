import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { CategoryType } from '../types';
import { 
  Mail, 
  Phone, 
  MapPin, 
  Clock, 
  Send, 
  CheckCircle2, 
  Sparkles,
  MessageSquare,
  Dribbble,
  Twitter,
  Instagram,
  Linkedin
} from 'lucide-react';

export const ContactPage: React.FC = () => {
  const { showToast } = useApp();

  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [projectType, setProjectType] = useState<CategoryType>('UI/UX Design');
  const [budget, setBudget] = useState('$1,000 - $3,000');
  const [message, setMessage] = useState('');
  const [submitted, setSubmitted] = useState(false);
  const [errors, setErrors] = useState<{ [key: string]: string }>({});

  const validate = () => {
    const errs: { [key: string]: string } = {};
    if (!fullName.trim()) errs.fullName = 'Full Name is required';
    if (!email.trim() || !email.includes('@')) errs.email = 'Valid work email is required';
    if (!message.trim() || message.length < 15) errs.message = 'Please provide a message with at least 15 characters';
    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) {
      showToast('Validation Error', 'Please complete the required fields correctly.', 'warning');
      return;
    }

    setSubmitted(true);
    showToast('Inquiry Received', 'Thank you! Our creative director will respond within 24 hours.', 'success');
  };

  const handleReset = () => {
    setFullName('');
    setEmail('');
    setMessage('');
    setSubmitted(false);
    setErrors({});
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 sm:py-16 space-y-12">
      {/* Header */}
      <div className="text-center max-w-2xl mx-auto space-y-3">
        <span className="text-xs font-bold uppercase tracking-wider text-indigo-600 dark:text-indigo-400">
          Get in Touch
        </span>
        <h1 className="text-3xl sm:text-4xl md:text-5xl font-display font-extrabold text-neutral-900 dark:text-white tracking-tight">
          Let’s Build Something Remarkable
        </h1>
        <p className="text-neutral-600 dark:text-neutral-400 text-sm sm:text-base">
          Have an enterprise inquiry, custom project specification, or need help matching with the right designer? We’re here to help.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
        {/* Contact Info Sidebar */}
        <div className="lg:col-span-5 space-y-6">
          <div className="bg-neutral-900 text-white p-8 rounded-3xl space-y-6 shadow-xl">
            <div className="space-y-2">
              <h3 className="font-display font-bold text-xl text-white">
                Contact Information
              </h3>
              <p className="text-xs text-neutral-400 leading-relaxed">
                Connect with our concierge team directly or drop by our studio hubs.
              </p>
            </div>

            <div className="space-y-4 text-xs sm:text-sm text-neutral-300">
              <div className="flex items-start gap-3">
                <Mail className="w-4 h-4 text-indigo-400 shrink-0 mt-1" />
                <div>
                  <span className="text-[11px] text-neutral-400 uppercase tracking-wider font-semibold block">Inquiries</span>
                  <a href="mailto:hello@designcraft.com" className="hover:text-white font-medium">hello@designcraft.com</a>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <Phone className="w-4 h-4 text-indigo-400 shrink-0 mt-1" />
                <div>
                  <span className="text-[11px] text-neutral-400 uppercase tracking-wider font-semibold block">Direct Line</span>
                  <span className="font-medium">+1 (415) 890-3490</span>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <MapPin className="w-4 h-4 text-indigo-400 shrink-0 mt-1" />
                <div>
                  <span className="text-[11px] text-neutral-400 uppercase tracking-wider font-semibold block">Design Studio</span>
                  <span className="font-medium">550 Montgomery St, Financial District, San Francisco, CA</span>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <Clock className="w-4 h-4 text-indigo-400 shrink-0 mt-1" />
                <div>
                  <span className="text-[11px] text-neutral-400 uppercase tracking-wider font-semibold block">Hours of Operation</span>
                  <span className="font-medium">Mon - Fri: 8:00 AM – 6:00 PM PST</span>
                </div>
              </div>
            </div>

            <div className="pt-4 border-t border-neutral-800">
              <span className="text-[11px] text-neutral-400 uppercase tracking-wider font-semibold block mb-3">
                Follow our Creative Roster
              </span>
              <div className="flex items-center gap-3">
                <a href="https://dribbble.com" target="_blank" rel="noreferrer" className="w-8 h-8 rounded-lg bg-neutral-800 hover:bg-indigo-600 flex items-center justify-center text-neutral-400 hover:text-white transition-colors" aria-label="Dribbble">
                  <Dribbble className="w-3.5 h-3.5" />
                </a>
                <a href="https://twitter.com" target="_blank" rel="noreferrer" className="w-8 h-8 rounded-lg bg-neutral-800 hover:bg-indigo-600 flex items-center justify-center text-neutral-400 hover:text-white transition-colors" aria-label="Twitter">
                  <Twitter className="w-3.5 h-3.5" />
                </a>
                <a href="https://instagram.com" target="_blank" rel="noreferrer" className="w-8 h-8 rounded-lg bg-neutral-800 hover:bg-indigo-600 flex items-center justify-center text-neutral-400 hover:text-white transition-colors" aria-label="Instagram">
                  <Instagram className="w-3.5 h-3.5" />
                </a>
                <a href="https://linkedin.com" target="_blank" rel="noreferrer" className="w-8 h-8 rounded-lg bg-neutral-800 hover:bg-indigo-600 flex items-center justify-center text-neutral-400 hover:text-white transition-colors" aria-label="LinkedIn">
                  <Linkedin className="w-3.5 h-3.5" />
                </a>
              </div>
            </div>
          </div>
        </div>

        {/* Contact Form */}
        <div className="lg:col-span-7">
          <div className="bg-white dark:bg-neutral-900 p-8 sm:p-10 rounded-3xl border border-neutral-200/80 dark:border-neutral-800/80 shadow-sm">
            {submitted ? (
              <div className="text-center py-12 space-y-4 animate-in fade-in duration-300">
                <div className="w-16 h-16 rounded-full bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 flex items-center justify-center mx-auto shadow-inner">
                  <CheckCircle2 className="w-8 h-8" />
                </div>
                <h3 className="font-display font-bold text-2xl text-neutral-900 dark:text-white">
                  Message Dispatched!
                </h3>
                <p className="text-sm text-neutral-600 dark:text-neutral-400 max-w-md mx-auto leading-relaxed">
                  Thank you for reaching out, <strong>{fullName}</strong>. A DesignCraft client director will review your brief and follow up with you at <strong>{email}</strong> shortly.
                </p>
                <div className="pt-4">
                  <button
                    onClick={handleReset}
                    className="px-6 py-2.5 rounded-xl border border-neutral-300 dark:border-neutral-700 hover:bg-neutral-100 dark:hover:bg-neutral-800 text-xs font-semibold text-neutral-800 dark:text-neutral-200"
                  >
                    Send Another Message
                  </button>
                </div>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-5">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-bold uppercase tracking-wider text-neutral-600 dark:text-neutral-300 mb-1.5">
                      Full Name *
                    </label>
                    <input
                      type="text"
                      id="contact-fullname"
                      value={fullName}
                      onChange={e => {
                        setFullName(e.target.value);
                        if (errors.fullName) setErrors(prev => ({ ...prev, fullName: '' }));
                      }}
                      placeholder="e.g. Jordan Hayes"
                      className={`w-full px-4 py-2.5 rounded-xl border bg-white dark:bg-neutral-800 text-neutral-900 dark:text-white text-sm focus:outline-none transition-all ${
                        errors.fullName 
                          ? 'border-rose-500 focus:ring-1 focus:ring-rose-500' 
                          : 'border-neutral-300 dark:border-neutral-700 focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500'
                      }`}
                    />
                    {errors.fullName && (
                      <p className="text-[11px] text-rose-500 mt-1 font-medium">{errors.fullName}</p>
                    )}
                  </div>

                  <div>
                    <label className="block text-xs font-bold uppercase tracking-wider text-neutral-600 dark:text-neutral-300 mb-1.5">
                      Work Email *
                    </label>
                    <input
                      type="email"
                      id="contact-email"
                      value={email}
                      onChange={e => {
                        setEmail(e.target.value);
                        if (errors.email) setErrors(prev => ({ ...prev, email: '' }));
                      }}
                      placeholder="e.g. jordan@ventures.com"
                      className={`w-full px-4 py-2.5 rounded-xl border bg-white dark:bg-neutral-800 text-neutral-900 dark:text-white text-sm focus:outline-none transition-all ${
                        errors.email 
                          ? 'border-rose-500 focus:ring-1 focus:ring-rose-500' 
                          : 'border-neutral-300 dark:border-neutral-700 focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500'
                      }`}
                    />
                    {errors.email && (
                      <p className="text-[11px] text-rose-500 mt-1 font-medium">{errors.email}</p>
                    )}
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-bold uppercase tracking-wider text-neutral-600 dark:text-neutral-300 mb-1.5">
                      Project Type
                    </label>
                    <select
                      id="contact-project-type"
                      value={projectType}
                      onChange={e => setProjectType(e.target.value as CategoryType)}
                      className="w-full px-4 py-2.5 rounded-xl border border-neutral-300 dark:border-neutral-700 bg-white dark:bg-neutral-800 text-neutral-900 dark:text-white text-sm focus:outline-none focus:border-indigo-500"
                    >
                      <option value="UI/UX Design">UI/UX & Product Design</option>
                      <option value="Branding">Brand Identity & Rebrand</option>
                      <option value="Logo Design">Logo & Wordmark</option>
                      <option value="Web Design">Web & Marketing Site</option>
                      <option value="Social Media">Social Media Creative Kit</option>
                      <option value="Posters">Poster & Editorial Print</option>
                      <option value="Illustration">Custom Illustration</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-bold uppercase tracking-wider text-neutral-600 dark:text-neutral-300 mb-1.5">
                      Target Budget
                    </label>
                    <select
                      id="contact-budget"
                      value={budget}
                      onChange={e => setBudget(e.target.value)}
                      className="w-full px-4 py-2.5 rounded-xl border border-neutral-300 dark:border-neutral-700 bg-white dark:bg-neutral-800 text-neutral-900 dark:text-white text-sm focus:outline-none focus:border-indigo-500"
                    >
                      <option value="< $1,000">&lt; $1,000 (Small sprint)</option>
                      <option value="$1,000 - $3,000">$1,000 - $3,000 (Standard MVP)</option>
                      <option value="$3,000 - $8,000">$3,000 - $8,000 (Comprehensive rebrand)</option>
                      <option value="$8,000+">$8,000+ (Enterprise Design System)</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-neutral-600 dark:text-neutral-300 mb-1.5">
                    Your Message *
                  </label>
                  <textarea
                    id="contact-message"
                    rows={4}
                    value={message}
                    onChange={e => {
                      setMessage(e.target.value);
                      if (errors.message) setErrors(prev => ({ ...prev, message: '' }));
                    }}
                    placeholder="Tell us about your venture, what you aim to achieve, timeline requirements, or any specific inspirations..."
                    className={`w-full px-4 py-2.5 rounded-xl border bg-white dark:bg-neutral-800 text-neutral-900 dark:text-white text-sm focus:outline-none transition-all ${
                      errors.message 
                        ? 'border-rose-500 focus:ring-1 focus:ring-rose-500' 
                        : 'border-neutral-300 dark:border-neutral-700 focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500'
                    }`}
                  ></textarea>
                  {errors.message && (
                    <p className="text-[11px] text-rose-500 mt-1 font-medium">{errors.message}</p>
                  )}
                </div>

                <button
                  type="submit"
                  id="contact-submit-btn"
                  className="w-full py-3 px-6 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-sm shadow-md shadow-indigo-600/20 hover:shadow-indigo-600/30 transition-all flex items-center justify-center gap-2"
                >
                  <Send className="w-4 h-4" />
                  <span>Send Message</span>
                </button>
              </form>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
