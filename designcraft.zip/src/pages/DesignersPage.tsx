import React, { useState, useMemo } from 'react';
import { useApp } from '../context/AppContext';
import { CategoryType } from '../types';
import { DesignerCard } from '../components/cards/DesignerCard';
import { Search, Star, Filter, X, Users } from 'lucide-react';

export const DesignersPage: React.FC = () => {
  const { designers } = useApp();

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<CategoryType | 'All'>('All');
  const [selectedSkill, setSelectedSkill] = useState<string>('All');
  const [minRating, setMinRating] = useState<number>(0);

  const categories: (CategoryType | 'All')[] = [
    'All',
    'UI/UX Design',
    'Branding',
    'Web Design',
    'Logo Design',
    'Social Media',
    'Posters',
    'Illustration'
  ];

  // Extract unique skills across designers
  const allSkills = useMemo(() => {
    const set = new Set<string>();
    designers.forEach(d => d.skills.forEach(s => set.add(s)));
    return ['All', ...Array.from(set)];
  }, [designers]);

  const filteredDesigners = useMemo(() => {
    return designers.filter(d => {
      // Category
      if (selectedCategory !== 'All' && d.category !== selectedCategory) {
        return false;
      }

      // Skill
      if (selectedSkill !== 'All' && !d.skills.includes(selectedSkill)) {
        return false;
      }

      // Rating
      if (minRating > 0 && d.rating < minRating) {
        return false;
      }

      // Search Query
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchName = d.name.toLowerCase().includes(q);
        const matchTitle = d.title.toLowerCase().includes(q);
        const matchBio = d.bio.toLowerCase().includes(q);
        const matchLocation = d.location.toLowerCase().includes(q);
        const matchSkills = d.skills.some(s => s.toLowerCase().includes(q));
        if (!matchName && !matchTitle && !matchBio && !matchLocation && !matchSkills) {
          return false;
        }
      }

      return true;
    });
  }, [designers, selectedCategory, selectedSkill, minRating, searchQuery]);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 sm:py-14 space-y-8">
      {/* Header */}
      <div className="text-center max-w-2xl mx-auto space-y-3">
        <span className="text-xs font-bold uppercase tracking-wider text-indigo-600 dark:text-indigo-400">
          World-Class Talent
        </span>
        <h1 className="text-3xl sm:text-4xl md:text-5xl font-display font-extrabold text-neutral-900 dark:text-white tracking-tight">
          Find Your Next Creative Partner
        </h1>
        <p className="text-neutral-600 dark:text-neutral-400 text-sm sm:text-base">
          Browse vetted graphic and product designers ready to elevate your brand identity, web experience, and product interfaces.
        </p>
      </div>

      {/* Filter Suite */}
      <div className="bg-white dark:bg-neutral-900 p-5 rounded-2xl border border-neutral-200/80 dark:border-neutral-800/80 shadow-sm space-y-4">
        {/* Search Row */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-3 items-center">
          <div className="md:col-span-6 relative">
            <Search className="w-4 h-4 text-neutral-400 absolute left-3.5 top-3.5" />
            <input
              type="text"
              id="designers-search-input"
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              placeholder="Search by name, skill, title, or location..."
              className="w-full pl-10 pr-9 py-2.5 rounded-xl border border-neutral-200 dark:border-neutral-700 bg-neutral-50 dark:bg-neutral-800 text-neutral-900 dark:text-white text-sm focus:outline-none focus:border-indigo-500 transition-all"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-3 text-neutral-400 hover:text-neutral-700 dark:hover:text-neutral-200"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>

          {/* Skill Filter */}
          <div className="md:col-span-3">
            <select
              value={selectedSkill}
              onChange={e => setSelectedSkill(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-xl border border-neutral-200 dark:border-neutral-700 bg-neutral-50 dark:bg-neutral-800 text-neutral-900 dark:text-white text-xs font-semibold focus:outline-none focus:border-indigo-500"
            >
              <option value="All">All Skills & Software</option>
              {allSkills.filter(s => s !== 'All').map(skill => (
                <option key={skill} value={skill}>{skill}</option>
              ))}
            </select>
          </div>

          {/* Rating Filter */}
          <div className="md:col-span-3">
            <select
              value={minRating}
              onChange={e => setMinRating(Number(e.target.value))}
              className="w-full px-3.5 py-2.5 rounded-xl border border-neutral-200 dark:border-neutral-700 bg-neutral-50 dark:bg-neutral-800 text-neutral-900 dark:text-white text-xs font-semibold focus:outline-none focus:border-indigo-500"
            >
              <option value="0">All Ratings</option>
              <option value="4.9">★ 4.9 & Above</option>
              <option value="4.95">★ 4.95+ Top Tier</option>
            </select>
          </div>
        </div>

        {/* Category Pills */}
        <div className="flex items-center gap-2 overflow-x-auto pb-1 pt-1 scrollbar-none">
          {categories.map(cat => {
            const isSelected = selectedCategory === cat;
            return (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all duration-200 ${
                  isSelected
                    ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/25'
                    : 'bg-neutral-100 dark:bg-neutral-800 text-neutral-600 dark:text-neutral-300 hover:bg-neutral-200/80 dark:hover:bg-neutral-700'
                }`}
              >
                {cat}
              </button>
            );
          })}
        </div>
      </div>

      {/* Grid of Designers */}
      {filteredDesigners.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 animate-in fade-in duration-300">
          {filteredDesigners.map(designer => (
            <DesignerCard key={designer.id} designer={designer} />
          ))}
        </div>
      ) : (
        <div className="p-12 text-center bg-white dark:bg-neutral-900 rounded-3xl border border-neutral-200/80 dark:border-neutral-800/80 space-y-4 max-w-md mx-auto">
          <div className="w-12 h-12 rounded-2xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-500 flex items-center justify-center mx-auto">
            <Users className="w-6 h-6" />
          </div>
          <h3 className="font-display font-bold text-lg text-neutral-900 dark:text-white">
            No designers match your filter
          </h3>
          <p className="text-xs text-neutral-500 dark:text-neutral-400">
            Try adjusting your search criteria or reset filters to see all vetted talent.
          </p>
          <button
            onClick={() => {
              setSearchQuery('');
              setSelectedCategory('All');
              setSelectedSkill('All');
              setMinRating(0);
            }}
            className="px-4 py-2 bg-neutral-900 text-white dark:bg-white dark:text-neutral-900 text-xs font-semibold rounded-xl hover:opacity-90"
          >
            Reset Filters
          </button>
        </div>
      )}
    </div>
  );
};
