import React from 'react';
import { useApp } from '../context/AppContext';
import { 
  Sparkles, 
  Target, 
  ShieldCheck, 
  Heart, 
  Compass, 
  Users, 
  ArrowRight,
  Award,
  Globe2
} from 'lucide-react';

export const AboutPage: React.FC = () => {
  const { navigateTo, openStartProjectModal } = useApp();

  const values = [
    {
      title: 'Craftsmanship First',
      desc: 'We curate designers based on rigor, typography sensitivity, and real-world execution — never algorithmic mass production.',
      icon: <Award className="w-5 h-5 text-indigo-500" />
    },
    {
      title: 'Radical Transparency',
      desc: 'Clear upfront pricing, milestone escrow protections, and direct communication without bureaucratic middle-layers.',
      icon: <ShieldCheck className="w-5 h-5 text-emerald-500" />
    },
    {
      title: '100% IP Ownership',
      desc: 'Clients receive unencumbered worldwide commercial copyright and full source files upon project milestone completion.',
      icon: <Target className="w-5 h-5 text-amber-500" />
    },
    {
      title: 'Global Perspectives',
      desc: 'Connecting clients with leading talent across 45+ countries, bringing diverse cultural nuance to every visual system.',
      icon: <Globe2 className="w-5 h-5 text-purple-500" />
    }
  ];

  const leadership = [
    {
      name: 'Alexander Ward',
      role: 'Co-Founder & Head of Curation',
      bio: 'Former Creative Director at Pentagram & Design Lead at Stripe.',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=200&q=80'
    },
    {
      name: 'Maya Lin-Kowalski',
      role: 'Co-Founder & CEO',
      bio: 'Serial design-tech entrepreneur, passionate about equitable creator economies.',
      avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=200&q=80'
    },
    {
      name: 'Devon Takahashi',
      role: 'Head of Product & Experience',
      bio: 'Leading design systems and community feedback loops across our creative network.',
      avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=200&q=80'
    }
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 sm:py-16 space-y-20">
      {/* Story Hero */}
      <div className="text-center max-w-3xl mx-auto space-y-5">
        <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-indigo-50 dark:bg-indigo-950/60 border border-indigo-200/80 dark:border-indigo-800/80 text-indigo-700 dark:text-indigo-300 text-xs font-semibold">
          <Sparkles className="w-3.5 h-3.5" /> Our Mission & Vision
        </span>
        <h1 className="text-3xl sm:text-5xl font-display font-extrabold text-neutral-900 dark:text-white tracking-tight leading-tight">
          Elevating design from a commodity into a strategic advantage.
        </h1>
        <p className="text-neutral-600 dark:text-neutral-400 text-base sm:text-lg leading-relaxed">
          DesignCraft was founded on a simple conviction: generic gig platforms failed both ambitious founders and serious creative professionals. We built a curated ecosystem where craft is respected, compensation is fair, and collaboration is seamless.
        </p>
      </div>

      {/* Stats Counter Strip */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-6 p-8 rounded-3xl bg-neutral-900 text-white shadow-xl">
        <div className="space-y-1 text-center">
          <div className="font-display font-extrabold text-3xl sm:text-4xl text-indigo-400">15,000+</div>
          <div className="text-xs text-neutral-400 uppercase tracking-wider font-semibold">Designs Delivered</div>
        </div>
        <div className="space-y-1 text-center">
          <div className="font-display font-extrabold text-3xl sm:text-4xl text-white">99.4%</div>
          <div className="text-xs text-neutral-400 uppercase tracking-wider font-semibold">Client Satisfaction</div>
        </div>
        <div className="space-y-1 text-center">
          <div className="font-display font-extrabold text-3xl sm:text-4xl text-indigo-400">4,500+</div>
          <div className="text-xs text-neutral-400 uppercase tracking-wider font-semibold">Vetted Designers</div>
        </div>
        <div className="space-y-1 text-center">
          <div className="font-display font-extrabold text-3xl sm:text-4xl text-white">$18M+</div>
          <div className="text-xs text-neutral-400 uppercase tracking-wider font-semibold">Paid to Creatives</div>
        </div>
      </div>

      {/* Values Grid */}
      <div className="space-y-8">
        <div className="text-center max-w-xl mx-auto space-y-2">
          <span className="text-xs font-bold uppercase tracking-wider text-indigo-600 dark:text-indigo-400">
            Guiding Principles
          </span>
          <h2 className="text-3xl font-display font-bold text-neutral-900 dark:text-white">
            What We Stand For
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {values.map((v, i) => (
            <div
              key={i}
              className="p-7 rounded-3xl bg-white dark:bg-neutral-900 border border-neutral-200/80 dark:border-neutral-800/80 shadow-sm space-y-3"
            >
              <div className="w-11 h-11 rounded-2xl bg-neutral-100 dark:bg-neutral-800 flex items-center justify-center">
                {v.icon}
              </div>
              <h3 className="font-display font-bold text-lg text-neutral-900 dark:text-white">
                {v.title}
              </h3>
              <p className="text-xs sm:text-sm text-neutral-600 dark:text-neutral-400 leading-relaxed">
                {v.desc}
              </p>
            </div>
          ))}
        </div>
      </div>

      {/* Team */}
      <div className="space-y-8">
        <div className="text-center max-w-xl mx-auto space-y-2">
          <span className="text-xs font-bold uppercase tracking-wider text-indigo-600 dark:text-indigo-400">
            The Collective
          </span>
          <h2 className="text-3xl font-display font-bold text-neutral-900 dark:text-white">
            Curated by Designers, for Designers
          </h2>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
          {leadership.map(member => (
            <div
              key={member.name}
              className="p-6 rounded-3xl bg-white dark:bg-neutral-900 border border-neutral-200/80 dark:border-neutral-800/80 text-center space-y-3 shadow-sm"
            >
              <img
                src={member.avatar}
                alt={member.name}
                referrerPolicy="no-referrer"
                className="w-20 h-20 rounded-2xl object-cover mx-auto ring-2 ring-indigo-500/20"
              />
              <div>
                <h4 className="font-display font-bold text-base text-neutral-900 dark:text-white">
                  {member.name}
                </h4>
                <p className="text-xs text-indigo-600 dark:text-indigo-400 font-semibold">
                  {member.role}
                </p>
              </div>
              <p className="text-xs text-neutral-500 dark:text-neutral-400 leading-relaxed">
                {member.bio}
              </p>
            </div>
          ))}
        </div>
      </div>

      {/* Bottom Action Banner */}
      <div className="p-8 sm:p-12 rounded-3xl bg-indigo-50 dark:bg-indigo-950/40 border border-indigo-200/80 dark:border-indigo-800/80 flex flex-col sm:flex-row items-center justify-between gap-6">
        <div className="space-y-2 text-center sm:text-left">
          <h3 className="font-display font-bold text-2xl text-neutral-900 dark:text-white">
            Ready to bring your vision to life?
          </h3>
          <p className="text-sm text-neutral-600 dark:text-neutral-300">
            Start a project today or join our vetted roster of international designers.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => navigateTo('signup')}
            className="px-5 py-2.5 rounded-xl border border-neutral-300 dark:border-neutral-700 bg-white dark:bg-neutral-900 font-semibold text-xs text-neutral-900 dark:text-white hover:bg-neutral-50"
          >
            Apply as Designer
          </button>
          <button
            onClick={openStartProjectModal}
            className="px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-xs shadow-md shadow-indigo-600/20"
          >
            Start a Project
          </button>
        </div>
      </div>
    </div>
  );
};
