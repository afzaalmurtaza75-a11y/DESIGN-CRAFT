import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { ProjectCard } from '../components/cards/ProjectCard';
import { 
  Star, 
  MapPin, 
  CheckCircle, 
  Bookmark, 
  MessageSquare, 
  UserCheck, 
  Globe, 
  Briefcase, 
  Calendar, 
  ExternalLink,
  DollarSign,
  Share2,
  ArrowLeft,
  ShieldCheck,
  Check
} from 'lucide-react';

export const DesignerProfilePage: React.FC = () => {
  const { 
    selectedDesignerId, 
    designers, 
    projects, 
    navigateTo, 
    openHireModal, 
    savedDesignerIds, 
    toggleSaveDesigner, 
    startMessageWithDesigner,
    showToast 
  } = useApp();

  const [activeTab, setActiveTab] = useState<'portfolio' | 'services' | 'reviews' | 'about'>('portfolio');

  // Find designer (default to des-1 if none selected)
  const designer = designers.find(d => d.id === selectedDesignerId) || designers[0];
  const isSaved = savedDesignerIds.has(designer.id);

  // Projects created by this designer
  const designerProjects = projects.filter(p => p.designerId === designer.id);

  const handleShare = () => {
    navigator.clipboard?.writeText(window.location.href);
    showToast('Link Copied', `${designer.name}'s profile link copied!`, 'info');
  };

  const handleContact = () => {
    startMessageWithDesigner(designer, `Hi ${designer.name}, I loved your portfolio on DesignCraft and would like to discuss a project.`);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Back button */}
      <button
        onClick={() => navigateTo('designers')}
        className="inline-flex items-center gap-1.5 text-xs font-semibold text-neutral-500 hover:text-neutral-900 dark:hover:text-white transition-colors"
      >
        <ArrowLeft className="w-4 h-4" />
        <span>Back to Designers</span>
      </button>

      {/* Cover and Profile Header Card */}
      <div className="bg-white dark:bg-neutral-900 rounded-3xl border border-neutral-200/80 dark:border-neutral-800/80 shadow-sm overflow-hidden">
        {/* Cover Banner */}
        <div className="h-48 sm:h-64 w-full relative overflow-hidden bg-neutral-800">
          <img
            src={designer.coverImage}
            alt={designer.name}
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />

          <div className="absolute top-4 right-4 flex items-center gap-2">
            <button
              onClick={handleShare}
              className="p-2.5 rounded-full bg-black/40 hover:bg-black/60 text-white backdrop-blur-md transition-colors"
              title="Share profile"
            >
              <Share2 className="w-4 h-4" />
            </button>
            <button
              onClick={() => toggleSaveDesigner(designer.id)}
              className={`p-2.5 rounded-full backdrop-blur-md transition-colors ${
                isSaved ? 'bg-indigo-600 text-white' : 'bg-black/40 hover:bg-black/60 text-white'
              }`}
              title={isSaved ? 'Saved' : 'Save designer'}
            >
              <Bookmark className={`w-4 h-4 ${isSaved ? 'fill-white' : ''}`} />
            </button>
          </div>
        </div>

        {/* Profile Info Row */}
        <div className="px-6 sm:px-10 pb-8 pt-0">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 -mt-16 sm:-mt-20 mb-6">
            {/* Avatar & Identifiers */}
            <div className="flex flex-col sm:flex-row items-center sm:items-end gap-5 text-center sm:text-left">
              <div className="relative">
                <img
                  src={designer.avatar}
                  alt={designer.name}
                  referrerPolicy="no-referrer"
                  className="w-28 h-28 sm:w-32 sm:h-32 rounded-3xl object-cover ring-4 ring-white dark:ring-neutral-900 shadow-xl bg-white dark:bg-neutral-800"
                />
                {designer.verified && (
                  <span className="absolute -bottom-1.5 -right-1.5 p-1 rounded-full bg-white dark:bg-neutral-900 shadow">
                    <CheckCircle className="w-5 h-5 text-indigo-600 fill-indigo-600/10" />
                  </span>
                )}
              </div>

              <div className="space-y-1">
                <div className="flex items-center justify-center sm:justify-start gap-2">
                  <h1 className="font-display font-extrabold text-2xl sm:text-3xl text-neutral-900 dark:text-white">
                    {designer.name}
                  </h1>
                  <span className="text-xs text-neutral-400 font-mono">{designer.handle}</span>
                </div>
                <p className="text-sm font-medium text-neutral-600 dark:text-neutral-300">
                  {designer.title}
                </p>
                <div className="flex items-center justify-center sm:justify-start gap-3 text-xs text-neutral-500 dark:text-neutral-400 pt-1">
                  <span className="flex items-center gap-1">
                    <MapPin className="w-3.5 h-3.5 text-neutral-400" /> {designer.location}
                  </span>
                  <span>•</span>
                  <span className="inline-flex items-center gap-1 text-emerald-600 dark:text-emerald-400 font-semibold">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                    Available for projects
                  </span>
                </div>
              </div>
            </div>

            {/* Action Buttons: Hire & Contact */}
            <div className="flex items-center justify-center gap-3">
              <button
                id="profile-contact-btn"
                onClick={handleContact}
                className="px-5 py-2.5 rounded-xl border border-neutral-300 dark:border-neutral-700 hover:bg-neutral-100 dark:hover:bg-neutral-800 text-neutral-900 dark:text-white font-semibold text-sm transition-colors flex items-center gap-2"
              >
                <MessageSquare className="w-4 h-4 text-neutral-500" />
                <span>Message</span>
              </button>

              <button
                id="profile-hire-btn"
                onClick={() => openHireModal(designer)}
                className="px-6 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-sm shadow-md shadow-indigo-600/20 hover:shadow-indigo-600/30 transition-all flex items-center gap-2"
              >
                <UserCheck className="w-4 h-4" />
                <span>Hire Designer</span>
              </button>
            </div>
          </div>

          {/* Stats strip */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 p-4 rounded-2xl bg-neutral-50 dark:bg-neutral-850/60 border border-neutral-200/80 dark:border-neutral-800/80">
            <div className="text-center sm:text-left sm:pl-3">
              <div className="flex items-center justify-center sm:justify-start gap-1 text-base font-extrabold text-neutral-900 dark:text-white">
                <Star className="w-4 h-4 text-amber-500 fill-amber-500" />
                <span>{designer.rating}</span>
              </div>
              <p className="text-[11px] text-neutral-500 font-medium">({designer.reviewCount} client reviews)</p>
            </div>

            <div className="text-center sm:text-left">
              <div className="text-base font-extrabold text-neutral-900 dark:text-white">
                {designer.completedProjects}+
              </div>
              <p className="text-[11px] text-neutral-500 font-medium">Completed Projects</p>
            </div>

            <div className="text-center sm:text-left">
              <div className="text-base font-extrabold text-indigo-600 dark:text-indigo-400">
                ${designer.startingPrice}
              </div>
              <p className="text-[11px] text-neutral-500 font-medium">Starting Project Rate</p>
            </div>

            <div className="text-center sm:text-left">
              <div className="text-base font-extrabold text-neutral-900 dark:text-white">
                ${designer.hourlyRate}/hr
              </div>
              <p className="text-[11px] text-neutral-500 font-medium">Hourly Consultation</p>
            </div>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="px-6 sm:px-10 border-t border-neutral-200 dark:border-neutral-800 flex items-center gap-6 overflow-x-auto scrollbar-none">
          <button
            onClick={() => setActiveTab('portfolio')}
            className={`py-4 text-sm font-semibold border-b-2 transition-colors whitespace-nowrap ${
              activeTab === 'portfolio'
                ? 'border-indigo-600 text-indigo-600 dark:text-indigo-400'
                : 'border-transparent text-neutral-500 hover:text-neutral-900 dark:hover:text-white'
            }`}
          >
            Portfolio Showcase ({designerProjects.length})
          </button>

          <button
            onClick={() => setActiveTab('services')}
            className={`py-4 text-sm font-semibold border-b-2 transition-colors whitespace-nowrap ${
              activeTab === 'services'
                ? 'border-indigo-600 text-indigo-600 dark:text-indigo-400'
                : 'border-transparent text-neutral-500 hover:text-neutral-900 dark:hover:text-white'
            }`}
          >
            Services & Packages ({designer.services.length})
          </button>

          <button
            onClick={() => setActiveTab('reviews')}
            className={`py-4 text-sm font-semibold border-b-2 transition-colors whitespace-nowrap ${
              activeTab === 'reviews'
                ? 'border-indigo-600 text-indigo-600 dark:text-indigo-400'
                : 'border-transparent text-neutral-500 hover:text-neutral-900 dark:hover:text-white'
            }`}
          >
            Client Reviews ({designer.reviews.length})
          </button>

          <button
            onClick={() => setActiveTab('about')}
            className={`py-4 text-sm font-semibold border-b-2 transition-colors whitespace-nowrap ${
              activeTab === 'about'
                ? 'border-indigo-600 text-indigo-600 dark:text-indigo-400'
                : 'border-transparent text-neutral-500 hover:text-neutral-900 dark:hover:text-white'
            }`}
          >
            About & Philosophy
          </button>
        </div>
      </div>

      {/* Tab Contents */}
      {activeTab === 'portfolio' && (
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <h3 className="font-display font-bold text-xl text-neutral-900 dark:text-white">
              Selected Works
            </h3>
            <span className="text-xs text-neutral-500">
              {designerProjects.length} portfolio items
            </span>
          </div>

          {designerProjects.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {designerProjects.map(project => (
                <ProjectCard key={project.id} project={project} />
              ))}
            </div>
          ) : (
            <div className="p-8 text-center bg-white dark:bg-neutral-900 rounded-2xl border border-neutral-200 dark:border-neutral-800">
              <p className="text-sm text-neutral-500">No additional projects available at this moment.</p>
            </div>
          )}
        </div>
      )}

      {activeTab === 'services' && (
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <h3 className="font-display font-bold text-xl text-neutral-900 dark:text-white">
              Standard Packages & Offerings
            </h3>
            <span className="text-xs text-neutral-500">Custom scopes also available on request</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {designer.services.map(pkg => (
              <div
                key={pkg.id}
                className="p-6 rounded-2xl bg-white dark:bg-neutral-900 border border-neutral-200/80 dark:border-neutral-800/80 shadow-sm flex flex-col justify-between space-y-5"
              >
                <div className="space-y-3">
                  <div className="flex items-baseline justify-between">
                    <h4 className="font-display font-bold text-lg text-neutral-900 dark:text-white">
                      {pkg.name}
                    </h4>
                    <span className="font-display font-black text-2xl text-indigo-600 dark:text-indigo-400">
                      ${pkg.price}
                    </span>
                  </div>

                  <p className="text-xs text-neutral-600 dark:text-neutral-300 leading-relaxed">
                    {pkg.description}
                  </p>

                  <div className="flex items-center gap-4 text-xs text-neutral-500 dark:text-neutral-400 py-1">
                    <span>⚡ {pkg.deliveryDays} Days Delivery</span>
                    <span>•</span>
                    <span>🔄 {pkg.revisions}</span>
                  </div>

                  {/* Deliverables checklist */}
                  <div className="space-y-2 pt-2 border-t border-neutral-100 dark:border-neutral-800">
                    <span className="text-[11px] font-bold uppercase tracking-wider text-neutral-400">
                      Deliverables Included:
                    </span>
                    <ul className="space-y-1.5 text-xs text-neutral-700 dark:text-neutral-300">
                      {pkg.deliverables.map((item, idx) => (
                        <li key={idx} className="flex items-center gap-2">
                          <Check className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
                          <span>{item}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>

                <button
                  onClick={() => openHireModal(designer)}
                  className="w-full py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-xs shadow-sm transition-all"
                >
                  Order Package (${pkg.price})
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {activeTab === 'reviews' && (
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <h3 className="font-display font-bold text-xl text-neutral-900 dark:text-white">
              Client Feedback & Testimonials
            </h3>
            <div className="flex items-center gap-1 text-sm font-bold text-neutral-900 dark:text-white">
              <Star className="w-4 h-4 text-amber-500 fill-amber-500" />
              <span>{designer.rating} / 5.0</span>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {designer.reviews.map(rev => (
              <div
                key={rev.id}
                className="p-6 rounded-2xl bg-white dark:bg-neutral-900 border border-neutral-200/80 dark:border-neutral-800/80 shadow-sm space-y-4"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1">
                    {[...Array(rev.rating)].map((_, i) => (
                      <Star key={i} className="w-3.5 h-3.5 text-amber-500 fill-amber-500" />
                    ))}
                  </div>
                  <span className="text-xs text-neutral-400">{rev.date}</span>
                </div>

                <p className="text-xs sm:text-sm text-neutral-700 dark:text-neutral-300 italic leading-relaxed">
                  "{rev.comment}"
                </p>

                {rev.projectName && (
                  <p className="text-[11px] text-indigo-600 dark:text-indigo-400 font-medium">
                    Project: {rev.projectName}
                  </p>
                )}

                <div className="flex items-center gap-3 pt-3 border-t border-neutral-100 dark:border-neutral-800">
                  <img
                    src={rev.clientAvatar}
                    alt={rev.clientName}
                    referrerPolicy="no-referrer"
                    className="w-8 h-8 rounded-full object-cover"
                  />
                  <div>
                    <h5 className="text-xs font-bold text-neutral-900 dark:text-white">{rev.clientName}</h5>
                    <p className="text-[10px] text-neutral-500">{rev.clientRole}, {rev.clientCompany}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {activeTab === 'about' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 space-y-6 bg-white dark:bg-neutral-900 p-8 rounded-3xl border border-neutral-200/80 dark:border-neutral-800/80">
            <div>
              <h3 className="font-display font-bold text-xl text-neutral-900 dark:text-white mb-3">
                Biography & Creative Practice
              </h3>
              <p className="text-sm text-neutral-600 dark:text-neutral-300 leading-relaxed">
                {designer.about}
              </p>
            </div>

            <div className="pt-4 border-t border-neutral-100 dark:border-neutral-800">
              <h4 className="font-semibold text-sm text-neutral-900 dark:text-white mb-3">
                Core Competencies & Tools
              </h4>
              <div className="flex flex-wrap gap-2">
                {designer.skills.map(skill => (
                  <span
                    key={skill}
                    className="px-3 py-1.5 rounded-xl text-xs font-semibold bg-neutral-100 dark:bg-neutral-800 text-neutral-700 dark:text-neutral-300"
                  >
                    {skill}
                  </span>
                ))}
              </div>
            </div>
          </div>

          {/* Socials & Verified Badge */}
          <div className="space-y-6">
            <div className="p-6 rounded-3xl bg-white dark:bg-neutral-900 border border-neutral-200/80 dark:border-neutral-800/80 space-y-4">
              <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-neutral-400">
                <ShieldCheck className="w-4 h-4 text-emerald-500" />
                <span>Verification & Guarantees</span>
              </div>
              <ul className="space-y-2 text-xs text-neutral-600 dark:text-neutral-300">
                <li className="flex items-center gap-2">
                  <Check className="w-3.5 h-3.5 text-indigo-500" />
                  <span>Identity & Portfolio Vetted</span>
                </li>
                <li className="flex items-center gap-2">
                  <Check className="w-3.5 h-3.5 text-indigo-500" />
                  <span>Commercial Copyright Transfer</span>
                </li>
                <li className="flex items-center gap-2">
                  <Check className="w-3.5 h-3.5 text-indigo-500" />
                  <span>Secure Escrow Payments</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
