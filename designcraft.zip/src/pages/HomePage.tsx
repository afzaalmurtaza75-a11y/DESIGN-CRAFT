import React from 'react';
import { useApp } from '../context/AppContext';
import { CategoryType } from '../types';
import { DesignerCard } from '../components/cards/DesignerCard';
import { ProjectCard } from '../components/cards/ProjectCard';
import { 
  ArrowRight, 
  Sparkles, 
  Search, 
  ShieldCheck, 
  MessageSquare, 
  Layers, 
  Star, 
  Palette, 
  Layout, 
  Globe, 
  Share2, 
  PenTool, 
  CheckCircle2, 
  TrendingUp,
  Award
} from 'lucide-react';
import { INITIAL_REVIEWS } from '../data/mockData';

export const HomePage: React.FC = () => {
  const { 
    designers, 
    projects, 
    navigateTo, 
    openStartProjectModal 
  } = useApp();

  const categories: { label: CategoryType; icon: React.ReactNode; desc: string; count: number }[] = [
    { label: 'Logo Design', icon: <PenTool className="w-5 h-5" />, desc: 'Memorable brand marks and symbols', count: 184 },
    { label: 'UI/UX Design', icon: <Layout className="w-5 h-5" />, desc: 'Mobile apps & digital interfaces', count: 320 },
    { label: 'Branding', icon: <Palette className="w-5 h-5" />, desc: 'Identity systems & brand guidelines', count: 245 },
    { label: 'Web Design', icon: <Globe className="w-5 h-5" />, desc: 'Responsive sites & modern landing pages', count: 210 },
    { label: 'Social Media', icon: <Share2 className="w-5 h-5" />, desc: 'High-conversion feeds and carousels', count: 160 },
    { label: 'Illustration', icon: <Sparkles className="w-5 h-5" />, desc: 'Custom editorial art & 3D narratives', count: 195 }
  ];

  const featuredDesigners = designers.filter(d => d.featured).slice(0, 4);
  const trendingProjects = projects.slice(0, 6);

  return (
    <div className="space-y-24 md:space-y-32 pb-24">
      {/* HERO SECTION */}
      <section className="relative pt-12 md:pt-20 lg:pt-28 overflow-hidden">
        {/* Subtle background decorative aura */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full max-w-7xl h-96 bg-gradient-to-tr from-indigo-500/10 via-purple-500/10 to-pink-500/5 blur-3xl -z-10 rounded-full pointer-events-none" />

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center">
            {/* Left Content */}
            <div className="lg:col-span-7 space-y-6 text-center lg:text-left">
              <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-indigo-50 dark:bg-indigo-950/50 border border-indigo-200/80 dark:border-indigo-800/80 text-indigo-700 dark:text-indigo-300 text-xs font-semibold tracking-wide">
                <Sparkles className="w-3.5 h-3.5 text-indigo-500" />
                <span>The Premier Creative Designer Network</span>
              </div>

              <h1 className="font-display font-black text-4xl sm:text-5xl md:text-6xl text-neutral-900 dark:text-white tracking-tight leading-[1.08]">
                Where Great Design Meets{' '}
                <span className="bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600 dark:from-indigo-400 dark:via-purple-400 dark:to-pink-400 bg-clip-text text-transparent">
                  Great Ideas
                </span>
              </h1>

              <p className="text-neutral-600 dark:text-neutral-300 text-lg sm:text-xl max-w-2xl mx-auto lg:mx-0 leading-relaxed font-normal">
                Discover talented designers, explore creative work, and bring your next idea to life.
              </p>

              {/* Action Buttons */}
              <div className="flex flex-col sm:flex-row items-center justify-center lg:justify-start gap-3 pt-2">
                <button
                  id="hero-explore-designers-btn"
                  onClick={() => navigateTo('designers')}
                  className="w-full sm:w-auto px-7 py-3.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-base shadow-lg shadow-indigo-600/25 hover:shadow-indigo-600/35 transition-all duration-200 flex items-center justify-center gap-2 active:scale-95"
                >
                  <span>Explore Designers</span>
                  <ArrowRight className="w-4 h-4" />
                </button>

                <button
                  id="hero-start-project-btn"
                  onClick={openStartProjectModal}
                  className="w-full sm:w-auto px-7 py-3.5 rounded-xl border border-neutral-300 dark:border-neutral-700 hover:bg-neutral-100 dark:hover:bg-neutral-800 text-neutral-900 dark:text-white font-semibold text-base transition-all duration-200"
                >
                  Start a Project
                </button>
              </div>

              {/* Trust Indicators */}
              <div className="pt-6 flex items-center justify-center lg:justify-start gap-6 text-xs text-neutral-500 dark:text-neutral-400 font-medium">
                <div className="flex items-center gap-1.5">
                  <ShieldCheck className="w-4 h-4 text-emerald-500" />
                  <span>Vetted Talent</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <Star className="w-4 h-4 text-amber-500 fill-amber-500" />
                  <span>4.95 Average Rating</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <Award className="w-4 h-4 text-indigo-500" />
                  <span>100% IP Ownership</span>
                </div>
              </div>
            </div>

            {/* Right Hero Visual / Interactive Showcase */}
            <div className="lg:col-span-5 relative">
              <div className="relative mx-auto max-w-md lg:max-w-none">
                {/* Main Card */}
                <div className="relative rounded-3xl overflow-hidden shadow-2xl border border-neutral-200/80 dark:border-neutral-800/80 bg-white dark:bg-neutral-900 group">
                  <div className="relative aspect-[4/3] overflow-hidden">
                    <img
                      src="https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=1000&q=80"
                      alt="Creative Studio Design"
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent" />
                    
                    <div className="absolute bottom-4 left-4 right-4 text-white">
                      <span className="px-2.5 py-1 rounded-md text-[11px] font-semibold bg-white/20 backdrop-blur-md">
                        Featured Brand Experience
                      </span>
                      <h3 className="font-display font-bold text-lg mt-1">
                        Kinetic Dynamic Identity System
                      </h3>
                      <p className="text-xs text-neutral-300">
                        Designed by Julian Sterling • London
                      </p>
                    </div>
                  </div>

                  {/* Floating Metric Badge 1: Top Rated */}
                  <div className="absolute -top-4 -left-4 p-3 rounded-2xl bg-white/95 dark:bg-neutral-850/95 backdrop-blur-md border border-neutral-200 dark:border-neutral-700 shadow-xl flex items-center gap-2.5 animate-bounce-slow">
                    <div className="w-8 h-8 rounded-xl bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 flex items-center justify-center">
                      <Star className="w-4 h-4 fill-current" />
                    </div>
                    <div>
                      <div className="text-xs font-bold text-neutral-900 dark:text-white">Top 1% Talent</div>
                      <div className="text-[10px] text-neutral-500">Strict curation filter</div>
                    </div>
                  </div>

                  {/* Floating Metric Badge 2: Completed Projects */}
                  <div className="absolute -bottom-4 -right-4 p-3 rounded-2xl bg-white/95 dark:bg-neutral-850/95 backdrop-blur-md border border-neutral-200 dark:border-neutral-700 shadow-xl flex items-center gap-2.5">
                    <div className="w-8 h-8 rounded-xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 flex items-center justify-center">
                      <TrendingUp className="w-4 h-4" />
                    </div>
                    <div>
                      <div className="text-xs font-bold text-neutral-900 dark:text-white">15,000+</div>
                      <div className="text-[10px] text-neutral-500">Designs Delivered</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* POPULAR CATEGORIES */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-8">
          <div>
            <span className="text-xs font-bold uppercase tracking-wider text-indigo-600 dark:text-indigo-400">
              Curated Disciplines
            </span>
            <h2 className="text-2xl sm:text-3xl font-display font-bold text-neutral-900 dark:text-white tracking-tight mt-1">
              Popular Categories
            </h2>
          </div>

          <button
            onClick={() => navigateTo('explore')}
            className="inline-flex items-center gap-1.5 text-sm font-semibold text-indigo-600 dark:text-indigo-400 hover:gap-2 transition-all"
          >
            <span>Browse All Categories</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
          {categories.map(cat => (
            <div
              key={cat.label}
              id={`cat-card-${cat.label.toLowerCase().replace(/\s+/g, '-')}`}
              onClick={() => navigateTo('explore', { category: cat.label })}
              className="group p-5 rounded-2xl bg-white dark:bg-neutral-900 border border-neutral-200/80 dark:border-neutral-800/80 hover:border-indigo-400 dark:hover:border-indigo-600 hover:shadow-lg transition-all duration-200 cursor-pointer flex flex-col justify-between"
            >
              <div className="w-11 h-11 rounded-xl bg-neutral-100 dark:bg-neutral-800 group-hover:bg-indigo-600 group-hover:text-white text-neutral-700 dark:text-neutral-200 flex items-center justify-center transition-colors duration-200 mb-4">
                {cat.icon}
              </div>
              <div>
                <h3 className="font-semibold text-sm text-neutral-900 dark:text-white group-hover:text-indigo-600 dark:group-hover:text-indigo-400 transition-colors">
                  {cat.label}
                </h3>
                <p className="text-[11px] text-neutral-400 dark:text-neutral-500 mt-0.5">
                  {cat.count}+ projects
                </p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* FEATURED DESIGNERS */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-8">
          <div>
            <span className="text-xs font-bold uppercase tracking-wider text-indigo-600 dark:text-indigo-400">
              Verified Creators
            </span>
            <h2 className="text-2xl sm:text-3xl font-display font-bold text-neutral-900 dark:text-white tracking-tight mt-1">
              Featured Designers
            </h2>
          </div>

          <button
            onClick={() => navigateTo('designers')}
            className="inline-flex items-center gap-1.5 text-sm font-semibold text-indigo-600 dark:text-indigo-400 hover:gap-2 transition-all"
          >
            <span>View All Designers</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {featuredDesigners.map(designer => (
            <DesignerCard key={designer.id} designer={designer} />
          ))}
        </div>
      </section>

      {/* TRENDING DESIGNS */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-8">
          <div>
            <span className="text-xs font-bold uppercase tracking-wider text-indigo-600 dark:text-indigo-400">
              Creative Showcase
            </span>
            <h2 className="text-2xl sm:text-3xl font-display font-bold text-neutral-900 dark:text-white tracking-tight mt-1">
              Trending Designs
            </h2>
          </div>

          <button
            onClick={() => navigateTo('explore')}
            className="inline-flex items-center gap-1.5 text-sm font-semibold text-indigo-600 dark:text-indigo-400 hover:gap-2 transition-all"
          >
            <span>Explore All Work</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {trendingProjects.map(project => (
            <ProjectCard key={project.id} project={project} />
          ))}
        </div>
      </section>

      {/* HOW IT WORKS */}
      <section className="bg-neutral-100/70 dark:bg-neutral-900/60 py-20 border-y border-neutral-200/80 dark:border-neutral-800/80 transition-colors">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-2xl mx-auto mb-16 space-y-3">
            <span className="text-xs font-bold uppercase tracking-wider text-indigo-600 dark:text-indigo-400">
              Simple & Transparent
            </span>
            <h2 className="text-3xl sm:text-4xl font-display font-bold text-neutral-900 dark:text-white tracking-tight">
              How It Works
            </h2>
            <p className="text-neutral-600 dark:text-neutral-400 text-sm sm:text-base">
              From creative brief to pixel-perfect delivery in three streamlined stages.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 relative">
            {/* Step 1 */}
            <div className="p-8 rounded-3xl bg-white dark:bg-neutral-850 border border-neutral-200 dark:border-neutral-700/80 shadow-sm relative space-y-4">
              <div className="w-12 h-12 rounded-2xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 flex items-center justify-center font-display font-extrabold text-lg">
                1
              </div>
              <h3 className="font-display font-bold text-xl text-neutral-900 dark:text-white">
                Find a Designer
              </h3>
              <p className="text-sm text-neutral-600 dark:text-neutral-400 leading-relaxed">
                Filter through verified talent by style, discipline, rating, or starting budget. Browse genuine portfolios with real client projects.
              </p>
            </div>

            {/* Step 2 */}
            <div className="p-8 rounded-3xl bg-white dark:bg-neutral-850 border border-neutral-200 dark:border-neutral-700/80 shadow-sm relative space-y-4">
              <div className="w-12 h-12 rounded-2xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 flex items-center justify-center font-display font-extrabold text-lg">
                2
              </div>
              <h3 className="font-display font-bold text-xl text-neutral-900 dark:text-white">
                Discuss Your Project
              </h3>
              <p className="text-sm text-neutral-600 dark:text-neutral-400 leading-relaxed">
                Align on project scope, milestone timelines, and custom deliverables directly with the creative. Review moodboards and concepts early.
              </p>
            </div>

            {/* Step 3 */}
            <div className="p-8 rounded-3xl bg-white dark:bg-neutral-850 border border-neutral-200 dark:border-neutral-700/80 shadow-sm relative space-y-4">
              <div className="w-12 h-12 rounded-2xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 flex items-center justify-center font-display font-extrabold text-lg">
                3
              </div>
              <h3 className="font-display font-bold text-xl text-neutral-900 dark:text-white">
                Get Your Design
              </h3>
              <p className="text-sm text-neutral-600 dark:text-neutral-400 leading-relaxed">
                Receive production-ready assets: vector source files, Figma design systems, brand guidelines, and full intellectual property copyright transfer.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CLIENT REVIEWS */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-12 space-y-3">
          <span className="text-xs font-bold uppercase tracking-wider text-indigo-600 dark:text-indigo-400">
            Trusted Worldwide
          </span>
          <h2 className="text-3xl font-display font-bold text-neutral-900 dark:text-white tracking-tight">
            Loved by Founders & Product Teams
          </h2>
          <p className="text-neutral-600 dark:text-neutral-400 text-sm">
            Read what startups and global organizations say about collaborating on DesignCraft.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {INITIAL_REVIEWS.map(rev => (
            <div
              key={rev.id}
              className="p-6 rounded-2xl bg-white dark:bg-neutral-900 border border-neutral-200/80 dark:border-neutral-800/80 shadow-sm flex flex-col justify-between"
            >
              <div className="space-y-3">
                <div className="flex items-center gap-1">
                  {[...Array(rev.rating)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 text-amber-500 fill-amber-500" />
                  ))}
                </div>
                <p className="text-xs sm:text-sm text-neutral-700 dark:text-neutral-300 leading-relaxed italic">
                  "{rev.comment}"
                </p>
              </div>

              <div className="pt-4 mt-4 border-t border-neutral-100 dark:border-neutral-800 flex items-center gap-3">
                <img
                  src={rev.clientAvatar}
                  alt={rev.clientName}
                  referrerPolicy="no-referrer"
                  className="w-10 h-10 rounded-full object-cover"
                />
                <div>
                  <h4 className="text-xs font-bold text-neutral-900 dark:text-white leading-tight">
                    {rev.clientName}
                  </h4>
                  <p className="text-[11px] text-neutral-500 dark:text-neutral-400">
                    {rev.clientRole}, {rev.clientCompany}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* CALL TO ACTION */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="relative rounded-3xl overflow-hidden bg-gradient-to-r from-neutral-900 via-indigo-950 to-neutral-900 text-white p-8 sm:p-12 md:p-16 border border-indigo-900/40 shadow-2xl">
          <div className="relative z-10 max-w-2xl space-y-5 text-center sm:text-left">
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/10 backdrop-blur-md text-xs font-semibold text-indigo-300">
              <Sparkles className="w-3.5 h-3.5" /> Start Crafting Today
            </span>

            <h2 className="font-display font-extrabold text-3xl sm:text-4xl md:text-5xl tracking-tight leading-tight">
              Have a project in mind?
            </h2>

            <p className="text-neutral-300 text-base sm:text-lg leading-relaxed">
              Connect with talented designers and turn your ideas into reality.
            </p>

            <div className="pt-2">
              <button
                id="cta-start-project-btn"
                onClick={openStartProjectModal}
                className="px-8 py-4 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-base shadow-xl shadow-indigo-600/30 transition-all duration-200 active:scale-95 inline-flex items-center gap-2"
              >
                <span>Start a Project</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Decorative geometric blur element in background */}
          <div className="absolute right-0 top-1/2 -translate-y-1/2 w-96 h-96 bg-indigo-500/20 rounded-full blur-3xl pointer-events-none" />
        </div>
      </section>
    </div>
  );
};
