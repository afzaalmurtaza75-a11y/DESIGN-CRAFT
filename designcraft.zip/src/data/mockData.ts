import { Designer, PortfolioProject, ServiceItem, Review, ClientProject, MessageThread } from '../types';

export const INITIAL_SERVICES: ServiceItem[] = [
  {
    id: 'srv-1',
    title: 'Logo Design',
    category: 'Logo Design',
    description: 'Distinctive, memorable brand marks and iconic visual symbols crafted for long-term brand equity.',
    startingPrice: 350,
    iconName: 'Shapes',
    popular: true,
    deliverables: [
      '3 unique initial logo concepts',
      'Full vector source files (AI, EPS, SVG, PNG, PDF)',
      'Brand color palette & typography pairings',
      'Full commercial copyright transfer'
    ]
  },
  {
    id: 'srv-2',
    title: 'Brand Identity',
    category: 'Branding',
    description: 'Comprehensive design system including guidelines, stationery, color psychology, and brand storytelling.',
    startingPrice: 1200,
    iconName: 'Palette',
    popular: true,
    deliverables: [
      'Comprehensive 40+ page Brand Guidelines document',
      'Typography hierarchy, iconography, and color scales',
      'Stationery suite (business cards, letterhead, envelopes)',
      'Social media kit and avatar templates'
    ]
  },
  {
    id: 'srv-3',
    title: 'UI/UX Design',
    category: 'UI/UX Design',
    description: 'High-conversion, intuitive digital product interfaces engineered with user research and design systems.',
    startingPrice: 1500,
    iconName: 'Layout',
    popular: true,
    deliverables: [
      'Interactive Figma prototypes with auto-layout',
      'User journey mapping and wireframe architecture',
      'Complete reusable design system component library',
      'Developer handoff specs with tokens & assets'
    ]
  },
  {
    id: 'srv-4',
    title: 'Web Design',
    category: 'Web Design',
    description: 'Bespoke, responsive landing pages and high-impact web experiences that capture attention and drive sales.',
    startingPrice: 950,
    iconName: 'Globe',
    deliverables: [
      'Pixel-perfect desktop and mobile responsive layouts',
      'Micro-interactions & animation choreography specs',
      'Asset export in modern WebP & vector formats',
      'Framer or Webflow ready structure'
    ]
  },
  {
    id: 'srv-5',
    title: 'Social Media Design',
    category: 'Social Media',
    description: 'Engaging, on-brand creative assets, carousels, and templates engineered to maximize organic social engagement.',
    startingPrice: 280,
    iconName: 'Share2',
    deliverables: [
      '15 customizable feed templates (Instagram, LinkedIn, X)',
      'Story and carousel templates in editable Figma format',
      'Thumbnail graphics and promotional banners',
      'Content grid layout strategy guide'
    ]
  },
  {
    id: 'srv-6',
    title: 'Poster Design',
    category: 'Posters',
    description: 'Expressive, avant-garde editorial and promotional posters for events, product launches, and exhibits.',
    startingPrice: 220,
    iconName: 'Image',
    deliverables: [
      'Ultra high-resolution print-ready files (CMYK 300DPI)',
      'Digital display versions for screens and outdoor LED',
      'Typography treatment and visual texture overlays',
      'Multiple standard poster formats (A1, A2, 24x36)'
    ]
  }
];

export const INITIAL_REVIEWS: Review[] = [
  {
    id: 'rev-1',
    clientName: 'Sarah Jenkins',
    clientRole: 'VP of Marketing',
    clientCompany: 'Aura Health',
    clientAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=160&q=80',
    rating: 5,
    date: '3 days ago',
    comment: 'Elena completely reimagined our mobile product experience. Our user activation jumped by 42% in the first two weeks post-launch. She is simply exceptional.',
    projectName: 'Aura Wellness Mobile App'
  },
  {
    id: 'rev-2',
    clientName: 'Marcus Vance',
    clientRole: 'Founder & CEO',
    clientCompany: 'Monolith Fintech',
    clientAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=160&q=80',
    rating: 5,
    date: '1 week ago',
    comment: 'Working with Julian on our rebrand was a masterclass in creative direction. He balanced sophisticated fintech credibility with high aesthetic polish.',
    projectName: 'Monolith Global Rebrand'
  },
  {
    id: 'rev-3',
    clientName: 'Chloe Dupont',
    clientRole: 'Head of Creative',
    clientCompany: 'Solstice Studios',
    clientAvatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=160&q=80',
    rating: 5,
    date: '2 weeks ago',
    comment: 'The quality of talent on DesignCraft is leagues ahead of traditional freelancer marketplaces. We found our lead branding specialist within 24 hours.',
    projectName: 'Editorial Brand Visuals'
  },
  {
    id: 'rev-4',
    clientName: 'David Chen',
    clientRole: 'Product Director',
    clientCompany: 'Orbit SaaS',
    clientAvatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=160&q=80',
    rating: 5,
    date: '3 weeks ago',
    comment: 'Flawless design tokens, crisp Figma components, and seamless communication. DesignCraft made our engineering handoff smooth as silk.',
    projectName: 'Orbit Cloud Dashboard UI'
  }
];

export const INITIAL_DESIGNERS: Designer[] = [
  {
    id: 'des-1',
    name: 'Elena Rostova',
    handle: '@elenarostova',
    avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=300&q=80',
    coverImage: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=1200&q=80',
    title: 'Senior Product & UI/UX Designer',
    category: 'UI/UX Design',
    location: 'Berlin, Germany',
    bio: 'Crafting intentional, high-converting digital products for ambitious tech ventures and design-forward startups.',
    about: 'With over 8 years of experience leading UI/UX initiatives for European tech unicorns and early-stage innovators, I specialize in transforming complex data workflows into elegant, intuitive human interfaces. Former Lead Designer at Kinetic Labs.',
    skills: ['Figma', 'Design Systems', 'Mobile App UI', 'Micro-interactions', 'User Research', 'Prototyping'],
    rating: 4.96,
    reviewCount: 48,
    completedProjects: 84,
    startingPrice: 850,
    hourlyRate: 95,
    availability: 'available',
    verified: true,
    featured: true,
    socials: {
      dribbble: 'https://dribbble.com',
      behance: 'https://behance.net',
      website: 'https://designcraft.example.com',
      twitter: 'https://twitter.com'
    },
    services: [
      {
        id: 'pk-1',
        name: 'Starter UI Audit & Wireframe',
        price: 850,
        deliveryDays: 4,
        revisions: '2 rounds',
        description: 'Complete UX teardown and high-fidelity wireframing for up to 4 key application screens.',
        deliverables: ['Heuristic analysis report', 'User flow diagrams', 'Clickable prototype in Figma', 'Asset exports']
      },
      {
        id: 'pk-2',
        name: 'Full Product MVP Design',
        price: 2400,
        deliveryDays: 12,
        revisions: 'Unlimited during sprint',
        description: 'End-to-end UX/UI design for web or mobile applications, including design system primitives.',
        deliverables: ['Up to 15 responsive screens', 'Design tokens & typography scales', 'Component library', 'Loom walkthrough']
      }
    ],
    reviews: [INITIAL_REVIEWS[0], INITIAL_REVIEWS[3]]
  },
  {
    id: 'des-2',
    name: 'Julian Sterling',
    handle: '@sterlingbrand',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80',
    coverImage: 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=1200&q=80',
    title: 'Brand Strategist & Identity Director',
    category: 'Branding',
    location: 'London, United Kingdom',
    bio: 'Sculpting timeless visual identities, luxury packaging, and cohesive graphic brand universes.',
    about: 'I help founders distill their core company philosophy into a compelling visual language. Having worked with fashion houses, specialty coffee roasters, and architectural studios, I balance minimalist restraint with bold personality.',
    skills: ['Brand Identity', 'Logo Design', 'Typography', 'Packaging', 'Art Direction', 'Print Production'],
    rating: 4.98,
    reviewCount: 62,
    completedProjects: 112,
    startingPrice: 1100,
    hourlyRate: 110,
    availability: 'available',
    verified: true,
    featured: true,
    socials: {
      behance: 'https://behance.net',
      instagram: 'https://instagram.com',
      website: 'https://designcraft.example.com'
    },
    services: [
      {
        id: 'pk-3',
        name: 'Core Brand Mark & Logo',
        price: 1100,
        deliveryDays: 6,
        revisions: '3 rounds',
        description: 'Custom bespoke logo system with responsive lockups, primary symbol, and color book.',
        deliverables: ['3 bespoke brand mark concepts', 'Full vector asset bundle', 'Basic brand guidelines PDF', 'Social avatars']
      },
      {
        id: 'pk-4',
        name: 'Comprehensive Identity Suite',
        price: 3200,
        deliveryDays: 18,
        revisions: 'Unlimited during sprint',
        description: 'Full-spectrum corporate identity overhaul with packaging, collateral, and comprehensive rulebook.',
        deliverables: ['Brand guidelines handbook', 'Complete packaging design', 'Stationery kit', 'Investor pitch deck theme']
      }
    ],
    reviews: [INITIAL_REVIEWS[1]]
  },
  {
    id: 'des-3',
    name: 'Kenji Takahashi',
    handle: '@takahashistudio',
    avatar: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?auto=format&fit=crop&w=300&q=80',
    coverImage: 'https://images.unsplash.com/photo-1550745165-9bc0b252726f?auto=format&fit=crop&w=1200&q=80',
    title: 'Lead Web Designer & Creative Technologist',
    category: 'Web Design',
    location: 'Tokyo, Japan',
    bio: 'Creating mesmerizing, fluid web experiences, editorial layouts, and micro-animated websites.',
    about: 'Bridging avant-garde Japanese modernism with cutting-edge responsive web layouts. I have won 4 Awwwards Site of the Day honors and love pushing the boundaries of web typography and spatial design.',
    skills: ['Web Design', 'UI Motion', 'Figma', 'Framer', 'Editorial Layout', 'Responsive Architecture'],
    rating: 4.92,
    reviewCount: 39,
    completedProjects: 65,
    startingPrice: 950,
    hourlyRate: 85,
    availability: 'available',
    verified: true,
    featured: true,
    socials: {
      dribbble: 'https://dribbble.com',
      website: 'https://designcraft.example.com',
      twitter: 'https://twitter.com'
    },
    services: [
      {
        id: 'pk-5',
        name: 'High-Impact Landing Page',
        price: 950,
        deliveryDays: 5,
        revisions: '2 rounds',
        description: 'A striking hero section and narrative product journey built to maximize conversion.',
        deliverables: ['Desktop & mobile Figma mockups', 'Interactive hover and scroll specs', 'Exported assets', 'Framer ready file']
      }
    ],
    reviews: [INITIAL_REVIEWS[2]]
  },
  {
    id: 'des-4',
    name: 'Amara Okafor',
    handle: '@amaraillustrates',
    avatar: 'https://images.unsplash.com/photo-1531746020798-e6953c6e8e04?auto=format&fit=crop&w=300&q=80',
    coverImage: 'https://images.unsplash.com/photo-1579783900882-c0d3dad7b119?auto=format&fit=crop&w=1200&q=80',
    title: 'Editorial Illustrator & Visual Artist',
    category: 'Illustration',
    location: 'Cape Town, South Africa',
    bio: 'Vibrant, culturally resonant illustrations, editorial spots, and 2D character narratives.',
    about: 'My illustration work has been featured in The New Yorker, Wired, and Spotify playlists. I create visual poetry through lush palettes, dynamic silhouettes, and rich textural depth.',
    skills: ['Editorial Illustration', 'Vector Art', 'Book Cover Art', 'Character Design', 'Procreate', 'Adobe Illustrator'],
    rating: 4.97,
    reviewCount: 54,
    completedProjects: 93,
    startingPrice: 450,
    hourlyRate: 75,
    availability: 'busy',
    verified: true,
    featured: true,
    socials: {
      instagram: 'https://instagram.com',
      behance: 'https://behance.net'
    },
    services: [
      {
        id: 'pk-6',
        name: 'Spot Illustration Trio',
        price: 450,
        deliveryDays: 4,
        revisions: '2 rounds',
        description: 'Three custom editorial illustrations tailored for articles, blog headers, or marketing campaigns.',
        deliverables: ['3 full vector illustrations', 'High-res transparent PNGs', 'Custom color palette', 'Commercial usage rights']
      }
    ],
    reviews: [INITIAL_REVIEWS[0]]
  },
  {
    id: 'des-5',
    name: 'Mateo Morales',
    handle: '@mateo_type',
    avatar: 'https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?auto=format&fit=crop&w=300&q=80',
    coverImage: 'https://images.unsplash.com/photo-1541701494587-cb58502866ab?auto=format&fit=crop&w=1200&q=80',
    title: 'Typographer & Logo Architect',
    category: 'Logo Design',
    location: 'Barcelona, Spain',
    bio: 'Obsessed with custom letterforms, wordmarks, and geometric logo construction.',
    about: 'I believe a great logo should be recognizable drawn in the sand with a stick. Specializing in bespoke display lettering and minimal monograms that withstand changing trends.',
    skills: ['Custom Lettering', 'Logo Design', 'Geometric Geometry', 'Monogram Design', 'Brand Systems'],
    rating: 4.89,
    reviewCount: 31,
    completedProjects: 58,
    startingPrice: 400,
    hourlyRate: 70,
    availability: 'available',
    verified: true,
    featured: false,
    socials: {
      dribbble: 'https://dribbble.com',
      instagram: 'https://instagram.com'
    },
    services: [
      {
        id: 'pk-7',
        name: 'Bespoke Wordmark & Monogram',
        price: 400,
        deliveryDays: 3,
        revisions: '3 rounds',
        description: 'Custom hand-drawn typographic logotype crafted from scratch, no stock fonts.',
        deliverables: ['Custom letterform files', 'Vector formats (SVG, AI)', 'Monogram icon variation', 'Color variations']
      }
    ],
    reviews: [INITIAL_REVIEWS[1]]
  },
  {
    id: 'des-6',
    name: 'Sienna Zhao',
    handle: '@siennazhaodesign',
    avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=300&q=80',
    coverImage: 'https://images.unsplash.com/photo-1513542789411-b6a5d4f31634?auto=format&fit=crop&w=1200&q=80',
    title: 'Social Media & Growth Visual Designer',
    category: 'Social Media',
    location: 'Toronto, Canada',
    bio: 'Designing high-velocity creative content, launch campaigns, and viral carousel systems.',
    about: 'Bridging aesthetic beauty with engagement metrics. Over the last 5 years, my visual assets have generated over 80 million impressions across consumer brands and modern SaaS platforms.',
    skills: ['Social Media Design', 'Carousel Graphics', 'Ad Creatives', 'Motion Graphics', 'Canva Systems', 'Figma'],
    rating: 4.94,
    reviewCount: 44,
    completedProjects: 120,
    startingPrice: 350,
    hourlyRate: 65,
    availability: 'available',
    verified: true,
    featured: false,
    socials: {
      instagram: 'https://instagram.com',
      twitter: 'https://twitter.com'
    },
    services: [
      {
        id: 'pk-8',
        name: 'Full Campaign Social Kit',
        price: 650,
        deliveryDays: 5,
        revisions: '2 rounds',
        description: 'Everything needed to dominate social platforms during your next major product release.',
        deliverables: ['20 multi-platform templates', '3 animated story clips', 'Style guide for social', 'Figma source files']
      }
    ],
    reviews: [INITIAL_REVIEWS[2]]
  },
  {
    id: 'des-7',
    name: 'Nikolai Lindqvist',
    handle: '@nordicdesignlab',
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=300&q=80',
    coverImage: 'https://images.unsplash.com/photo-1507238691740-187a5b1d37b8?auto=format&fit=crop&w=1200&q=80',
    title: 'Minimalist Poster & Print Specialist',
    category: 'Posters',
    location: 'Stockholm, Sweden',
    bio: 'Swiss-style grid systems, brutalist concert posters, and architectural exhibition prints.',
    about: 'Rooted in Scandinavian modernism and the International Typographic Style. Every poster I compose leverages mathematical grid systems, asymmetry, and intentional white space.',
    skills: ['Poster Design', 'Swiss Typography', 'Print Production', 'Editorial Layout', 'Grid Systems', 'InDesign'],
    rating: 4.91,
    reviewCount: 29,
    completedProjects: 52,
    startingPrice: 250,
    hourlyRate: 70,
    availability: 'available',
    verified: true,
    featured: false,
    socials: {
      behance: 'https://behance.net',
      website: 'https://designcraft.example.com'
    },
    services: [
      {
        id: 'pk-9',
        name: 'Exhibition & Event Poster Duo',
        price: 250,
        deliveryDays: 3,
        revisions: '2 rounds',
        description: 'Two complementary posters formatted for both large scale physical printing and digital screens.',
        deliverables: ['Print ready 300 DPI CMYK PDFs', 'Digital 4K PNGs', 'Custom typography lockups', 'Mockup previews']
      }
    ],
    reviews: [INITIAL_REVIEWS[3]]
  },
  {
    id: 'des-8',
    name: 'Camila Rodriguez',
    handle: '@camilacreative',
    avatar: 'https://images.unsplash.com/photo-1567532939604-b6b5b0db2604?auto=format&fit=crop&w=300&q=80',
    coverImage: 'https://images.unsplash.com/photo-1579546929518-9e396f3cc809?auto=format&fit=crop&w=1200&q=80',
    title: 'Visual Identity & Creative Consultant',
    category: 'Branding',
    location: 'Buenos Aires, Argentina',
    bio: 'Holistic brand identities that ignite emotional bonds between products and people.',
    about: 'I collaborate with ethical lifestyle brands, boutique hospitality spots, and creative studios. My aesthetic merges warm tactile textures with clean, contemporary typography.',
    skills: ['Branding', 'Packaging', 'Creative Strategy', 'Collateral Design', 'Color Systems', 'Illustrator'],
    rating: 4.95,
    reviewCount: 38,
    completedProjects: 77,
    startingPrice: 600,
    hourlyRate: 80,
    availability: 'available',
    verified: true,
    featured: true,
    socials: {
      dribbble: 'https://dribbble.com',
      instagram: 'https://instagram.com'
    },
    services: [
      {
        id: 'pk-10',
        name: 'Boutique Brand Identity Pack',
        price: 850,
        deliveryDays: 7,
        revisions: '3 rounds',
        description: 'Complete brand essence bundle for boutique shops, restaurants, and founders.',
        deliverables: ['Primary & secondary logos', 'Packaging & label templates', 'Color & font guide', 'Social template set']
      }
    ],
    reviews: [INITIAL_REVIEWS[0]]
  }
];

export const INITIAL_PROJECTS: PortfolioProject[] = [
  {
    id: 'proj-1',
    title: 'Aura AI Wellness & Meditation App',
    designerId: 'des-1',
    designerName: 'Elena Rostova',
    designerAvatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=120&q=80',
    designerTitle: 'Senior Product & UI/UX Designer',
    category: 'UI/UX Design',
    imageUrl: 'https://images.unsplash.com/photo-1616469829941-c7200edec809?auto=format&fit=crop&w=1000&q=80',
    description: 'A comprehensive mobile interface redesign emphasizing calm mindfulness, biometrics tracking, and personalized audio meditations.',
    likes: 412,
    views: 3890,
    toolsUsed: ['Figma', 'Protopie', 'After Effects'],
    clientName: 'Aura Health Inc.',
    completionDate: 'August 2026',
    featured: true
  },
  {
    id: 'proj-2',
    title: 'Monolith Global Financial Brand System',
    designerId: 'des-2',
    designerName: 'Julian Sterling',
    designerAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=120&q=80',
    designerTitle: 'Brand Strategist & Identity Director',
    category: 'Branding',
    imageUrl: 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=1000&q=80',
    description: 'Corporate rebranding including a geometric monolith emblem, embossed stationery, and custom typeface adaptations for a London venture fund.',
    likes: 589,
    views: 5210,
    toolsUsed: ['Illustrator', 'InDesign', 'Photoshop'],
    clientName: 'Monolith Holdings',
    completionDate: 'July 2026',
    featured: true
  },
  {
    id: 'proj-3',
    title: 'Kinetic Architecture Web Studio',
    designerId: 'des-3',
    designerName: 'Kenji Takahashi',
    designerAvatar: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?auto=format&fit=crop&w=120&q=80',
    designerTitle: 'Lead Web Designer',
    category: 'Web Design',
    imageUrl: 'https://images.unsplash.com/photo-1507238691740-187a5b1d37b8?auto=format&fit=crop&w=1000&q=80',
    description: 'An interactive portfolio site featuring structural glassmorphism, horizontal project showcases, and editorial architecture typography.',
    likes: 367,
    views: 3410,
    toolsUsed: ['Figma', 'Framer', 'Three.js'],
    clientName: 'Kengo Atelier',
    completionDate: 'June 2026',
    featured: true
  },
  {
    id: 'proj-4',
    title: 'Lumina Botanical Gin Packaging & Identity',
    designerId: 'des-8',
    designerName: 'Camila Rodriguez',
    designerAvatar: 'https://images.unsplash.com/photo-1567532939604-b6b5b0db2604?auto=format&fit=crop&w=120&q=80',
    designerTitle: 'Visual Identity Consultant',
    category: 'Branding',
    imageUrl: 'https://images.unsplash.com/photo-1527061011665-3652c757a4d4?auto=format&fit=crop&w=1000&q=80',
    description: 'Artisanal spirit packaging with tactile gold foil accents, bespoke botanical line engravings, and custom amber glass bottle typography.',
    likes: 495,
    views: 4120,
    toolsUsed: ['Illustrator', 'Blender', 'Photoshop'],
    clientName: 'Lumina Distillers',
    completionDate: 'May 2026',
    featured: true
  },
  {
    id: 'proj-5',
    title: 'Vortex Quantum Typography Poster Series',
    designerId: 'des-7',
    designerName: 'Nikolai Lindqvist',
    designerAvatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=120&q=80',
    designerTitle: 'Minimalist Poster Specialist',
    category: 'Posters',
    imageUrl: 'https://images.unsplash.com/photo-1541701494587-cb58502866ab?auto=format&fit=crop&w=1000&q=80',
    description: 'Experimental Swiss-style typographic poster series exploring gravitational waves and sound frequencies in modern architecture.',
    likes: 310,
    views: 2980,
    toolsUsed: ['InDesign', 'Illustrator'],
    clientName: 'Stockholm Design Week',
    completionDate: 'September 2026',
    featured: false
  },
  {
    id: 'proj-6',
    title: 'Neon Odyssey Synthwave Illustrations',
    designerId: 'des-4',
    designerName: 'Amara Okafor',
    designerAvatar: 'https://images.unsplash.com/photo-1531746020798-e6953c6e8e04?auto=format&fit=crop&w=120&q=80',
    designerTitle: 'Editorial Illustrator',
    category: 'Illustration',
    imageUrl: 'https://images.unsplash.com/photo-1579783900882-c0d3dad7b119?auto=format&fit=crop&w=1000&q=80',
    description: 'A vibrant suite of 6 narrative digital illustrations depicting futuristic African metropolis landscapes and solar-punk energy.',
    likes: 541,
    views: 6100,
    toolsUsed: ['Procreate', 'Adobe Illustrator', 'Photoshop'],
    clientName: 'AfroFuturism Press',
    completionDate: 'August 2026',
    featured: true
  },
  {
    id: 'proj-7',
    title: 'Prism SaaS Analytics & Data Studio',
    designerId: 'des-1',
    designerName: 'Elena Rostova',
    designerAvatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=120&q=80',
    designerTitle: 'Senior Product Designer',
    category: 'UI/UX Design',
    imageUrl: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?auto=format&fit=crop&w=1000&q=80',
    description: 'A dark-mode analytics workstation providing machine learning observability, funnel diagnostics, and real-time revenue cohorts.',
    likes: 472,
    views: 4530,
    toolsUsed: ['Figma', 'Storybook', 'Tailwind CSS'],
    clientName: 'Prism Data Cloud',
    completionDate: 'July 2026',
    featured: true
  },
  {
    id: 'proj-8',
    title: 'Apex Mobility Electric Vehicle Logomark',
    designerId: 'des-5',
    designerName: 'Mateo Morales',
    designerAvatar: 'https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?auto=format&fit=crop&w=120&q=80',
    designerTitle: 'Logo Architect',
    category: 'Logo Design',
    imageUrl: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=1000&q=80',
    description: 'Dynamic aerodynamic monogram crafted for an autonomous EV startup, with fluid negative space evoking continuous speed.',
    likes: 298,
    views: 2650,
    toolsUsed: ['Illustrator', 'Glyphs'],
    clientName: 'Apex EV Motors',
    completionDate: 'June 2026',
    featured: false
  },
  {
    id: 'proj-9',
    title: 'CreatorLab Viral Social Growth Pack',
    designerId: 'des-6',
    designerName: 'Sienna Zhao',
    designerAvatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=120&q=80',
    designerTitle: 'Social Media Visual Designer',
    category: 'Social Media',
    imageUrl: 'https://images.unsplash.com/photo-1611162617474-5b21e879e113?auto=format&fit=crop&w=1000&q=80',
    description: 'Modular social templates optimized for multi-slide carousel storytelling, LinkedIn thought leadership, and product teardowns.',
    likes: 388,
    views: 3820,
    toolsUsed: ['Figma', 'After Effects'],
    clientName: 'CreatorLab Studio',
    completionDate: 'August 2026',
    featured: false
  },
  {
    id: 'proj-10',
    title: 'Nordic Ceramic Craftsman Brand Identity',
    designerId: 'des-2',
    designerName: 'Julian Sterling',
    designerAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=120&q=80',
    designerTitle: 'Brand Strategist',
    category: 'Branding',
    imageUrl: 'https://images.unsplash.com/photo-1565193566173-7a0ee3dbe261?auto=format&fit=crop&w=1000&q=80',
    description: 'Earthy, minimalist identity system celebrating raw clay textures, blind debossing, and warm stone gray tonal aesthetics.',
    likes: 420,
    views: 3950,
    toolsUsed: ['Illustrator', 'Photoshop'],
    clientName: 'Studio Jord Pottery',
    completionDate: 'May 2026',
    featured: false
  },
  {
    id: 'proj-11',
    title: 'Solstice Music & Arts Festival Poster',
    designerId: 'des-7',
    designerName: 'Nikolai Lindqvist',
    designerAvatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=120&q=80',
    designerTitle: 'Minimalist Poster Specialist',
    category: 'Posters',
    imageUrl: 'https://images.unsplash.com/photo-1514525253161-7a46d19cd819?auto=format&fit=crop&w=1000&q=80',
    description: 'A psychedelic yet structured typographic visual celebrating summer solstice performances across three open-air stages.',
    likes: 345,
    views: 3100,
    toolsUsed: ['InDesign', 'Photoshop'],
    clientName: 'Solstice Cultural Org',
    completionDate: 'April 2026',
    featured: false
  },
  {
    id: 'proj-12',
    title: 'Chroma Digital Magazine Web Experience',
    designerId: 'des-3',
    designerName: 'Kenji Takahashi',
    designerAvatar: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?auto=format&fit=crop&w=120&q=80',
    designerTitle: 'Lead Web Designer',
    category: 'Web Design',
    imageUrl: 'https://images.unsplash.com/photo-1498050108023-c5249f4df085?auto=format&fit=crop&w=1000&q=80',
    description: 'Experimental digital editorial featuring kinetic typography headlines, responsive masonry article displays, and darkroom audio toggles.',
    likes: 512,
    views: 4890,
    toolsUsed: ['Figma', 'Framer', 'GSAP'],
    clientName: 'Chroma Media Group',
    completionDate: 'March 2026',
    featured: true
  }
];

export const INITIAL_CLIENT_PROJECTS: ClientProject[] = [
  {
    id: 'cp-1',
    title: 'Brand Identity & Guidelines Redesign',
    category: 'Branding',
    designerId: 'des-2',
    designerName: 'Julian Sterling',
    designerAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=120&q=80',
    budget: 2500,
    deadline: 'Oct 15, 2026',
    status: 'In Progress',
    description: 'Modernizing our core consumer identity with new logo lockups, stationery, and comprehensive Figma guidelines.',
    createdAt: 'Sep 10, 2026',
    deliverablesCount: 4
  },
  {
    id: 'cp-2',
    title: 'SaaS Mobile App UX Flow & Wireframes',
    category: 'UI/UX Design',
    designerId: 'des-1',
    designerName: 'Elena Rostova',
    designerAvatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=120&q=80',
    budget: 1800,
    deadline: 'Sep 30, 2026',
    status: 'Under Review',
    description: 'Interactive high-fidelity prototypes for our iOS client dashboard and push notification center.',
    createdAt: 'Sep 02, 2026',
    deliverablesCount: 6
  },
  {
    id: 'cp-3',
    title: 'Launch Event Posters & Social Promo Kit',
    category: 'Posters',
    designerId: 'des-7',
    designerName: 'Nikolai Lindqvist',
    designerAvatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=120&q=80',
    budget: 750,
    deadline: 'Aug 28, 2026',
    status: 'Completed',
    description: 'Minimalist Swiss posters and digital display variants for our global developer summit.',
    createdAt: 'Aug 14, 2026',
    deliverablesCount: 3
  }
];

export const INITIAL_MESSAGE_THREADS: MessageThread[] = [
  {
    id: 'th-1',
    participantId: 'des-1',
    participantName: 'Elena Rostova',
    participantAvatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=120&q=80',
    participantRole: 'Senior Product Designer',
    lastMessage: "I just pushed the revised interactive prototype in Figma! Let me know your thoughts on the onboarding flow.",
    lastMessageTime: '10:24 AM',
    unreadCount: 1,
    messages: [
      {
        id: 'm-1',
        senderId: 'client-user',
        text: 'Hi Elena! We love the latest moodboard you sent over. Can we focus on the checkout steps next?',
        timestamp: 'Yesterday, 4:15 PM',
        isOwn: true
      },
      {
        id: 'm-2',
        senderId: 'des-1',
        text: "Absolutely! I've streamlined the checkout into 2 frictionless micro-steps to reduce drop-offs.",
        timestamp: 'Yesterday, 5:30 PM',
        isOwn: false
      },
      {
        id: 'm-3',
        senderId: 'des-1',
        text: "I just pushed the revised interactive prototype in Figma! Let me know your thoughts on the onboarding flow.",
        timestamp: '10:24 AM',
        isOwn: false
      }
    ]
  },
  {
    id: 'th-2',
    participantId: 'des-2',
    participantName: 'Julian Sterling',
    participantAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=120&q=80',
    participantRole: 'Brand Strategist',
    lastMessage: "Here are the 3 final logo vectors in SVG and EPS. Everything is ready for trademark filing.",
    lastMessageTime: 'Sep 12',
    unreadCount: 0,
    messages: [
      {
        id: 'm-4',
        senderId: 'client-user',
        text: 'Julian, the serif option is brilliant. Can we get the dark mode colorway files?',
        timestamp: 'Sep 12, 1:00 PM',
        isOwn: true
      },
      {
        id: 'm-5',
        senderId: 'des-2',
        text: "Here are the 3 final logo vectors in SVG and EPS. Everything is ready for trademark filing.",
        timestamp: 'Sep 12, 3:45 PM',
        isOwn: false
      }
    ]
  }
];
